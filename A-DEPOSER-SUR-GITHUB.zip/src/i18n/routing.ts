import { defineRouting } from 'next-intl/routing';

/**
 * Les deux versions du site.
 * L'anglais est la langue par défaut : c'est la priorité éditoriale d'Afro Daily Village.
 * Chaque adresse est traduite, parce qu'un lecteur anglophone cherche "stories",
 * pas "histoires" — et Google en tient compte.
 */
export const routing = defineRouting({
  locales: ['en', 'fr'],
  defaultLocale: 'en',
  localePrefix: 'always',
  localeDetection: true,
  pathnames: {
    '/': '/',
    '/videos': { en: '/videos', fr: '/videos' },
    '/villages': { en: '/villages', fr: '/villages' },
    '/villages/[slug]': { en: '/villages/[slug]', fr: '/villages/[slug]' },
    '/countries/[slug]': { en: '/countries/[slug]', fr: '/pays/[slug]' },
    '/culture': { en: '/culture', fr: '/culture' },
    '/culture/[slug]': { en: '/culture/[slug]', fr: '/culture/[slug]' },
    '/food': { en: '/food', fr: '/cuisine' },
    '/food/[slug]': { en: '/food/[slug]', fr: '/cuisine/[slug]' },
    '/stories': { en: '/stories', fr: '/histoires' },
    '/stories/[slug]': { en: '/stories/[slug]', fr: '/histoires/[slug]' },
    '/languages': { en: '/languages', fr: '/langues' },
    '/languages/[slug]': { en: '/languages/[slug]', fr: '/langues/[slug]' },
    '/about': { en: '/about', fr: '/a-propos' },
    '/contact': { en: '/contact', fr: '/contact' },
    '/partners': { en: '/partners', fr: '/partenaires' },
    '/support': { en: '/support', fr: '/soutenir' },
    '/search': { en: '/search', fr: '/recherche' },
    '/legal-notice': { en: '/legal-notice', fr: '/mentions-legales' },
    '/privacy': { en: '/privacy', fr: '/confidentialite' },
    '/cookies': { en: '/cookies', fr: '/cookies' },
    '/terms': { en: '/terms', fr: '/conditions' },
  },
} as const);

export type Locale = (typeof routing.locales)[number];
