import { createNavigation } from 'next-intl/navigation';
import { routing } from './routing';

/**
 * À utiliser PARTOUT à la place de next/link et next/navigation.
 * Ces versions ajoutent automatiquement /en ou /fr et traduisent l'adresse.
 */
export const { Link, redirect, usePathname, useRouter, getPathname } =
  createNavigation(routing);
