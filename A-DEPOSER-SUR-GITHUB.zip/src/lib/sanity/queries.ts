/**
 * LES REQUÊTES ENVOYÉES AU TABLEAU DE BORD
 *
 * Écrites en GROQ, le langage de Sanity. Chaque requête ne demande que les
 * champs dont la page a besoin — c'est ce qui garde le site rapide.
 */

/** Une image, avec son texte alternatif et son aperçu flou. */
const IMG = `{
  "url": asset->url,
  "alt": alt,
  "lqip": asset->metadata.lqip
}`;

const BODY = `{
  ...,
  _type == "image" => { "url": asset->url, "alt": alt, "caption": caption }
}`;

export const ARTICLE_FIELDS = `
  "slug": slug.current,
  title, standfirst, category,
  "categorySlug": lower(coalesce(category.en, "")),
  "country": country->slug.current,
  "village": village->slug.current,
  "author": author->slug.current,
  publishedAt, readingMinutes, featured,
  "image": mainImage${IMG},
  "bodyEn": body.en[]${BODY},
  "bodyFr": body.fr[]${BODY}
`;

export const VIDEO_FIELDS = `
  "slug": slug.current,
  youtubeId, title, category, categoryKey,
  "country": country->slug.current,
  "village": village->slug.current,
  durationSeconds, publishedAt, format,
  "image": mainImage${IMG}
`;

export const VILLAGE_FIELDS = `
  "slug": slug.current,
  name, region, summary, description, filmed,
  "country": country->slug.current,
  "lat": location.lat,
  "lng": location.lng,
  "languages": languages[]->slug.current,
  "image": mainImage${IMG},
  "gallery": gallery[]${IMG}
`;

export const COUNTRY_FIELDS = `
  "slug": slug.current, name, iso, intro, "image": mainImage${IMG}
`;

export const RECIPE_FIELDS = `
  "slug": slug.current,
  name, region, summary, minutes, serves, ingredients, steps, story,
  "country": country->slug.current,
  "image": mainImage${IMG}
`;

export const LANGUAGE_FIELDS = `
  "slug": slug.current, name, speakers, description, region
`;

export const WORD_FIELDS = `
  "slug": slug.current,
  word, pronunciation, meaning, example, exampleTranslation, region,
  "language": language->slug.current,
  "audioUrl": audio.asset->url
`;

export const CULTURE_FIELDS = `
  "slug": slug.current, name, description, "image": mainImage${IMG}
`;

export const AUTHOR_FIELDS = `
  "slug": slug.current, name, role, bio, "image": photo${IMG}
`;

/* ---------- les requêtes complètes ---------- */

export const Q = {
  articles: `*[_type == "article" && defined(slug.current)]|order(publishedAt desc){${ARTICLE_FIELDS}}`,
  articleBySlug: `*[_type == "article" && slug.current == $slug][0]{${ARTICLE_FIELDS}}`,
  featuredArticle: `*[_type == "article" && featured == true]|order(publishedAt desc)[0]{${ARTICLE_FIELDS}}`,
  articlesByVillage: `*[_type == "article" && village->slug.current == $slug]|order(publishedAt desc){${ARTICLE_FIELDS}}`,
  articlesByCountry: `*[_type == "article" && country->slug.current == $slug]|order(publishedAt desc){${ARTICLE_FIELDS}}`,

  videos: `*[_type == "video" && defined(slug.current)]|order(publishedAt desc){${VIDEO_FIELDS}}`,
  videosByVillage: `*[_type == "video" && village->slug.current == $slug]|order(publishedAt desc){${VIDEO_FIELDS}}`,
  videosByCountry: `*[_type == "video" && country->slug.current == $slug]|order(publishedAt desc){${VIDEO_FIELDS}}`,

  villages: `*[_type == "village" && defined(slug.current)]|order(name asc){${VILLAGE_FIELDS}}`,
  villageBySlug: `*[_type == "village" && slug.current == $slug][0]{${VILLAGE_FIELDS}}`,
  villagesByCountry: `*[_type == "village" && country->slug.current == $slug]|order(name asc){${VILLAGE_FIELDS}}`,

  countries: `*[_type == "country" && defined(slug.current)]|order(name.en asc){${COUNTRY_FIELDS}}`,
  countryBySlug: `*[_type == "country" && slug.current == $slug][0]{${COUNTRY_FIELDS}}`,

  recipes: `*[_type == "recipe" && defined(slug.current)]|order(name.en asc){${RECIPE_FIELDS}}`,
  recipeBySlug: `*[_type == "recipe" && slug.current == $slug][0]{${RECIPE_FIELDS}}`,
  recipesByCountry: `*[_type == "recipe" && country->slug.current == $slug]{${RECIPE_FIELDS}}`,

  languages: `*[_type == "language" && defined(slug.current)]|order(name asc){${LANGUAGE_FIELDS}}`,
  languageBySlug: `*[_type == "language" && slug.current == $slug][0]{${LANGUAGE_FIELDS}}`,

  words: `*[_type == "word" && defined(slug.current)]|order(word asc){${WORD_FIELDS}}`,
  wordsByLanguage: `*[_type == "word" && language->slug.current == $slug]|order(word asc){${WORD_FIELDS}}`,

  cultureThemes: `*[_type == "cultureTheme" && defined(slug.current)]{${CULTURE_FIELDS}}`,
  cultureThemeBySlug: `*[_type == "cultureTheme" && slug.current == $slug][0]{${CULTURE_FIELDS}}`,

  authors: `*[_type == "author" && defined(slug.current)]{${AUTHOR_FIELDS}}`,
  authorBySlug: `*[_type == "author" && slug.current == $slug][0]{${AUTHOR_FIELDS}}`,

  settings: `*[_type == "siteSettings"][0]{
    youtubeUrl, tiktokUrl, instagramUrl, contactEmail, footerBlurb
  }`,
} as const;
