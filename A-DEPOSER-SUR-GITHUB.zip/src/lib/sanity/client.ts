import 'server-only';
import { createClient, type SanityClient } from 'next-sanity';
import { apiVersion, dataset, projectId, sanityEnabled } from '@/sanity/env';

/**
 * La connexion au tableau de bord.
 *
 * `useCdn: true` fait passer les requêtes par le réseau de diffusion de Sanity :
 * c'est beaucoup plus rapide et cela protège le site en cas de pic de visiteurs.
 */
export const sanityClient: SanityClient | null = sanityEnabled
  ? createClient({
      projectId,
      dataset,
      apiVersion,
      useCdn: true,
      perspective: 'published',
      token: process.env.SANITY_API_READ_TOKEN || undefined,
    })
  : null;

/**
 * Interroge le tableau de bord, et retombe sur le contenu de démonstration
 * si quoi que ce soit se passe mal.
 *
 * C'est la pièce qui garantit qu'une panne de Sanity ne met JAMAIS le site
 * hors service : au pire, il affiche l'ancien contenu.
 */
export async function sanityFetch<T>(
  query: string,
  params: Record<string, unknown>,
  fallback: T,
  /** Durée pendant laquelle la réponse est gardée en mémoire, en secondes. */
  revalidate = 300,
): Promise<T> {
  if (!sanityClient) return fallback;

  try {
    const data = await sanityClient.fetch<T>(query, params, {
      next: { revalidate },
    });
    if (data === null || data === undefined) return fallback;
    if (Array.isArray(data) && data.length === 0) return fallback;
    return data;
  } catch (error) {
    // On garde le message court : une panne de Sanity ne doit pas noyer les journaux.
    const reason = error instanceof Error ? error.message.split('\n')[0] : String(error);
    console.warn(`[sanity] indisponible, contenu de démonstration utilisé — ${reason}`);
    return fallback;
  }
}
