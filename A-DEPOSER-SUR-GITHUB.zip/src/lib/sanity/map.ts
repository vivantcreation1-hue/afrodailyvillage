import type {
  Article,
  Author,
  Block,
  Country,
  CultureTheme,
  ImageRef,
  Language,
  Localized,
  Recipe,
  Video,
  VideoCategoryKey,
  Village,
  Word,
} from '@/lib/content/types';

/**
 * TRADUCTION SANITY → SITE
 *
 * Sanity renvoie ses données dans sa propre forme. Ces fonctions les
 * remettent exactement dans la forme que les pages du site attendent.
 * C'est ici, et nulle part ailleurs, qu'on absorbe les différences.
 */

type Raw = Record<string, unknown>;

/** Un texte bilingue. Si le français manque, on retombe sur l'anglais. */
function loc(value: unknown): Localized {
  const v = (value ?? {}) as { en?: string; fr?: string };
  const en = v.en ?? '';
  return { en, fr: v.fr?.trim() ? v.fr : en };
}

/** Une liste bilingue (ingrédients, étapes). */
function locList(value: unknown): Localized<string[]> {
  const v = (value ?? {}) as { en?: string[]; fr?: string[] };
  const en = v.en ?? [];
  return { en, fr: v.fr?.length ? v.fr : en };
}

function img(value: unknown): ImageRef | undefined {
  const v = value as { url?: string; alt?: string; lqip?: string } | null | undefined;
  if (!v?.url) return undefined;
  return { url: v.url, alt: v.alt ?? undefined, lqip: v.lqip ?? undefined };
}

function str(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value : fallback;
}

function num(value: unknown, fallback = 0): number {
  return typeof value === 'number' ? value : fallback;
}

/* ---------- le texte riche des articles ---------- */

type PtChild = { text?: string };
type PtBlock = {
  _type?: string;
  style?: string;
  children?: PtChild[];
  url?: string;
  alt?: string;
  caption?: string;
};

/**
 * Sanity écrit les articles en « Portable Text ».
 * On le remet dans nos quatre briques : paragraphe, intertitre, citation, image.
 */
function toBlocks(raw: unknown): Block[] {
  if (!Array.isArray(raw)) return [];
  const blocks: Block[] = [];

  for (const item of raw as PtBlock[]) {
    if (item._type === 'image') {
      if (!item.url) continue;
      blocks.push({
        type: 'image',
        image: { url: item.url, alt: item.alt },
        caption: item.caption ?? item.alt ?? '',
      });
      continue;
    }

    const text = (item.children ?? []).map((c) => c.text ?? '').join('').trim();
    if (!text) continue;

    if (item.style === 'h2' || item.style === 'h3' || item.style === 'h4') {
      blocks.push({ type: 'h2', text });
    } else if (item.style === 'blockquote') {
      blocks.push({ type: 'quote', text });
    } else {
      blocks.push({ type: 'p', text });
    }
  }

  return blocks;
}

/* ---------- les fiches ---------- */

export function mapCountry(r: Raw): Country {
  return {
    slug: str(r.slug),
    name: loc(r.name),
    iso: str(r.iso).toUpperCase(),
    flag: '',
    intro: loc(r.intro),
    image: img(r.image),
  };
}

export function mapVillage(r: Raw): Village {
  return {
    slug: str(r.slug),
    name: str(r.name),
    country: str(r.country),
    region: loc(r.region),
    lat: num(r.lat),
    lng: num(r.lng),
    summary: loc(r.summary),
    description: loc(r.description),
    languages: Array.isArray(r.languages) ? (r.languages as string[]).filter(Boolean) : [],
    filmed: r.filmed === true,
    image: img(r.image),
    gallery: Array.isArray(r.gallery)
      ? (r.gallery as unknown[]).map(img).filter((x): x is ImageRef => Boolean(x))
      : undefined,
  };
}

export function mapVideo(r: Raw): Video {
  return {
    slug: str(r.slug),
    youtubeId: typeof r.youtubeId === 'string' && r.youtubeId ? r.youtubeId : null,
    title: loc(r.title),
    category: loc(r.category),
    categoryKey: (str(r.categoryKey, 'documentary') as VideoCategoryKey) ?? 'documentary',
    country: str(r.country),
    village: str(r.village) || undefined,
    durationSeconds: num(r.durationSeconds),
    publishedAt: str(r.publishedAt),
    format: r.format === 'short' ? 'short' : 'film',
    image: img(r.image),
  };
}

export function mapArticle(r: Raw): Article {
  const en = toBlocks(r.bodyEn);
  const fr = toBlocks(r.bodyFr);
  return {
    slug: str(r.slug),
    title: loc(r.title),
    standfirst: loc(r.standfirst),
    category: loc(r.category),
    categorySlug: str(r.categorySlug),
    country: str(r.country),
    village: str(r.village) || undefined,
    author: str(r.author),
    publishedAt: str(r.publishedAt),
    readingMinutes: num(r.readingMinutes, 5),
    featured: r.featured === true,
    body: { en, fr: fr.length ? fr : en },
    image: img(r.image),
  };
}

export function mapRecipe(r: Raw): Recipe {
  return {
    slug: str(r.slug),
    name: loc(r.name),
    country: str(r.country),
    region: loc(r.region),
    summary: loc(r.summary),
    minutes: num(r.minutes),
    serves: num(r.serves, 4),
    ingredients: locList(r.ingredients),
    steps: locList(r.steps),
    story: loc(r.story),
    image: img(r.image),
  };
}

export function mapLanguage(r: Raw): Language {
  return {
    slug: str(r.slug),
    name: str(r.name),
    speakers: loc(r.speakers),
    description: loc(r.description),
    region: loc(r.region),
  };
}

export function mapWord(r: Raw): Word {
  return {
    slug: str(r.slug),
    word: str(r.word),
    language: str(r.language),
    pronunciation: str(r.pronunciation),
    audioUrl: str(r.audioUrl) || undefined,
    meaning: loc(r.meaning),
    example: loc(r.example),
    exampleTranslation: loc(r.exampleTranslation),
    region: loc(r.region),
  };
}

export function mapCultureTheme(r: Raw): CultureTheme {
  return {
    slug: str(r.slug),
    name: loc(r.name),
    description: loc(r.description),
    image: img(r.image),
  };
}

export function mapAuthor(r: Raw): Author {
  return {
    slug: str(r.slug),
    name: str(r.name),
    role: loc(r.role),
    bio: loc(r.bio),
    image: img(r.image),
  };
}
