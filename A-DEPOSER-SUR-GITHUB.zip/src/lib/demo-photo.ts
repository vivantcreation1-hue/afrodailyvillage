/**
 * Générateur de visuels de démonstration.
 *
 * Tant qu'Afro Daily Village n'a pas ses propres photos, le site affiche des
 * paysages de village dessinés en silhouette, dans les couleurs du logo.
 * Ils sont toujours identifiés comme des visuels de démonstration : on ne fait
 * jamais passer une image inventée pour un vrai reportage.
 *
 * Chaque visuel est déterministe : la même clé donne toujours la même image,
 * donc rien ne « saute » entre le serveur et le navigateur.
 */

export type DemoMood = 'dawn' | 'noon' | 'dusk' | 'night' | 'fire';

export interface DemoScene {
  mood: DemoMood;
  sky: [string, string];
  sun: string;
  sunY: number;
  sunX: number;
  ridges: { color: string; points: string }[];
  trees: { x: number; scale: number; color: string }[];
  huts: { x: number; scale: number; color: string }[];
  ground: string;
  haze: string;
}

const PALETTES: Record<
  DemoMood,
  { sky: [string, string]; sun: string; ridge: string[]; ground: string; haze: string }
> = {
  dawn: {
    sky: ['#2A1B10', '#E8A63C'],
    sun: '#FFD089',
    ridge: ['#5A3E22', '#3A2715', '#241709'],
    ground: '#1A1108',
    haze: '#E8A63C',
  },
  noon: {
    sky: ['#8A6A38', '#E8CE96'],
    sun: '#FFF2D2',
    ridge: ['#6B5227', '#463317', '#2A1D0C'],
    ground: '#1F1508',
    haze: '#E8CE96',
  },
  dusk: {
    sky: ['#1C1008', '#D97A1E'],
    sun: '#FFB55E',
    ridge: ['#59341A', '#3A2010', '#210F07'],
    ground: '#160C05',
    haze: '#D97A1E',
  },
  night: {
    sky: ['#080A10', '#2A2418'],
    sun: '#C9BE9A',
    ridge: ['#231D14', '#171208', '#0D0A06'],
    ground: '#0B0805',
    haze: '#3A3020',
  },
  fire: {
    sky: ['#150A04', '#C9552A'],
    sun: '#FFA24A',
    ridge: ['#5C2711', '#39170A', '#1E0C05'],
    ground: '#140803',
    haze: '#C9552A',
  },
};

// mulberry32 — petit générateur pseudo-aléatoire, stable et sans dépendance
function makeRandom(seed: string) {
  let h = 1779033703 ^ seed.length;
  for (let i = 0; i < seed.length; i++) {
    h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  let a = h >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function ridgePath(rnd: () => number, baseY: number, amplitude: number): string {
  const points: string[] = ['0,100'];
  const steps = 7;
  for (let i = 0; i <= steps; i++) {
    const x = (i / steps) * 100;
    const y = baseY + (rnd() - 0.5) * amplitude;
    points.push(`${x.toFixed(2)},${y.toFixed(2)}`);
  }
  points.push('100,100');
  return points.join(' ');
}

export function buildScene(seed: string, forced?: DemoMood): DemoScene {
  const rnd = makeRandom(seed);
  const moods: DemoMood[] = ['dawn', 'noon', 'dusk', 'night', 'fire'];
  const mood = forced ?? moods[Math.floor(rnd() * moods.length)];
  const p = PALETTES[mood];

  const ridges = p.ridge.map((color, i) => ({
    color,
    points: ridgePath(rnd, 52 + i * 11, 9 - i * 2),
  }));

  const treeCount = 2 + Math.floor(rnd() * 3);
  const trees = Array.from({ length: treeCount }, () => ({
    x: 6 + rnd() * 88,
    scale: 0.55 + rnd() * 0.75,
    color: p.ridge[2],
  })).sort((a, b) => a.scale - b.scale);

  const hutCount = 1 + Math.floor(rnd() * 3);
  const huts = Array.from({ length: hutCount }, () => ({
    x: 8 + rnd() * 84,
    scale: 0.5 + rnd() * 0.6,
    color: p.ridge[2],
  }));

  return {
    mood,
    sky: p.sky,
    sun: mood === 'dusk' ? '#FFB55E' : p.sun,
    sunX: 18 + rnd() * 64,
    sunY: 26 + rnd() * 22,
    ridges,
    trees,
    huts,
    ground: p.ground,
    haze: p.haze,
  };
}
