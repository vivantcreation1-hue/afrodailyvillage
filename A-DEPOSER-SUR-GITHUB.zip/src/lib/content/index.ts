import type { Locale } from '@/i18n/routing';
import * as demo from './demo-data';
import type { DemoArticle } from './demo-data';
import { sanityEnabled } from '@/sanity/env';
import { sanityFetch } from '@/lib/sanity/client';
import { Q } from '@/lib/sanity/queries';
import {
  mapArticle,
  mapAuthor,
  mapCountry,
  mapCultureTheme,
  mapLanguage,
  mapRecipe,
  mapVideo,
  mapVillage,
  mapWord,
} from '@/lib/sanity/map';
import type {
  Article,
  Author,
  Block,
  Country,
  CultureTheme,
  Language,
  Localized,
  Recipe,
  Video,
  VideoCategoryKey,
  Village,
  Word,
} from './types';

export * from './types';

/**
 * COUCHE D'ACCÈS AU CONTENU
 *
 * Tout le site passe par ces fonctions — jamais directement par les données.
 *
 * Chacune suit la même règle :
 *   1. si le tableau de bord est branché ET contient quelque chose → on l'utilise ;
 *   2. sinon → contenu de démonstration.
 *
 * Conséquence : le site ne tombe jamais en panne, même si Sanity est
 * indisponible, et il bascule tout seul dès que vous publiez votre
 * première fiche.
 */

type Raw = Record<string, unknown>;

async function list<T>(
  query: string,
  map: (r: Raw) => T,
  fallback: T[],
  params: Record<string, unknown> = {},
): Promise<T[]> {
  if (!sanityEnabled) return fallback;
  const raw = await sanityFetch<Raw[] | null>(query, params, null);
  if (!raw || raw.length === 0) return fallback;
  return raw.map(map);
}

async function one<T>(
  query: string,
  map: (r: Raw) => T,
  fallback: T | undefined,
  params: Record<string, unknown> = {},
): Promise<T | undefined> {
  if (!sanityEnabled) return fallback;
  const raw = await sanityFetch<Raw | null>(query, params, null);
  if (!raw) return fallback;
  return map(raw);
}

/** Le contenu de démonstration écrit les articles en bilingue : on les remet en forme. */
function fromDemoArticle(a: DemoArticle): Article {
  const split = (locale: Locale): Block[] =>
    a.body.map((b) => {
      switch (b.type) {
        case 'image':
          return { type: 'image' as const, seed: b.seed, caption: b.caption[locale] };
        case 'quote':
          return {
            type: 'quote' as const,
            text: b.text[locale],
            by: b.by ? b.by[locale] : undefined,
          };
        case 'h2':
          return { type: 'h2' as const, text: b.text[locale] };
        default:
          return { type: 'p' as const, text: b.text[locale] };
      }
    });

  return { ...a, body: { en: split('en'), fr: split('fr') } };
}

const demoArticles: Article[] = demo.articles.map(fromDemoArticle);

const byDateDesc = <T extends { publishedAt: string }>(a: T, b: T) =>
  b.publishedAt.localeCompare(a.publishedAt);

/** Vrai tant que le site tourne encore entièrement sur le contenu provisoire. */
export async function isDemoContent(): Promise<boolean> {
  if (!sanityEnabled) return true;
  const raw = await sanityFetch<Raw[] | null>(Q.articles, {}, null);
  return !raw || raw.length === 0;
}

/* ---------- vidéos ---------- */

export async function getAllVideos(): Promise<Video[]> {
  const videos = await list(Q.videos, mapVideo, demo.videos);
  return [...videos].sort(byDateDesc);
}

export async function getLatestVideos(limit = 6): Promise<Video[]> {
  return (await getAllVideos()).slice(0, limit);
}

export async function getVideos(category: VideoCategoryKey = 'all'): Promise<Video[]> {
  const all = await getAllVideos();
  if (category === 'all') return all;
  if (category === 'shorts') return all.filter((v) => v.format === 'short');
  return all.filter((v) => v.categoryKey === category);
}

export async function getVideoCounts(): Promise<Record<VideoCategoryKey, number>> {
  const all = await getAllVideos();
  return {
    all: all.length,
    documentary: all.filter((v) => v.categoryKey === 'documentary').length,
    dailyLife: all.filter((v) => v.categoryKey === 'dailyLife').length,
    food: all.filter((v) => v.categoryKey === 'food').length,
    culture: all.filter((v) => v.categoryKey === 'culture').length,
    traditions: all.filter((v) => v.categoryKey === 'traditions').length,
    interviews: all.filter((v) => v.categoryKey === 'interviews').length,
    shorts: all.filter((v) => v.format === 'short').length,
  };
}

export async function getVideosByVillage(slug: string): Promise<Video[]> {
  const fallback = demo.videos.filter((v) => v.village === slug).sort(byDateDesc);
  return list(Q.videosByVillage, mapVideo, fallback, { slug });
}

export async function getVideosByCountry(slug: string): Promise<Video[]> {
  const fallback = demo.videos.filter((v) => v.country === slug).sort(byDateDesc);
  return list(Q.videosByCountry, mapVideo, fallback, { slug });
}

/* ---------- articles ---------- */

export async function getAllArticles(): Promise<Article[]> {
  const articles = await list(Q.articles, mapArticle, demoArticles);
  return [...articles].sort(byDateDesc);
}

export async function getLatestArticles(limit = 6): Promise<Article[]> {
  return (await getAllArticles()).slice(0, limit);
}

export async function getFeaturedArticle(): Promise<Article | null> {
  const fallback = demoArticles.find((a) => a.featured) ?? demoArticles[0];
  const found = await one(Q.featuredArticle, mapArticle, fallback);
  return found ?? null;
}

export async function getArticle(slug: string): Promise<Article | undefined> {
  const fallback = demoArticles.find((a) => a.slug === slug);
  return one(Q.articleBySlug, mapArticle, fallback, { slug });
}

export async function getArticleSlugs(): Promise<string[]> {
  return (await getAllArticles()).map((a) => a.slug);
}

export async function getRelatedArticles(article: Article, limit = 3): Promise<Article[]> {
  const all = await getAllArticles();
  const others = all.filter((a) => a.slug !== article.slug);
  const sameCountry = others.filter((a) => a.country === article.country);
  const rest = others.filter((a) => a.country !== article.country);
  return [...sameCountry, ...rest].slice(0, limit);
}

export async function getArticlesByVillage(slug: string): Promise<Article[]> {
  const fallback = demoArticles.filter((a) => a.village === slug).sort(byDateDesc);
  return list(Q.articlesByVillage, mapArticle, fallback, { slug });
}

export async function getArticlesByCountry(slug: string): Promise<Article[]> {
  const fallback = demoArticles.filter((a) => a.country === slug).sort(byDateDesc);
  return list(Q.articlesByCountry, mapArticle, fallback, { slug });
}

/* ---------- villages et pays ---------- */

export async function getVillages(): Promise<Village[]> {
  return list(Q.villages, mapVillage, demo.villages);
}

export async function getVillage(slug: string): Promise<Village | undefined> {
  const fallback = demo.villages.find((v) => v.slug === slug);
  return one(Q.villageBySlug, mapVillage, fallback, { slug });
}

export async function getVillageSlugs(): Promise<string[]> {
  return (await getVillages()).map((v) => v.slug);
}

export async function getVillagesByCountry(slug: string): Promise<Village[]> {
  const fallback = demo.villages.filter((v) => v.country === slug);
  return list(Q.villagesByCountry, mapVillage, fallback, { slug });
}

export async function getCountries(): Promise<Country[]> {
  return list(Q.countries, mapCountry, demo.countries);
}

export async function getCountry(slug: string): Promise<Country | undefined> {
  const fallback = demo.countries.find((c) => c.slug === slug);
  return one(Q.countryBySlug, mapCountry, fallback, { slug });
}

export async function getCountrySlugs(): Promise<string[]> {
  return (await getCountries()).map((c) => c.slug);
}

/* ---------- cuisine ---------- */

export async function getRecipes(limit?: number): Promise<Recipe[]> {
  const recipes = await list(Q.recipes, mapRecipe, demo.recipes);
  return limit ? recipes.slice(0, limit) : recipes;
}

export async function getRecipe(slug: string): Promise<Recipe | undefined> {
  const fallback = demo.recipes.find((r) => r.slug === slug);
  return one(Q.recipeBySlug, mapRecipe, fallback, { slug });
}

export async function getRecipeSlugs(): Promise<string[]> {
  return (await getRecipes()).map((r) => r.slug);
}

export async function getRecipesByCountry(slug: string): Promise<Recipe[]> {
  const fallback = demo.recipes.filter((r) => r.country === slug);
  return list(Q.recipesByCountry, mapRecipe, fallback, { slug });
}

/* ---------- langues ---------- */

export async function getLanguages(): Promise<Language[]> {
  return list(Q.languages, mapLanguage, demo.languages);
}

export async function getLanguage(slug: string): Promise<Language | undefined> {
  const fallback = demo.languages.find((l) => l.slug === slug);
  return one(Q.languageBySlug, mapLanguage, fallback, { slug });
}

export async function getLanguageSlugs(): Promise<string[]> {
  return (await getLanguages()).map((l) => l.slug);
}

export async function getWords(languageSlug?: string): Promise<Word[]> {
  if (languageSlug) {
    const fallback = demo.words.filter((w) => w.language === languageSlug);
    return list(Q.wordsByLanguage, mapWord, fallback, { slug: languageSlug });
  }
  return list(Q.words, mapWord, demo.words);
}

/** Un mot différent chaque jour, mais le même pour tout le monde ce jour-là. */
export async function getWordOfTheDay(): Promise<Word> {
  const words = await getWords();
  const dayIndex = Math.floor(Date.now() / 86_400_000);
  return words[dayIndex % words.length];
}

/* ---------- culture ---------- */

export async function getCultureThemes(): Promise<CultureTheme[]> {
  return list(Q.cultureThemes, mapCultureTheme, demo.cultureThemes);
}

export async function getCultureTheme(slug: string): Promise<CultureTheme | undefined> {
  const fallback = demo.cultureThemes.find((c) => c.slug === slug);
  return one(Q.cultureThemeBySlug, mapCultureTheme, fallback, { slug });
}

export async function getCultureThemeSlugs(): Promise<string[]> {
  return (await getCultureThemes()).map((c) => c.slug);
}

/* ---------- auteurs et chiffres ---------- */

export async function getAuthor(slug: string): Promise<Author | undefined> {
  if (!slug) return undefined;
  const fallback = demo.authors.find((a) => a.slug === slug);
  return one(Q.authorBySlug, mapAuthor, fallback, { slug });
}

export async function getStats() {
  const [villages, videos] = await Promise.all([getVillages(), getAllVideos()]);
  return {
    villages: villages.filter((v) => v.filmed).length,
    countries: new Set(villages.map((v) => v.country)).size,
    films: videos.filter((v) => v.format === 'film').length,
  };
}

/* ---------- recherche ---------- */

export type SearchHit = {
  kind: 'article' | 'video' | 'village' | 'recipe' | 'word';
  slug: string;
  title: string;
  excerpt: string;
};

export async function search(query: string, locale: Locale): Promise<SearchHit[]> {
  const q = query.trim().toLowerCase();
  if (q.length < 2) return [];

  const [articles, videos, villages, recipes, words] = await Promise.all([
    getAllArticles(),
    getAllVideos(),
    getVillages(),
    getRecipes(),
    getWords(),
  ]);

  const matches = (...fields: (string | undefined)[]) =>
    fields.some((f) => f?.toLowerCase().includes(q));

  const hits: SearchHit[] = [];

  for (const a of articles) {
    if (matches(a.title[locale], a.standfirst[locale], a.category[locale]))
      hits.push({ kind: 'article', slug: a.slug, title: a.title[locale], excerpt: a.standfirst[locale] });
  }
  for (const v of videos) {
    if (matches(v.title[locale], v.category[locale]))
      hits.push({ kind: 'video', slug: v.slug, title: v.title[locale], excerpt: v.category[locale] });
  }
  for (const v of villages) {
    if (matches(v.name, v.region[locale], v.summary[locale]))
      hits.push({ kind: 'village', slug: v.slug, title: v.name, excerpt: v.summary[locale] });
  }
  for (const r of recipes) {
    if (matches(r.name[locale], r.summary[locale]))
      hits.push({ kind: 'recipe', slug: r.slug, title: r.name[locale], excerpt: r.summary[locale] });
  }
  for (const w of words) {
    if (matches(w.word, w.meaning[locale], w.language))
      hits.push({ kind: 'word', slug: w.slug, title: w.word, excerpt: w.meaning[locale] });
  }

  return hits;
}

/* ---------- petits utilitaires d'affichage ---------- */

export function pick<T>(value: Localized<T>, locale: Locale): T {
  return value[locale];
}

export function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function formatDate(iso: string, locale: Locale): string {
  if (!iso) return '';
  return new Intl.DateTimeFormat(locale === 'fr' ? 'fr-FR' : 'en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(new Date(`${iso.slice(0, 10)}T00:00:00Z`));
}
