import type { Locale } from '@/i18n/routing';

/** Un texte qui existe dans les deux langues. */
export type Localized<T = string> = Record<Locale, T>;

/**
 * Une vraie photo, venue du tableau de bord.
 * Quand ce champ est absent, le site affiche un visuel de démonstration
 * à la place — c'est ce qui permet de remplacer une image en dix secondes.
 */
export interface ImageRef {
  url: string;
  alt?: string;
  /** Aperçu flou minuscule, affiché pendant le chargement. */
  lqip?: string;
}

export interface Author {
  slug: string;
  name: string;
  role: Localized;
  bio: Localized;
  image?: ImageRef;
}

export interface Country {
  slug: string;
  name: Localized;
  flag: string;
  iso: string;
  intro: Localized;
  image?: ImageRef;
}

export interface Village {
  slug: string;
  name: string;
  country: string;
  region: Localized;
  /** Position sur la carte, en degrés décimaux. */
  lat: number;
  lng: number;
  summary: Localized;
  description: Localized;
  languages: string[];
  filmed: boolean;
  image?: ImageRef;
  gallery?: ImageRef[];
}

export interface Video {
  slug: string;
  youtubeId: string | null;
  title: Localized;
  category: Localized;
  /** Clé stable utilisée par les filtres de la page /videos. */
  categoryKey: VideoCategoryKey;
  country: string;
  village?: string;
  durationSeconds: number;
  publishedAt: string;
  format: 'film' | 'short';
  image?: ImageRef;
}

export const VIDEO_CATEGORIES = [
  'all',
  'documentary',
  'dailyLife',
  'food',
  'culture',
  'traditions',
  'interviews',
  'shorts',
] as const;

export type VideoCategoryKey = (typeof VIDEO_CATEGORIES)[number];

/**
 * Les briques dont un article est fait, dans UNE langue.
 * Le corps d'un article est donc `Localized<Block[]>` : une liste de briques
 * par langue. C'est exactement la forme que renvoie Sanity, où le texte
 * anglais et le texte français sont deux champs indépendants.
 */
export type Block =
  | { type: 'p'; text: string }
  | { type: 'h2'; text: string }
  | { type: 'quote'; text: string; by?: string }
  | { type: 'image'; seed?: string; image?: ImageRef; caption: string };

/** Forme d'écriture du contenu de démonstration : les deux langues côte à côte. */
export type BilingualBlock =
  | { type: 'p'; text: Localized }
  | { type: 'h2'; text: Localized }
  | { type: 'quote'; text: Localized; by?: Localized }
  | { type: 'image'; seed?: string; caption: Localized };

export interface Article {
  slug: string;
  title: Localized;
  standfirst: Localized;
  category: Localized;
  categorySlug: string;
  country: string;
  village?: string;
  author: string;
  publishedAt: string;
  readingMinutes: number;
  featured?: boolean;
  body: Localized<Block[]>;
  image?: ImageRef;
}

export interface Recipe {
  slug: string;
  name: Localized;
  country: string;
  region: Localized;
  summary: Localized;
  minutes: number;
  serves: number;
  image?: ImageRef;
  ingredients: Localized<string[]>;
  steps: Localized<string[]>;
  story: Localized;
}

export interface Language {
  slug: string;
  name: string;
  speakers: Localized;
  description: Localized;
  region: Localized;
}

export interface Word {
  slug: string;
  word: string;
  language: string;
  pronunciation: string;
  /** Enregistrement de la prononciation, quand il existe. */
  audioUrl?: string;
  meaning: Localized;
  example: Localized;
  exampleTranslation: Localized;
  region: Localized;
}

export interface CultureTheme {
  slug: string;
  name: Localized;
  description: Localized;
  image?: ImageRef;
}
