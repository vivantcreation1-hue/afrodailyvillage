import type {
  Article,
  BilingualBlock,
  Author,
  Country,
  CultureTheme,
  Language,
  Recipe,
  Video,
  Village,
  Word,
} from './types';

/**
 * ⚠️ CONTENU DE DÉMONSTRATION ⚠️
 *
 * Rien ici n'est un vrai reportage. Ce sont des fiches provisoires qui servent
 * uniquement à tester le design tant que les vrais tournages n'ont pas eu lieu.
 * Les lieux et les langues sont réels — la région de Kolda, le marché de Diaobé,
 * le pulaar, le mandinka — mais les récits, les personnes, les durées et les
 * dates sont inventés.
 *
 * Tout ce fichier disparaîtra quand le CMS Sanity prendra le relais (phase 5).
 */

export const IS_DEMO = true;

/* ============================================================
   PAYS
   ============================================================ */

export const countries: Country[] = [
  {
    slug: 'senegal',
    iso: 'SN',
    flag: '🇸🇳',
    name: { en: 'Senegal', fr: 'Sénégal' },
    intro: {
      en: 'Our home base. Most of what we film happens in Haute-Casamance, the southern region around Kolda.',
      fr: 'Notre base. L’essentiel de ce que nous filmons se passe en Haute-Casamance, la région du Sud autour de Kolda.',
    },
  },
  {
    slug: 'gambia',
    iso: 'GM',
    flag: '🇬🇲',
    name: { en: 'The Gambia', fr: 'Gambie' },
    intro: {
      en: 'A country shaped by a single river. Crossing it is still an event, and the ferry sets the pace.',
      fr: 'Un pays dessiné par un seul fleuve. Le traverser reste un événement, et le bac donne le rythme.',
    },
  },
  {
    slug: 'guinea-bissau',
    iso: 'GW',
    flag: '🇬🇼',
    name: { en: 'Guinea-Bissau', fr: 'Guinée-Bissau' },
    intro: {
      en: 'South of Kolda, past the border. The old Kaabu kingdom left its songs and its family names here.',
      fr: 'Au sud de Kolda, passé la frontière. L’ancien royaume du Kaabu y a laissé ses chants et ses noms de famille.',
    },
  },
  {
    slug: 'guinea',
    iso: 'GN',
    flag: '🇬🇳',
    name: { en: 'Guinea', fr: 'Guinée' },
    intro: {
      en: 'The highlands where the rivers start. We are only beginning to film there.',
      fr: 'Les hauteurs où naissent les fleuves. Nous commençons tout juste à y filmer.',
    },
  },
  {
    slug: 'mali',
    iso: 'ML',
    flag: '🇲🇱',
    name: { en: 'Mali', fr: 'Mali' },
    intro: {
      en: 'Further inland, where the Mandé world begins. On our road map, not yet on our footage.',
      fr: 'Plus loin dans les terres, là où commence le monde mandé. Sur notre feuille de route, pas encore dans nos rushes.',
    },
  },
];

/* ============================================================
   AUTEURS
   ============================================================ */

export const authors: Author[] = [
  {
    slug: 'amadou',
    name: 'Amadou',
    role: { en: 'Field reporter', fr: 'Reporter de terrain' },
    bio: {
      en: 'Films and writes from the road. Travels between Senegal, The Gambia, Guinea-Bissau and Mali, and brings back what he finds.',
      fr: 'Filme et écrit depuis la route. Circule entre le Sénégal, la Gambie, la Guinée-Bissau et le Mali, et rapporte ce qu’il y trouve.',
    },
  },
  {
    slug: 'adv-desk',
    name: 'Afro Daily Village',
    role: { en: 'Editorial desk', fr: 'Rédaction' },
    bio: {
      en: 'The team that edits, translates and checks everything published here.',
      fr: 'L’équipe qui édite, traduit et vérifie tout ce qui est publié ici.',
    },
  },
];

/* ============================================================
   VILLAGES
   ============================================================ */

export const villages: Village[] = [
  {
    slug: 'kolda',
    name: 'Kolda',
    country: 'senegal',
    region: { en: 'Upper Casamance', fr: 'Haute-Casamance' },
    lat: 12.883,
    lng: -14.95,
    summary: {
      en: 'Our base. The town on the Casamance river where every road out of the region begins.',
      fr: 'Notre base. La ville sur le fleuve Casamance d’où part chaque route de la région.',
    },
    description: {
      en: 'Kolda is not a village but the town every village around it depends on: the hospital, the secondary school, the bus station, the weekly bank queue. Most of our films begin here at six in the morning, in a shared taxi that will not leave until the last seat is sold.',
      fr: 'Kolda n’est pas un village, mais la ville dont dépendent tous les villages autour : l’hôpital, le lycée, la gare routière, la file d’attente hebdomadaire à la banque. La plupart de nos films commencent ici à six heures du matin, dans un taxi collectif qui ne partira pas avant que la dernière place soit vendue.',
    },
    languages: ['pulaar', 'mandinka', 'wolof'],
    filmed: true,
  },
  {
    slug: 'diaobe',
    name: 'Diaobé',
    country: 'senegal',
    region: { en: 'Upper Casamance', fr: 'Haute-Casamance' },
    lat: 12.746,
    lng: -14.379,
    summary: {
      en: 'One of the largest weekly markets in West Africa. Traders arrive from four countries before dawn.',
      fr: 'L’un des plus grands marchés hebdomadaires d’Afrique de l’Ouest. Les commerçants arrivent de quatre pays avant l’aube.',
    },
    description: {
      en: 'Six days a week Diaobé is a quiet roadside town. On the seventh it becomes one of the biggest markets in the sub-region: trucks from Guinea, Mali and The Gambia unload in the dark, and by mid-morning you can buy anything from a live goat to a phone charger.',
      fr: 'Six jours sur sept, Diaobé est une petite ville tranquille au bord de la route. Le septième, elle devient l’un des plus grands marchés de la sous-région : les camions de Guinée, du Mali et de Gambie déchargent dans le noir, et en milieu de matinée on y trouve aussi bien une chèvre vivante qu’un chargeur de téléphone.',
    },
    languages: ['pulaar', 'mandinka'],
    filmed: true,
  },
  {
    slug: 'sare-yoba-diega',
    name: 'Saré Yoba Diéga',
    country: 'senegal',
    region: { en: 'Upper Casamance', fr: 'Haute-Casamance' },
    lat: 12.94,
    lng: -14.62,
    summary: {
      en: 'A Fulani farming village where the day is measured by the herd, not the clock.',
      fr: 'Un village peul d’agriculteurs où la journée se mesure au troupeau, pas à l’horloge.',
    },
    description: {
      en: 'Around two hundred households, groundnuts and millet in the fields, cattle on the move at first light. The name means "the compound of Yoba" — most villages here are named after whoever settled first.',
      fr: 'Environ deux cents foyers, de l’arachide et du mil dans les champs, le bétail en mouvement dès les premières lueurs. Le nom signifie « la concession de Yoba » — la plupart des villages d’ici portent le nom de celui qui s’y est installé le premier.',
    },
    languages: ['pulaar'],
    filmed: true,
  },
  {
    slug: 'velingara',
    name: 'Vélingara',
    country: 'senegal',
    region: { en: 'Upper Casamance', fr: 'Haute-Casamance' },
    lat: 13.15,
    lng: -14.117,
    summary: {
      en: 'The last Senegalese town before the Guinean border — and the first stop for everything crossing it.',
      fr: 'La dernière ville sénégalaise avant la frontière guinéenne — et le premier arrêt de tout ce qui la traverse.',
    },
    description: {
      en: 'A border town, with everything that implies: three currencies in the same pocket, four languages in the same conversation, and a customs post that everybody knows how to talk to.',
      fr: 'Une ville frontière, avec tout ce que cela suppose : trois monnaies dans la même poche, quatre langues dans la même conversation, et un poste de douane auquel tout le monde sait parler.',
    },
    languages: ['pulaar', 'mandinka'],
    filmed: true,
  },
  {
    slug: 'basse-santa-su',
    name: 'Basse Santa Su',
    country: 'gambia',
    region: { en: 'Upper River Division', fr: 'Upper River Division' },
    lat: 13.309,
    lng: -14.215,
    summary: {
      en: 'Where the Gambia river narrows and the ferry still decides what time you arrive.',
      fr: 'Là où le fleuve Gambie se resserre et où le bac décide encore de votre heure d’arrivée.',
    },
    description: {
      en: 'The furthest town upriver that river boats used to reach. Today it is the commercial heart of eastern Gambia, and the place where our Senegalese crew stops speaking French and starts speaking English.',
      fr: 'La ville la plus en amont que les bateaux fluviaux atteignaient autrefois. C’est aujourd’hui le cœur commercial de la Gambie orientale, et l’endroit où notre équipe sénégalaise cesse de parler français pour parler anglais.',
    },
    languages: ['mandinka', 'pulaar'],
    filmed: false,
  },
  {
    slug: 'gabu',
    name: 'Gabú',
    country: 'guinea-bissau',
    region: { en: 'Gabú region', fr: 'Région de Gabú' },
    lat: 12.28,
    lng: -14.223,
    summary: {
      en: 'The old capital of the Kaabu kingdom. The stories here are older than the borders.',
      fr: 'L’ancienne capitale du royaume du Kaabu. Ici, les histoires sont plus vieilles que les frontières.',
    },
    description: {
      en: 'Kaabu was a Mandinka kingdom that ended in the nineteenth century, long before Senegal, Guinea-Bissau and The Gambia existed as countries. Its family names, its songs and its griot lineages did not stop at the lines drawn afterwards.',
      fr: 'Le Kaabu était un royaume mandingue qui s’est éteint au XIXᵉ siècle, bien avant que le Sénégal, la Guinée-Bissau et la Gambie n’existent comme pays. Ses noms de famille, ses chants et ses lignées de griots ne se sont pas arrêtés aux lignes tracées après.',
    },
    languages: ['pulaar', 'mandinka'],
    filmed: false,
  },
];

/* ============================================================
   VIDÉOS
   ============================================================ */

export const videos: Video[] = [
  {
    slug: 'a-day-in-sare-yoba',
    youtubeId: null,
    title: {
      en: 'Five in the morning in Saré Yoba Diéga',
      fr: 'Cinq heures du matin à Saré Yoba Diéga',
    },
    category: { en: 'Documentary', fr: 'Documentaire' },
    categoryKey: 'documentary',
    country: 'senegal',
    village: 'sare-yoba-diega',
    durationSeconds: 754,
    publishedAt: '2026-09-05',
    format: 'film',
  },
  {
    slug: 'diaobe-market',
    youtubeId: null,
    title: {
      en: 'Diaobé: the market that wakes four countries',
      fr: 'Diaobé : le marché qui réveille quatre pays',
    },
    category: { en: 'Daily life', fr: 'Vie quotidienne' },
    categoryKey: 'dailyLife',
    country: 'senegal',
    village: 'diaobe',
    durationSeconds: 1102,
    publishedAt: '2026-08-29',
    format: 'film',
  },
  {
    slug: 'thieboudienne-fire',
    youtubeId: null,
    title: { en: 'One pot, three hours, twelve people', fr: 'Une marmite, trois heures, douze personnes' },
    category: { en: 'Food', fr: 'Cuisine' },
    categoryKey: 'food',
    country: 'senegal',
    village: 'kolda',
    durationSeconds: 628,
    publishedAt: '2026-08-22',
    format: 'film',
  },
  {
    slug: 'pulaar-greetings',
    youtubeId: null,
    title: { en: 'How to greet someone in Pulaar', fr: 'Comment saluer en pulaar' },
    category: { en: 'Languages', fr: 'Langues' },
    categoryKey: 'shorts',
    country: 'senegal',
    durationSeconds: 47,
    publishedAt: '2026-09-09',
    format: 'short',
  },
  {
    slug: 'weaving-kolda',
    youtubeId: null,
    title: { en: 'The last weavers of Kolda', fr: 'Les derniers tisserands de Kolda' },
    category: { en: 'Crafts', fr: 'Artisanat' },
    categoryKey: 'culture',
    country: 'senegal',
    village: 'kolda',
    durationSeconds: 892,
    publishedAt: '2026-08-15',
    format: 'film',
  },
  {
    slug: 'crossing-to-gabu',
    youtubeId: null,
    title: { en: 'The road to Gabú', fr: 'La route de Gabú' },
    category: { en: 'Travel', fr: 'Voyage' },
    categoryKey: 'documentary',
    country: 'guinea-bissau',
    village: 'gabu',
    durationSeconds: 1341,
    publishedAt: '2026-08-08',
    format: 'film',
  },
  {
    slug: 'griot-of-gabu',
    youtubeId: null,
    title: { en: 'A griot names eleven generations', fr: 'Un griot énumère onze générations' },
    category: { en: 'Traditions', fr: 'Traditions' },
    categoryKey: 'traditions',
    country: 'guinea-bissau',
    village: 'gabu',
    durationSeconds: 1015,
    publishedAt: '2026-08-01',
    format: 'film',
  },
  {
    slug: 'interview-rice-women',
    youtubeId: null,
    title: {
      en: '"We rebuilt the dykes with our hands" — Fatoumata, rice farmer',
      fr: '« Nous avons relevé les diguettes à la main » — Fatoumata, riziculture',
    },
    category: { en: 'Interview', fr: 'Interview' },
    categoryKey: 'interviews',
    country: 'senegal',
    village: 'kolda',
    durationSeconds: 743,
    publishedAt: '2026-07-25',
    format: 'film',
  },
  {
    slug: 'market-in-60-seconds',
    youtubeId: null,
    title: { en: 'Diaobé market in 60 seconds', fr: 'Le marché de Diaobé en 60 secondes' },
    category: { en: 'Daily life', fr: 'Vie quotidienne' },
    categoryKey: 'shorts',
    country: 'senegal',
    village: 'diaobe',
    durationSeconds: 58,
    publishedAt: '2026-09-02',
    format: 'short',
  },
];

/* ============================================================
   ARTICLES
   ============================================================ */

/** Un article de démonstration : comme un vrai, mais avec le corps écrit en bilingue. */
export type DemoArticle = Omit<Article, 'body'> & { body: BilingualBlock[] };

export const articles: DemoArticle[] = [
  {
    slug: 'the-woman-who-decides-breakfast',
    title: {
      en: 'The woman who decides when the village eats',
      fr: 'La femme qui décide quand le village mange',
    },
    standfirst: {
      en: 'At five in the morning, Aïssatou lights the fire before anyone is awake. Nobody argues with the time she sets.',
      fr: 'À cinq heures du matin, Aïssatou allume le feu avant que le village ne se réveille. Personne ne discute l’heure qu’elle décide.',
    },
    category: { en: 'Portrait', fr: 'Portrait' },
    categorySlug: 'portrait',
    country: 'senegal',
    village: 'sare-yoba-diega',
    author: 'amadou',
    publishedAt: '2026-09-06',
    readingMinutes: 8,
    featured: true,
    body: [
      {
        type: 'p',
        text: {
          en: 'The first sound in Saré Yoba Diéga is not a rooster. It is a match, then a breath, then wood catching. Aïssatou has been doing this for nineteen years and she no longer needs light to do it.',
          fr: 'Le premier bruit de Saré Yoba Diéga n’est pas un coq. C’est une allumette, puis un souffle, puis le bois qui prend. Aïssatou fait cela depuis dix-neuf ans et n’a plus besoin de lumière pour le faire.',
        },
      },
      {
        type: 'p',
        text: {
          en: 'By the time the sky turns grey, the water is hot and the millet is soaking. Nobody has told her to start. There is no schedule pinned anywhere. But if she started an hour later, the herd would leave late, the children would reach school late, and the whole day would arrive slightly behind itself.',
          fr: 'Quand le ciel vire au gris, l’eau est chaude et le mil trempe. Personne ne lui a dit de commencer. Aucun horaire n’est affiché nulle part. Mais si elle commençait une heure plus tard, le troupeau partirait en retard, les enfants arriveraient en retard à l’école, et la journée entière prendrait du retard sur elle-même.',
        },
      },
      {
        type: 'quote',
        text: {
          en: 'People think the men decide. The men decide where the cattle go. I decide when everyone can leave.',
          fr: 'Les gens croient que ce sont les hommes qui décident. Les hommes décident où va le bétail. Moi, je décide quand chacun peut partir.',
        },
        by: { en: 'Aïssatou, 44', fr: 'Aïssatou, 44 ans' },
      },
      { type: 'h2', text: { en: 'A job with no name', fr: 'Un métier sans nom' } },
      {
        type: 'p',
        text: {
          en: 'There is no word in the village for what she does, because it is not considered a job. It is considered morning. Ask anyone here who organises the day and they will name the village chief, or the imam, or the head of the family. Ask them what time breakfast is and they will all give the same answer, to the minute.',
          fr: 'Il n’existe pas de mot au village pour ce qu’elle fait, parce que ce n’est pas considéré comme un métier. C’est considéré comme le matin. Demandez à n’importe qui ici qui organise la journée : on vous nommera le chef de village, ou l’imam, ou le chef de famille. Demandez-leur à quelle heure est le petit-déjeuner : tous donneront la même réponse, à la minute près.',
        },
      },
      {
        type: 'image',
        seed: 'story-aissatou-fire',
        caption: {
          en: 'The cooking area, an hour before sunrise.',
          fr: 'Le coin cuisine, une heure avant le lever du soleil.',
        },
      },
      {
        type: 'p',
        text: {
          en: 'Her eldest daughter is seventeen and has started lighting the fire on Fridays. Aïssatou says she is teaching her the timing, not the cooking. The cooking, she says, anyone can learn.',
          fr: 'Sa fille aînée a dix-sept ans et a commencé à allumer le feu le vendredi. Aïssatou dit qu’elle lui apprend le tempo, pas la cuisine. La cuisine, dit-elle, tout le monde peut l’apprendre.',
        },
      },
    ],
  },
  {
    slug: 'diaobe-before-dawn',
    title: { en: 'Diaobé, before dawn', fr: 'Diaobé, avant l’aube' },
    standfirst: {
      en: 'Trucks from Guinea, Mali and The Gambia unload in the dark. By seven, the whole thing is a city.',
      fr: 'Les camions de Guinée, du Mali et de Gambie déchargent dans le noir. À sept heures, tout cela est devenu une ville.',
    },
    category: { en: 'Report', fr: 'Reportage' },
    categorySlug: 'report',
    country: 'senegal',
    village: 'diaobe',
    author: 'amadou',
    publishedAt: '2026-08-30',
    readingMinutes: 11,
    body: [
      {
        type: 'p',
        text: {
          en: 'At four in the morning the market is only headlights and shouting. Nothing is arranged yet. Men are throwing sacks down from a truck bed and other men are counting them out loud in two languages at once.',
          fr: 'À quatre heures du matin, le marché n’est que phares et cris. Rien n’est encore installé. Des hommes jettent des sacs du plateau d’un camion et d’autres les comptent à voix haute, dans deux langues à la fois.',
        },
      },
      {
        type: 'p',
        text: {
          en: 'Three hours later the same ground is laid out in aisles, as if someone had drawn them. Nobody drew them. Everyone simply knows where their family has stood for the last thirty years.',
          fr: 'Trois heures plus tard, le même terrain est organisé en allées, comme si quelqu’un les avait tracées. Personne ne les a tracées. Chacun sait simplement où sa famille se tient depuis trente ans.',
        },
      },
      {
        type: 'quote',
        text: {
          en: 'I come from Labé. Fourteen hours by road. I do it every week and I have never once thought of stopping.',
          fr: 'Je viens de Labé. Quatorze heures de route. Je le fais chaque semaine et je n’ai jamais pensé une seule fois à arrêter.',
        },
        by: { en: 'A trader from Guinea', fr: 'Un commerçant venu de Guinée' },
      },
      {
        type: 'p',
        text: {
          en: 'What surprises visitors is not the size. It is that a market this big runs on trust: almost nothing is written down, and almost everything is paid later.',
          fr: 'Ce qui surprend les visiteurs, ce n’est pas la taille. C’est qu’un marché de cette ampleur fonctionne à la confiance : presque rien n’est écrit, et presque tout est payé plus tard.',
        },
      },
    ],
  },
  {
    slug: 'what-pulaar-does-with-time',
    title: { en: 'What Pulaar does with time', fr: 'Ce que le pulaar fait du temps' },
    standfirst: {
      en: 'There is no single everyday word for “week” in Pulaar. There are market days, and there is everything between them.',
      fr: 'Il n’existe pas vraiment de mot courant pour « semaine » en pulaar. Il y a les jours de marché, et il y a le reste.',
    },
    category: { en: 'Languages', fr: 'Langues' },
    categorySlug: 'languages',
    country: 'senegal',
    author: 'adv-desk',
    publishedAt: '2026-08-24',
    readingMinutes: 6,
    body: [
      {
        type: 'p',
        text: {
          en: 'Ask someone in Saré Yoba when a cousin is arriving and you will rarely get a date. You will get "after the market", or "the market after this one".',
          fr: 'Demandez à quelqu’un de Saré Yoba quand un cousin arrive : vous obtiendrez rarement une date. Vous obtiendrez « après le marché », ou « le marché d’après ».',
        },
      },
      {
        type: 'p',
        text: {
          en: 'This is not vagueness. It is a calendar — one that is shared by everyone in a hundred-kilometre radius and that never needs to be written down.',
          fr: 'Ce n’est pas du flou. C’est un calendrier — partagé par tout le monde dans un rayon de cent kilomètres, et qui n’a jamais besoin d’être écrit.',
        },
      },
      {
        type: 'h2', text: { en: 'Greeting as a whole conversation', fr: 'La salutation comme conversation entière' },
      },
      {
        type: 'p',
        text: {
          en: 'A Pulaar greeting can last a full minute and consists almost entirely of asking about peace: your peace, your household’s peace, your herd’s peace. Only after that does anyone say what they came to say.',
          fr: 'Une salutation en pulaar peut durer une minute entière et consiste presque uniquement à s’enquérir de la paix : votre paix, celle de votre foyer, celle de votre troupeau. Ce n’est qu’ensuite qu’on dit ce pour quoi on est venu.',
        },
      },
    ],
  },
  {
    slug: 'a-loom-and-two-sons',
    title: {
      en: 'A loom, two sons, and a trade with no successor',
      fr: 'Un métier à tisser, deux fils, et un savoir-faire sans héritier',
    },
    standfirst: {
      en: 'Ousmane has been weaving for forty-one years. Neither of his sons intends to take over, and he says he understands.',
      fr: 'Ousmane tisse depuis quarante et un ans. Aucun de ses deux fils ne veut reprendre, et il dit qu’il comprend.',
    },
    category: { en: 'Crafts', fr: 'Artisanat' },
    categorySlug: 'crafts',
    country: 'senegal',
    village: 'kolda',
    author: 'amadou',
    publishedAt: '2026-08-16',
    readingMinutes: 9,
    body: [
      {
        type: 'p',
        text: {
          en: 'The loom takes up most of the room, and Ousmane sits inside it rather than at it, feet in the pedal pit, both hands busy.',
          fr: 'Le métier occupe presque toute la pièce, et Ousmane s’assied dedans plutôt que devant : les pieds dans la fosse à pédales, les deux mains occupées.',
        },
      },
      {
        type: 'quote',
        text: {
          en: 'A strip takes me a day. A machine in Dakar makes forty in an hour. I am not angry about it. I am just the last one.',
          fr: 'Une bande me prend une journée. Une machine à Dakar en fait quarante en une heure. Je n’en veux à personne. Je suis simplement le dernier.',
        },
        by: { en: 'Ousmane, weaver', fr: 'Ousmane, tisserand' },
      },
      {
        type: 'p',
        text: {
          en: 'He still gets orders for weddings and for naming ceremonies, because a machine-made cloth is not the same gift. That, he thinks, will outlast him by a while.',
          fr: 'Il reçoit encore des commandes pour les mariages et les baptêmes, parce qu’un tissu fait à la machine n’est pas le même cadeau. Cela, pense-t-il, lui survivra un moment.',
        },
      },
    ],
  },
  {
    slug: 'the-rice-that-came-back',
    title: { en: 'The rice that came back to Casamance', fr: 'Le riz qui est revenu en Casamance' },
    standfirst: {
      en: 'For twenty years the valleys were too salty to plant. Then a group of women started rebuilding the dykes by hand.',
      fr: 'Pendant vingt ans, les vallées étaient trop salées pour être plantées. Puis des femmes ont recommencé à relever les diguettes à la main.',
    },
    category: { en: 'Agriculture', fr: 'Agriculture' },
    categorySlug: 'agriculture',
    country: 'senegal',
    village: 'kolda',
    author: 'adv-desk',
    publishedAt: '2026-08-09',
    readingMinutes: 12,
    body: [
      {
        type: 'p',
        text: {
          en: 'Salt water pushed up the valleys during the dry years and stayed. Rice will not grow in it. A generation grew up buying imported rice in a region that used to export it.',
          fr: 'L’eau salée est remontée dans les vallées pendant les années sèches, et elle est restée. Le riz n’y pousse pas. Une génération a grandi en achetant du riz importé, dans une région qui en exportait autrefois.',
        },
      },
      {
        type: 'p',
        text: {
          en: 'The repair is unglamorous: earth walls, rebuilt every year, that keep the salt out and the rain in. There is no machine for it that anyone here can afford.',
          fr: 'La réparation n’a rien de spectaculaire : des murets de terre, refaits chaque année, qui retiennent la pluie et repoussent le sel. Aucune machine que quiconque ici puisse s’offrir ne fait ce travail.',
        },
      },
      {
        type: 'image',
        seed: 'story-rice-valley',
        caption: {
          en: 'A rebuilt dyke at the end of the dry season.',
          fr: 'Une diguette relevée en fin de saison sèche.',
        },
      },
      {
        type: 'p',
        text: {
          en: 'Four harvests in, the valley closest to the village produces again. It is not the whole region. It is one valley, and it took eleven years.',
          fr: 'Quatre récoltes plus tard, la vallée la plus proche du village produit de nouveau. Ce n’est pas toute la région. C’est une vallée, et cela a pris onze ans.',
        },
      },
    ],
  },
  {
    slug: 'borders-younger-than-the-songs',
    title: { en: 'Borders younger than the songs', fr: 'Des frontières plus jeunes que les chansons' },
    standfirst: {
      en: 'A griot in Gabú sings a lineage that runs through three modern countries without pausing at any of them.',
      fr: 'Un griot de Gabú chante une lignée qui traverse trois pays actuels sans s’arrêter à aucun.',
    },
    category: { en: 'Culture', fr: 'Culture' },
    categorySlug: 'culture',
    country: 'guinea-bissau',
    village: 'gabu',
    author: 'amadou',
    publishedAt: '2026-08-02',
    readingMinutes: 10,
    body: [
      {
        type: 'p',
        text: {
          en: 'He begins with a name from the eighteenth century and works forward. It takes eleven minutes. He does not hesitate once.',
          fr: 'Il commence par un nom du XVIIIᵉ siècle et remonte le temps. Cela prend onze minutes. Il n’hésite pas une seule fois.',
        },
      },
      {
        type: 'p',
        text: {
          en: 'Halfway through, the lineage crosses what is now the Senegalese border, then what is now the Gambian one, then comes back. The song was composed before any of those lines existed.',
          fr: 'À mi-parcours, la lignée franchit ce qui est aujourd’hui la frontière sénégalaise, puis la gambienne, puis revient. Le chant a été composé avant que ces lignes n’existent.',
        },
      },
      {
        type: 'quote',
        text: {
          en: 'The family did not move. The map moved.',
          fr: 'La famille n’a pas bougé. C’est la carte qui a bougé.',
        },
        by: { en: 'A griot in Gabú', fr: 'Un griot de Gabú' },
      },
    ],
  },
];

/* ============================================================
   RECETTES
   ============================================================ */

export const recipes: Recipe[] = [
  {
    slug: 'thieboudienne',
    name: { en: 'Thieboudienne', fr: 'Thiéboudienne' },
    country: 'senegal',
    region: { en: 'All Senegal', fr: 'Tout le Sénégal' },
    summary: {
      en: 'Rice, fish and vegetables cooked in one pot. The national dish, and the reason lunch takes three hours.',
      fr: 'Riz, poisson et légumes dans une seule marmite. Le plat national, et la raison pour laquelle le déjeuner dure trois heures.',
    },
    minutes: 180,
    serves: 8,
    ingredients: {
      en: [
        'Broken rice, 1 kg',
        'Firm white fish, 1 kg, cut into thick steaks',
        'Cassava, sweet potato, carrot, cabbage, aubergine',
        'Tomato paste, 3 tbsp',
        'Parsley, garlic, chilli and stock cube, pounded together',
        'Dried fish and tamarind, to taste',
        'Groundnut oil',
      ],
      fr: [
        'Riz brisé, 1 kg',
        'Poisson blanc ferme, 1 kg, en tranches épaisses',
        'Manioc, patate douce, carotte, chou, aubergine',
        'Concentré de tomate, 3 c. à soupe',
        'Persil, ail, piment et cube de bouillon, pilés ensemble',
        'Poisson séché et tamarin, selon le goût',
        'Huile d’arachide',
      ],
    },
    steps: {
      en: [
        'Stuff each fish steak with the pounded parsley and garlic mixture.',
        'Fry the fish in hot oil until coloured, then set aside.',
        'Cook the tomato paste slowly in the same oil until it darkens — this step decides the colour of the whole dish.',
        'Add water and the hard vegetables, then the softer ones in order of cooking time.',
        'Return the fish, simmer, then lift everything out and keep it warm.',
        'Cook the rice in the remaining broth, covered, until it has drunk all of it.',
        'Serve on one large platter: rice underneath, fish and vegetables on top.',
      ],
      fr: [
        'Farcir chaque tranche de poisson avec le mélange pilé persil-ail.',
        'Faire revenir le poisson dans l’huile chaude jusqu’à coloration, puis réserver.',
        'Faire cuire lentement le concentré de tomate dans la même huile jusqu’à ce qu’il fonce — cette étape décide de la couleur du plat entier.',
        'Ajouter l’eau et les légumes durs, puis les plus tendres selon leur temps de cuisson.',
        'Remettre le poisson, laisser mijoter, puis tout retirer et garder au chaud.',
        'Cuire le riz dans le bouillon restant, à couvert, jusqu’à ce qu’il l’ait entièrement bu.',
        'Servir sur un grand plat unique : le riz dessous, le poisson et les légumes dessus.',
      ],
    },
    story: {
      en: 'The dish is credited to Penda Mbaye, a nineteenth-century cook in Saint-Louis. The name simply means "rice and fish" in Wolof — ceebu jën.',
      fr: 'Le plat est attribué à Penda Mbaye, cuisinière à Saint-Louis au XIXᵉ siècle. Le nom signifie simplement « riz et poisson » en wolof — ceebu jën.',
    },
  },
  {
    slug: 'mafe',
    name: { en: 'Maafe', fr: 'Mafé' },
    country: 'mali',
    region: { en: 'Mandé region', fr: 'Pays mandé' },
    summary: {
      en: 'Groundnut stew, thick enough to hold a spoon upright. Every family swears its version is the original.',
      fr: 'Une sauce à l’arachide assez épaisse pour tenir une cuillère debout. Chaque famille jure que sa version est l’originale.',
    },
    minutes: 90,
    serves: 6,
    ingredients: {
      en: [
        'Beef or lamb, 800 g, in large pieces',
        'Unsweetened groundnut paste, 250 g',
        'Onion, 2 large',
        'Tomato paste, 2 tbsp',
        'Cassava and sweet potato',
        'Chilli, bay leaf, stock cube',
      ],
      fr: [
        'Bœuf ou agneau, 800 g, en gros morceaux',
        'Pâte d’arachide non sucrée, 250 g',
        'Oignon, 2 gros',
        'Concentré de tomate, 2 c. à soupe',
        'Manioc et patate douce',
        'Piment, feuille de laurier, cube de bouillon',
      ],
    },
    steps: {
      en: [
        'Brown the meat with the onions.',
        'Loosen the groundnut paste with warm water until it pours.',
        'Add the tomato paste, then the groundnut paste, and let it cook down slowly.',
        'Add the vegetables and simmer, stirring often so the bottom does not catch.',
        'It is ready when the oil rises to the surface. Serve with white rice.',
      ],
      fr: [
        'Faire revenir la viande avec les oignons.',
        'Détendre la pâte d’arachide à l’eau tiède jusqu’à ce qu’elle coule.',
        'Ajouter le concentré de tomate, puis la pâte d’arachide, et laisser réduire doucement.',
        'Ajouter les légumes et laisser mijoter en remuant souvent pour que le fond n’attache pas.',
        'C’est prêt quand l’huile remonte à la surface. Servir avec du riz blanc.',
      ],
    },
    story: {
      en: 'Maafe travelled with the Mandé world and changed at every stop: lamb here, chicken there, sometimes no meat at all.',
      fr: 'Le mafé a voyagé avec le monde mandé et a changé à chaque étape : agneau ici, poulet là, parfois pas de viande du tout.',
    },
  },
  {
    slug: 'caldo-de-peixe',
    name: { en: 'Caldo de peixe', fr: 'Caldo de peixe' },
    country: 'guinea-bissau',
    region: { en: 'Coast and rivers', fr: 'Côte et fleuves' },
    summary: {
      en: 'A fish broth with palm oil and lime, eaten with the hands and a lot of bread.',
      fr: 'Un bouillon de poisson à l’huile de palme et au citron vert, mangé à la main avec beaucoup de pain.',
    },
    minutes: 60,
    serves: 4,
    ingredients: {
      en: [
        'Whole fish, 1 kg, cleaned',
        'Red palm oil, 3 tbsp',
        'Onion, tomato, garlic',
        'Lime, 2',
        'Okra, optional',
        'Chilli and salt',
      ],
      fr: [
        'Poisson entier, 1 kg, vidé',
        'Huile de palme rouge, 3 c. à soupe',
        'Oignon, tomate, ail',
        'Citron vert, 2',
        'Gombo, facultatif',
        'Piment et sel',
      ],
    },
    steps: {
      en: [
        'Rub the fish with lime and salt, and leave it while you prepare the rest.',
        'Sweat onion, tomato and garlic in the palm oil.',
        'Add water and bring to a gentle boil.',
        'Slide the fish in whole and do not stir — turn the pot, not the fish.',
        'Finish with lime juice off the heat.',
      ],
      fr: [
        'Frotter le poisson au citron vert et au sel, et le laisser reposer pendant la préparation.',
        'Faire suer oignon, tomate et ail dans l’huile de palme.',
        'Ajouter l’eau et porter à frémissement.',
        'Glisser le poisson entier et ne pas remuer — on tourne la marmite, pas le poisson.',
        'Terminer au jus de citron vert, hors du feu.',
      ],
    },
    story: {
      en: 'Bissau-Guinean cooking keeps the Portuguese names and almost nothing of the Portuguese method.',
      fr: 'La cuisine bissau-guinéenne garde les noms portugais et presque rien de la méthode portugaise.',
    },
  },
];

/* ============================================================
   LANGUES ET MOTS
   ============================================================ */

export const languages: Language[] = [
  {
    slug: 'pulaar',
    name: 'Pulaar',
    speakers: { en: 'Millions of speakers across West Africa', fr: 'Des millions de locuteurs en Afrique de l’Ouest' },
    description: {
      en: 'The language of the Fulani. In Haute-Casamance it is what you hear first, in the compound and at the market.',
      fr: 'La langue des Peuls. En Haute-Casamance, c’est ce qu’on entend en premier, dans la concession comme au marché.',
    },
    region: { en: 'Senegal, Guinea, Mali, The Gambia, Mauritania', fr: 'Sénégal, Guinée, Mali, Gambie, Mauritanie' },
  },
  {
    slug: 'mandinka',
    name: 'Mandinka',
    speakers: { en: 'Widely spoken across the Senegambia', fr: 'Largement parlé dans toute la Sénégambie' },
    description: {
      en: 'The language of the old Kaabu kingdom, and still the language of the griots who remember it.',
      fr: 'La langue de l’ancien royaume du Kaabu, et encore celle des griots qui s’en souviennent.',
    },
    region: { en: 'The Gambia, Senegal, Guinea-Bissau, Mali', fr: 'Gambie, Sénégal, Guinée-Bissau, Mali' },
  },
  {
    slug: 'wolof',
    name: 'Wolof',
    speakers: { en: 'Senegal’s main spoken language', fr: 'La principale langue parlée au Sénégal' },
    description: {
      en: 'Not the first language of Kolda, but the language everyone switches to when a stranger arrives.',
      fr: 'Ce n’est pas la première langue de Kolda, mais celle vers laquelle tout le monde bascule quand un étranger arrive.',
    },
    region: { en: 'Senegal, The Gambia, Mauritania', fr: 'Sénégal, Gambie, Mauritanie' },
  },
];

export const words: Word[] = [
  {
    slug: 'jam-tan',
    word: 'Jam tan',
    language: 'pulaar',
    pronunciation: 'djam tann',
    meaning: {
      en: 'Peace only — the answer you give when someone asks how you are',
      fr: 'Rien que la paix — la réponse que l’on donne quand on demande comment vous allez',
    },
    example: { en: 'No jam? — Jam tan.', fr: 'No jam ? — Jam tan.' },
    exampleTranslation: {
      en: '“Are you at peace?” — “Only peace.” It is how two people begin every conversation.',
      fr: '« Es-tu en paix ? » — « Rien que la paix. » C’est ainsi que deux personnes commencent chaque conversation.',
    },
    region: { en: 'Senegal, Guinea, Mali, The Gambia', fr: 'Sénégal, Guinée, Mali, Gambie' },
  },
  {
    slug: 'on-jaaraama',
    word: 'On jaaraama',
    language: 'pulaar',
    pronunciation: 'onn djaa-raa-ma',
    meaning: { en: 'Thank you — literally, may you be rewarded', fr: 'Merci — littéralement, que tu sois récompensé' },
    example: { en: 'On jaaraama, sukaaɓe.', fr: 'On jaaraama, sukaaɓe.' },
    exampleTranslation: {
      en: 'Thank you, children. Said to a group, it is also a way of blessing them.',
      fr: 'Merci, les enfants. Dit à un groupe, c’est aussi une manière de le bénir.',
    },
    region: { en: 'Senegal, Guinea, Mali', fr: 'Sénégal, Guinée, Mali' },
  },
  {
    slug: 'i-be-nyaading',
    word: 'I be ñaading',
    language: 'mandinka',
    pronunciation: 'i bé gnaa-ding',
    meaning: { en: 'You are eating — said as a greeting at mealtime', fr: 'Tu manges — se dit en salutation à l’heure du repas' },
    example: { en: 'I be ñaading?', fr: 'I be ñaading ?' },
    exampleTranslation: {
      en: 'Asked from the doorway, it is not a question. It is an invitation to sit down.',
      fr: 'Posée depuis le seuil, ce n’est pas une question. C’est une invitation à s’asseoir.',
    },
    region: { en: 'Senegal, The Gambia, Guinea-Bissau', fr: 'Sénégal, Gambie, Guinée-Bissau' },
  },
  {
    slug: 'abaraka',
    word: 'Abaraka',
    language: 'mandinka',
    pronunciation: 'a-ba-ra-ka',
    meaning: { en: 'Thank you', fr: 'Merci' },
    example: { en: 'Abaraka baake.', fr: 'Abaraka baake.' },
    exampleTranslation: { en: 'Thank you very much.', fr: 'Merci beaucoup.' },
    region: { en: 'The Gambia, Senegal', fr: 'Gambie, Sénégal' },
  },
  {
    slug: 'teranga',
    word: 'Teranga',
    language: 'wolof',
    pronunciation: 'té-ran-ga',
    meaning: {
      en: 'Hospitality — but closer to “the duty to receive well”',
      fr: 'L’hospitalité — mais plus proche du « devoir de bien recevoir »',
    },
    example: { en: 'Senegal, the land of teranga', fr: 'Le Sénégal, pays de la teranga' },
    exampleTranslation: {
      en: 'A guest is not a guest. A guest is a responsibility.',
      fr: 'Un invité n’est pas un invité. Un invité est une responsabilité.',
    },
    region: { en: 'Senegal, The Gambia', fr: 'Sénégal, Gambie' },
  },
  {
    slug: 'jamm-rekk',
    word: 'Jàmm rekk',
    language: 'wolof',
    pronunciation: 'djam rèk',
    meaning: { en: 'Peace only — the Wolof twin of the Pulaar answer', fr: 'Rien que la paix — le jumeau wolof de la réponse peule' },
    example: { en: 'Na nga def? — Jàmm rekk.', fr: 'Na nga def ? — Jàmm rekk.' },
    exampleTranslation: {
      en: '“How are you?” — “Peace only.” Two languages, the same idea of what a good day is.',
      fr: '« Comment vas-tu ? » — « Rien que la paix. » Deux langues, la même idée de ce qu’est une bonne journée.',
    },
    region: { en: 'Senegal', fr: 'Sénégal' },
  },
];

/* ============================================================
   THÈMES CULTURELS
   ============================================================ */

export const cultureThemes: CultureTheme[] = [
  {
    slug: 'traditions',
    name: { en: 'Traditions', fr: 'Traditions' },
    description: {
      en: 'Naming ceremonies, weddings, harvest rites — what happens, who does what, and why it is done that way.',
      fr: 'Baptêmes, mariages, rites de récolte — ce qui se passe, qui fait quoi, et pourquoi c’est fait ainsi.',
    },
  },
  {
    slug: 'music',
    name: { en: 'Music', fr: 'Musique' },
    description: {
      en: 'The kora, the balafon, the drums that announce a wedding two villages away.',
      fr: 'La kora, le balafon, les tambours qui annoncent un mariage à deux villages de là.',
    },
  },
  {
    slug: 'dance',
    name: { en: 'Dance', fr: 'Danse' },
    description: {
      en: 'Who dances, when, and what is being said without words.',
      fr: 'Qui danse, quand, et ce qui se dit sans mots.',
    },
  },
  {
    slug: 'clothing',
    name: { en: 'Clothing', fr: 'Vêtements' },
    description: {
      en: 'Woven strips, indigo, embroidery — and what an outfit tells you before its wearer speaks.',
      fr: 'Bandes tissées, indigo, broderie — et ce qu’une tenue dit avant que celui qui la porte ne parle.',
    },
  },
  {
    slug: 'crafts',
    name: { en: 'Crafts', fr: 'Artisanat' },
    description: {
      en: 'Weaving, pottery, leather, metal. Trades learned by watching, rarely by being taught.',
      fr: 'Tissage, poterie, cuir, métal. Des métiers appris en regardant, rarement en étant enseignés.',
    },
  },
  {
    slug: 'festivals',
    name: { en: 'Festivals', fr: 'Fêtes' },
    description: {
      en: 'The days the whole village stops working, and what it costs to host them.',
      fr: 'Les jours où le village entier cesse de travailler, et ce que coûte de les accueillir.',
    },
  },
  {
    slug: 'family',
    name: { en: 'Family', fr: 'Famille' },
    description: {
      en: 'The compound, the elders, the children raised by everyone.',
      fr: 'La concession, les anciens, les enfants élevés par tout le monde.',
    },
  },
  {
    slug: 'social-life',
    name: { en: 'Social life', fr: 'Vie sociale' },
    description: {
      en: 'Tea under the mango tree, the long greeting, and who gets to speak first.',
      fr: 'Le thé sous le manguier, la longue salutation, et qui parle en premier.',
    },
  },
  {
    slug: 'beliefs',
    name: { en: 'Beliefs and practices', fr: 'Croyances et pratiques' },
    description: {
      en: 'Faith, custom, and everything that lives comfortably in between.',
      fr: 'La foi, la coutume, et tout ce qui vit tranquillement entre les deux.',
    },
  },
];
