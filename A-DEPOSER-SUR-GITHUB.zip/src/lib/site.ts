/**
 * Les réglages de la marque, à un seul endroit.
 * Les liens sociaux sont vides tant que les comptes ne sont pas créés :
 * le site affiche alors « bientôt » au lieu d'un lien mort.
 */
export const site = {
  name: 'Afro Daily Village',
  url: process.env.NEXT_PUBLIC_SITE_URL ?? 'https://afrodailyvillage.com',
  contactEmail: 'contact@afrodailyvillage.com',
  social: {
    youtube: process.env.NEXT_PUBLIC_YOUTUBE_URL ?? '',
    tiktok: process.env.NEXT_PUBLIC_TIKTOK_URL ?? '',
    instagram: process.env.NEXT_PUBLIC_INSTAGRAM_URL ?? '',
  },
  defaultLocale: 'en',
} as const;

export const hasSocial = (key: keyof typeof site.social) => site.social[key].length > 0;
