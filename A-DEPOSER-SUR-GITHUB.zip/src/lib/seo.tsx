import type { Metadata } from 'next';
import { getPathname } from '@/i18n/navigation';
import { routing, type Locale } from '@/i18n/routing';
import { site } from '@/lib/site';

type Href = Parameters<typeof getPathname>[0]['href'];

/**
 * Les métadonnées d'une page, construites une seule fois pour tout le site.
 *
 * Ce que ça produit automatiquement à chaque page :
 * — un titre et une description uniques ;
 * — l'adresse canonique (« la vraie adresse de cette page ») ;
 * — le lien vers la version dans l'autre langue (hreflang) ;
 * — la carte de partage pour WhatsApp, Facebook et X.
 */
export function buildMetadata({
  locale,
  href,
  title,
  description,
  type = 'website',
  publishedTime,
}: {
  locale: Locale;
  href: Href;
  title: string;
  description: string;
  type?: 'website' | 'article';
  publishedTime?: string;
}): Metadata {
  const canonical = getPathname({ href, locale });
  const languages = Object.fromEntries([
    ...routing.locales.map((l) => [l, getPathname({ href, locale: l })]),
    ['x-default', getPathname({ href, locale: 'en' })],
  ]);

  return {
    title,
    description,
    alternates: { canonical, languages },
    openGraph: {
      type,
      title,
      description,
      url: `${site.url}${canonical}`,
      siteName: site.name,
      locale: locale === 'fr' ? 'fr_FR' : 'en_GB',
      ...(publishedTime ? { publishedTime } : {}),
    },
    twitter: { card: 'summary_large_image', title, description },
  };
}

/** Le fil d'Ariane, en données structurées, pour que Google l'affiche. */
export function breadcrumbJsonLd(items: { name: string; path: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: `${site.url}${item.path}`,
    })),
  };
}

/** Composant minuscule pour injecter des données structurées dans une page. */
export function JsonLd({ data }: { data: object }) {
  return (
    <script
      type="application/ld+json"
      // Contenu construit par nous, jamais saisi par un visiteur.
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
