import { NextStudio } from 'next-sanity/studio';
import config from '../../../../sanity.config';
import { sanityEnabled } from '@/sanity/env';

export const dynamic = 'force-static';

/**
 * /studio — votre tableau de bord.
 *
 * Tant que l'identifiant de projet n'est pas renseigné, on affiche une
 * explication au lieu d'un écran d'erreur incompréhensible.
 */
export default function StudioPage() {
  if (!sanityEnabled) {
    return <NotConnected />;
  }
  return <NextStudio config={config} />;
}

function NotConnected() {
  return (
    <main
      style={{
        minHeight: '100vh',
        background: '#0d0a06',
        color: '#f5eee2',
        fontFamily: 'system-ui, sans-serif',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
      }}
    >
      <div style={{ maxWidth: 560 }}>
        <p style={{ letterSpacing: '0.16em', fontSize: 11, color: '#e39b2e', textTransform: 'uppercase' }}>
          Tableau de bord
        </p>
        <h1 style={{ fontSize: 30, lineHeight: 1.15, margin: '12px 0 16px' }}>
          Pas encore branché
        </h1>
        <p style={{ color: '#b3a48d', lineHeight: 1.6, margin: '0 0 16px' }}>
          Le tableau de bord s’ouvrira ici dès que l’identifiant du projet Sanity sera
          renseigné dans le fichier <code>.env.local</code>, à la ligne
          <code> NEXT_PUBLIC_SANITY_PROJECT_ID</code>.
        </p>
        <p style={{ color: '#7a6e5d', lineHeight: 1.6, fontSize: 14, margin: 0 }}>
          En attendant, le site fonctionne normalement avec le contenu de démonstration.
        </p>
      </div>
    </main>
  );
}
