import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { Breadcrumbs } from '@/components/layout/Breadcrumbs';
import { Picture } from '@/components/media/Picture';
import { CountryTag } from '@/components/ui/CountryTag';
import { getCountry, getRecipe, getRecipeSlugs } from '@/lib/content';
import { buildMetadata, breadcrumbJsonLd, JsonLd } from '@/lib/seo';
import { getPathname } from '@/i18n/navigation';
import { routing, type Locale } from '@/i18n/routing';

type Params = { params: Promise<{ locale: string; slug: string }> };

export async function generateStaticParams() {
  const slugs = await getRecipeSlugs();
  return routing.locales.flatMap((locale) => slugs.map((slug) => ({ locale, slug })));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { locale, slug } = await params;
  const recipe = await getRecipe(slug);
  if (!recipe) return {};
  const l = locale as Locale;
  return buildMetadata({
    locale: l,
    href: { pathname: '/food/[slug]', params: { slug } },
    title: recipe.name[l],
    description: recipe.summary[l],
  });
}

export default async function RecipePage({ params }: Params) {
  const { locale, slug } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const recipe = await getRecipe(slug);
  if (!recipe) notFound();

  const t = await getTranslations('pages.food');
  const tc = await getTranslations('common');
  const tn = await getTranslations('nav');
  const country = await getCountry(recipe.country);

  return (
    <>
      {/* Données structurées « Recette » : c'est ce qui permet à Google
          d'afficher le temps de préparation et le nombre de parts. */}
      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'Recipe',
          name: recipe.name[l],
          description: recipe.summary[l],
          recipeCuisine: country?.name[l],
          totalTime: `PT${recipe.minutes}M`,
          recipeYield: `${recipe.serves}`,
          inLanguage: l,
          recipeIngredient: recipe.ingredients[l],
          recipeInstructions: recipe.steps[l].map((step, i) => ({
            '@type': 'HowToStep',
            position: i + 1,
            text: step,
          })),
        }}
      />
      <JsonLd
        data={breadcrumbJsonLd([
          { name: tn('home'), path: getPathname({ href: '/', locale: l }) },
          { name: tn('food'), path: getPathname({ href: '/food', locale: l }) },
          {
            name: recipe.name[l],
            path: getPathname({ href: { pathname: '/food/[slug]', params: { slug } }, locale: l }),
          },
        ])}
      />

      <header className="border-b border-line bg-surface">
        <Container className="py-12 lg:py-16">
          <Breadcrumbs
            items={[
              { label: tn('home'), href: '/' },
              { label: tn('food'), href: '/food' },
              { label: recipe.name[l] },
            ]}
          />
          <h1 className="mt-6 text-[clamp(2rem,6vw,3.5rem)]">{recipe.name[l]}</h1>
          <p className="mt-5 max-w-[54ch] text-[clamp(1.05rem,2vw,1.25rem)] leading-[1.55] text-ink-muted">
            {recipe.summary[l]}
          </p>
          <p className="label mt-7 flex flex-wrap items-center gap-2.5 text-[10px] text-ink-faint">
            {country ? <CountryTag country={country} locale={l} /> : null}
            <span aria-hidden="true" className="text-line-strong">·</span>
            <span>{recipe.region[l]}</span>
            <span aria-hidden="true" className="text-line-strong">·</span>
            <span>{t('minutes', { count: recipe.minutes })}</span>
            <span aria-hidden="true" className="text-line-strong">·</span>
            <span>{t('serves', { count: recipe.serves })}</span>
          </p>
        </Container>
      </header>

      <div className="relative aspect-16/9 max-h-[60svh] w-full overflow-hidden bg-surface">
        <Picture
          image={recipe.image}
          seed={`recipe-${recipe.slug}`}
          mood="fire"
          alt={recipe.name[l]}
          demoLabel={tc('demoBadge')}
          priority
          className="h-full w-full object-cover"
        />
      </div>

      <Container className="py-12 lg:py-16">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.6fr] lg:gap-16">
          <section aria-labelledby="ingredients">
            <h2 id="ingredients" className="text-[clamp(1.25rem,2.6vw,1.6rem)]">
              {t('ingredients')}
            </h2>
            <ul className="mt-5 divide-y divide-line border-y border-line">
              {recipe.ingredients[l].map((item, i) => (
                <li key={i} className="py-3 text-[16px] leading-[1.5] text-ink-muted">
                  {item}
                </li>
              ))}
            </ul>
          </section>

          <section aria-labelledby="method">
            <h2 id="method" className="text-[clamp(1.25rem,2.6vw,1.6rem)]">
              {t('method')}
            </h2>
            <ol className="mt-5 flex flex-col">
              {recipe.steps[l].map((step, i) => (
                <li
                  key={i}
                  className="grid grid-cols-[2.25rem_minmax(0,1fr)] gap-4 border-t border-line py-5 last:border-b"
                >
                  <span className="label pt-1 text-[11px] font-semibold text-sun tabular-nums">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <p className="text-[16.5px] leading-[1.65] text-ink">{step}</p>
                </li>
              ))}
            </ol>

            <div className="mt-10 border-l-2 border-sun bg-surface px-5 py-4">
              <p className="label mb-2 text-[9.5px] text-sun">{t('story')}</p>
              <p className="text-[16px] leading-[1.6] text-ink-muted">{recipe.story[l]}</p>
            </div>
          </section>
        </div>
      </Container>
    </>
  );
}
