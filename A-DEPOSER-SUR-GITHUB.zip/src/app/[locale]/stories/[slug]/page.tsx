import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Breadcrumbs } from '@/components/layout/Breadcrumbs';
import { Picture } from '@/components/media/Picture';
import { CountryTag } from '@/components/ui/CountryTag';
import { ArticleCard } from '@/components/cards/ArticleCard';
import { ShareRow } from '@/components/article/ShareRow';
import { ArticleBody } from '@/components/article/ArticleBody';
import { NewsletterBlock } from '@/components/home/NewsletterBlock';
import { Link } from '@/i18n/navigation';
import { ArrowIcon } from '@/components/ui/Icon';
import {
  formatDate,
  getArticle,
  getArticleSlugs,
  getAuthor,
  getCountries,
  getCountry,
  getRelatedArticles,
  getVillage,
} from '@/lib/content';
import { buildMetadata, breadcrumbJsonLd, JsonLd } from '@/lib/seo';
import { getPathname } from '@/i18n/navigation';
import { routing, type Locale } from '@/i18n/routing';
import { site } from '@/lib/site';

type Params = { params: Promise<{ locale: string; slug: string }> };

export async function generateStaticParams() {
  const slugs = await getArticleSlugs();
  return routing.locales.flatMap((locale) => slugs.map((slug) => ({ locale, slug })));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { locale, slug } = await params;
  const article = await getArticle(slug);
  if (!article) return {};
  const l = locale as Locale;
  return buildMetadata({
    locale: l,
    href: { pathname: '/stories/[slug]', params: { slug } },
    title: article.title[l],
    description: article.standfirst[l],
    type: 'article',
    publishedTime: article.publishedAt,
  });
}

export default async function StoryPage({ params }: Params) {
  const { locale, slug } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const article = await getArticle(slug);
  if (!article) notFound();

  const t = await getTranslations('pages.stories');
  const tf = await getTranslations('featured');
  const tc = await getTranslations('common');
  const tn = await getTranslations('nav');

  const [author, country, village, related, countries] = await Promise.all([
    getAuthor(article.author),
    getCountry(article.country),
    article.village ? getVillage(article.village) : Promise.resolve(undefined),
    getRelatedArticles(article, 3),
    getCountries(),
  ]);
  const countryBySlug = new Map(countries.map((c) => [c.slug, c]));

  const url = `${site.url}${getPathname({ href: { pathname: '/stories/[slug]', params: { slug } }, locale: l })}`;

  return (
    <>
      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'Article',
          headline: article.title[l],
          description: article.standfirst[l],
          datePublished: article.publishedAt,
          inLanguage: l,
          author: author ? { '@type': 'Person', name: author.name } : undefined,
          publisher: { '@type': 'Organization', name: site.name },
          mainEntityOfPage: url,
        }}
      />
      <JsonLd
        data={breadcrumbJsonLd([
          { name: tn('home'), path: getPathname({ href: '/', locale: l }) },
          { name: tn('stories'), path: getPathname({ href: '/stories', locale: l }) },
          {
            name: article.title[l],
            path: getPathname({ href: { pathname: '/stories/[slug]', params: { slug } }, locale: l }),
          },
        ])}
      />

      <article>
        <header className="border-b border-line bg-surface">
          {/* Même largeur de colonne que le corps de l'article : le titre,
              le chapô et le texte partagent exactement le même bord gauche. */}
          <Container size="reading" className="py-12 lg:py-16">
            <Breadcrumbs
              items={[
                { label: tn('home'), href: '/' },
                { label: tn('stories'), href: '/stories' },
              ]}
            />

            <p className="label mt-6 text-sun">{article.category[l]}</p>

            <h1 className="mt-3 text-[clamp(2rem,5.2vw,3.25rem)]">{article.title[l]}</h1>

            <p className="mt-5 text-[clamp(1.05rem,2.2vw,1.3rem)] leading-[1.5] text-ink-muted">
              {article.standfirst[l]}
            </p>

            <div className="label mt-8 flex flex-wrap items-center gap-x-3 gap-y-2 border-t border-line pt-5 text-[10px] text-ink-faint">
              {author ? <span className="text-ink">{tf('byline', { author: author.name })}</span> : null}
              <span aria-hidden="true" className="text-line-strong">/</span>
              <span>{t('publishedOn', { date: formatDate(article.publishedAt, l) })}</span>
              <span aria-hidden="true" className="text-line-strong">/</span>
              <span>{tf('readingTime', { minutes: article.readingMinutes })}</span>
              {country ? (
                <>
                  <span aria-hidden="true" className="text-line-strong">/</span>
                  <CountryTag country={country} locale={l} />
                </>
              ) : null}
            </div>
          </Container>
        </header>

        {/* Image principale */}
        <div className="relative aspect-16/9 max-h-[68svh] w-full overflow-hidden bg-surface">
          <Picture
            image={article.image}
            seed={`article-${article.slug}`}
            alt={article.title[l]}
            demoLabel={tc('demoBadge')}
            priority
            className="h-full w-full object-cover"
          />
        </div>

        <Container size="reading" className="py-12 lg:py-16">
          <ArticleBody blocks={article.body[l]} demoLabel={tc('demoBadge')} />

          {village ? (
            <Link
              href={{ pathname: '/villages/[slug]', params: { slug: village.slug } }}
              className="mt-10 flex items-center justify-between gap-4 border border-line bg-surface px-5 py-4 transition-colors hover:border-sun"
            >
              <span>
                <span className="label block text-[9.5px] text-ink-faint">{tn('villages')}</span>
                <span className="mt-1 block font-display text-[17px] font-semibold">
                  {village.name}
                </span>
              </span>
              <ArrowIcon className="h-4 w-4 shrink-0 text-sun" />
            </Link>
          ) : null}

          <ShareRow label={t('share')} url={url} title={article.title[l]} />

          {author ? (
            <div className="mt-10 border-t border-line pt-6">
              <p className="label text-[9.5px] text-ink-faint">{author.role[l]}</p>
              <p className="mt-1.5 font-display text-[18px] font-semibold">{author.name}</p>
              <p className="mt-2 text-[15.5px] leading-[1.6] text-ink-muted">{author.bio[l]}</p>
            </div>
          ) : null}
        </Container>

        {related.length > 0 ? (
          <Container className="pb-8">
            <SectionHeader label={tn('stories')} title={t('related')} />
            <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((a, i) => (
                <ArticleCard
                  key={a.slug}
                  article={a}
                  locale={l}
                  index={i + 1}
                  country={countryBySlug.get(a.country)}
                />
              ))}
            </div>
          </Container>
        ) : null}

        <NewsletterBlock />
      </article>
    </>
  );
}
