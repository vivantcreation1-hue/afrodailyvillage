import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { ArticleCard } from '@/components/cards/ArticleCard';
import { getCountries, getLatestArticles } from '@/lib/content';
import { buildMetadata } from '@/lib/seo';
import type { Locale } from '@/i18n/routing';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.stories' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/stories',
    title: t('title'),
    description: t('lead'),
  });
}

export default async function StoriesPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const t = await getTranslations('pages.stories');
  const [articles, countries] = await Promise.all([getLatestArticles(24), getCountries()]);
  const countryBySlug = new Map(countries.map((c) => [c.slug, c]));

  return (
    <>
      <PageHeader title={t('title')} lead={t('lead')} />
      <Container className="py-12 lg:py-16">
        <div className="grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {articles.map((article, i) => (
            <ArticleCard
              key={article.slug}
              article={article}
              locale={l}
              index={i}
              country={countryBySlug.get(article.country)}
            />
          ))}
        </div>
      </Container>
    </>
  );
}
