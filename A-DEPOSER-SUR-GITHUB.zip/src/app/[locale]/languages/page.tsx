import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { WordCard } from '@/components/cards/WordCard';
import { Link } from '@/i18n/navigation';
import { ArrowIcon } from '@/components/ui/Icon';
import { getLanguages, getWords } from '@/lib/content';
import { buildMetadata } from '@/lib/seo';
import type { Locale } from '@/i18n/routing';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.languages' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/languages',
    title: t('title'),
    description: t('lead'),
  });
}

export default async function LanguagesPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const t = await getTranslations('pages.languages');
  const [languages, words] = await Promise.all([getLanguages(), getWords()]);
  const nameBySlug = new Map(languages.map((x) => [x.slug, x.name]));

  return (
    <>
      <PageHeader title={t('title')} lead={t('lead')} />

      <Container className="py-12 lg:py-16">
        {/* Les langues */}
        <ul className="mb-14 grid grid-cols-1 gap-px border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
          {languages.map((lang) => (
            <li key={lang.slug} className="bg-ground">
              <Link
                href={{ pathname: '/languages/[slug]', params: { slug: lang.slug } }}
                className="group flex h-full flex-col p-6 transition-colors hover:bg-surface"
              >
                <h2 className="wordmark text-[clamp(1.5rem,4vw,2rem)] transition-colors group-hover:text-sun">
                  {lang.name}
                </h2>
                <p className="label mt-2 text-[9.5px] text-ink-faint">{lang.speakers[l]}</p>
                <p className="mt-3 flex-1 text-[15px] leading-[1.55] text-ink-muted">
                  {lang.description[l]}
                </p>
                <span className="label mt-4 inline-flex items-center gap-1.5 text-[9.5px] text-sun">
                  {t('wordCount', { count: words.filter((w) => w.language === lang.slug).length })}
                  <ArrowIcon className="h-3 w-3" />
                </span>
              </Link>
            </li>
          ))}
        </ul>

        {/* Tous les mots */}
        <SectionHeader label={t('title')} title={t('allWords')} />
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {words.map((word) => (
            <WordCard
              key={word.slug}
              word={word}
              locale={l}
              languageName={nameBySlug.get(word.language)}
            />
          ))}
        </div>
      </Container>
    </>
  );
}
