import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { Breadcrumbs } from '@/components/layout/Breadcrumbs';
import { WordCard } from '@/components/cards/WordCard';
import { getLanguage, getLanguageSlugs, getWords } from '@/lib/content';
import { buildMetadata, breadcrumbJsonLd, JsonLd } from '@/lib/seo';
import { getPathname } from '@/i18n/navigation';
import { routing, type Locale } from '@/i18n/routing';

type Params = { params: Promise<{ locale: string; slug: string }> };

export async function generateStaticParams() {
  const slugs = await getLanguageSlugs();
  return routing.locales.flatMap((locale) => slugs.map((slug) => ({ locale, slug })));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { locale, slug } = await params;
  const language = await getLanguage(slug);
  if (!language) return {};
  const l = locale as Locale;
  return buildMetadata({
    locale: l,
    href: { pathname: '/languages/[slug]', params: { slug } },
    title: language.name,
    description: language.description[l],
  });
}

export default async function LanguagePage({ params }: Params) {
  const { locale, slug } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const language = await getLanguage(slug);
  if (!language) notFound();

  const t = await getTranslations('pages.languages');
  const tn = await getTranslations('nav');
  const words = await getWords(slug);

  return (
    <>
      <JsonLd
        data={breadcrumbJsonLd([
          { name: tn('home'), path: getPathname({ href: '/', locale: l }) },
          { name: tn('languages'), path: getPathname({ href: '/languages', locale: l }) },
          {
            name: language.name,
            path: getPathname({ href: { pathname: '/languages/[slug]', params: { slug } }, locale: l }),
          },
        ])}
      />

      <PageHeader
        eyebrow={`${t('spokenIn')} ${language.region[l]}`}
        title={language.name}
        lead={language.description[l]}
        meta={
          <p className="label text-[10px] text-ink-faint">
            {t('wordCount', { count: words.length })}
          </p>
        }
      >
        <div className="mt-7">
          <Breadcrumbs
            items={[
              { label: tn('home'), href: '/' },
              { label: tn('languages'), href: '/languages' },
              { label: language.name },
            ]}
          />
        </div>
      </PageHeader>

      <Container className="py-12 lg:py-16">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {words.map((word) => (
            <WordCard key={word.slug} word={word} locale={l} languageName={language.name} />
          ))}
        </div>
      </Container>
    </>
  );
}
