import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { ContactForm } from '@/components/forms/ContactForm';
import { buildMetadata } from '@/lib/seo';
import { site } from '@/lib/site';
import type { Locale } from '@/i18n/routing';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.contact' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/contact',
    title: t('title'),
    description: t('lead'),
  });
}

export default async function ContactPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const t = await getTranslations('pages.contact');

  return (
    <>
      <PageHeader title={t('title')} lead={t('lead')} />

      <Container className="py-12 lg:py-16">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
          <ContactForm />

          <aside className="border-t border-line pt-6 lg:border-l lg:border-t-0 lg:pl-10 lg:pt-0">
            <p className="label text-[9.5px] text-ink-faint">{t('or')}</p>
            <a
              href={`mailto:${site.contactEmail}`}
              className="mt-2 block font-display text-[clamp(1.05rem,2.4vw,1.35rem)] font-semibold break-words text-sun transition-colors hover:text-sun-deep"
            >
              {site.contactEmail}
            </a>
            <p className="mt-6 border-l-2 border-line pl-4 text-[14.5px] leading-[1.6] text-ink-faint">
              {t('notReady')}
            </p>
          </aside>
        </div>
      </Container>
    </>
  );
}
