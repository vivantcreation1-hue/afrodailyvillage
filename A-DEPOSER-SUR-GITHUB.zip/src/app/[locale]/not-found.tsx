import { getTranslations } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { ButtonLink } from '@/components/ui/Button';
import { DemoPhoto } from '@/components/media/DemoPhoto';
import { ArrowIcon } from '@/components/ui/Icon';

export default async function NotFound() {
  const t = await getTranslations('common');
  const tn = await getTranslations('nav');

  return (
    <section className="relative isolate flex min-h-[72svh] items-center overflow-hidden">
      <DemoPhoto
        seed="lost-village"
        mood="night"
        alt=""
        className="absolute inset-0 -z-20 h-full w-full object-cover"
      />
      <div className="scrim absolute inset-0 -z-10" />

      <Container className="py-24">
        <span className="label mb-4 block text-sun">404</span>
        <h1 className="max-w-[18ch] text-[clamp(2rem,6.5vw,4rem)]">
          You have wandered away from the village…
        </h1>
        <p className="mt-3 max-w-[18ch] text-[clamp(1.1rem,3vw,1.6rem)] font-semibold text-ink-muted">
          Vous vous êtes éloigné du village…
        </p>
        <div className="mt-9 flex flex-wrap gap-3">
          <ButtonLink href="/">{t('backHome')}</ButtonLink>
          <ButtonLink href="/stories" variant="outline">
            {tn('stories')}
            <ArrowIcon className="h-4 w-4" />
          </ButtonLink>
        </div>
      </Container>
    </section>
  );
}
