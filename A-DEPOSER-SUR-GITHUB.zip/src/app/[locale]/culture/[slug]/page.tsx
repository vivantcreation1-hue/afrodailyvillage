import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { Breadcrumbs } from '@/components/layout/Breadcrumbs';
import { ArticleCard } from '@/components/cards/ArticleCard';
import { SectionHeader } from '@/components/ui/SectionHeader';
import {
  getCountries,
  getCultureTheme,
  getCultureThemeSlugs,
  getLatestArticles,
} from '@/lib/content';
import { buildMetadata, breadcrumbJsonLd, JsonLd } from '@/lib/seo';
import { getPathname } from '@/i18n/navigation';
import { routing, type Locale } from '@/i18n/routing';

type Params = { params: Promise<{ locale: string; slug: string }> };

export async function generateStaticParams() {
  const slugs = await getCultureThemeSlugs();
  return routing.locales.flatMap((locale) => slugs.map((slug) => ({ locale, slug })));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { locale, slug } = await params;
  const theme = await getCultureTheme(slug);
  if (!theme) return {};
  const l = locale as Locale;
  return buildMetadata({
    locale: l,
    href: { pathname: '/culture/[slug]', params: { slug } },
    title: theme.name[l],
    description: theme.description[l],
  });
}

export default async function CultureThemePage({ params }: Params) {
  const { locale, slug } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const theme = await getCultureTheme(slug);
  if (!theme) notFound();

  const tn = await getTranslations('nav');
  const tc = await getTranslations('common');
  const ts = await getTranslations('pages.stories');

  // En attendant que le CMS permette de rattacher un article à un thème,
  // on montre les récits liés à la culture au sens large.
  const [articles, countries] = await Promise.all([getLatestArticles(3), getCountries()]);
  const countryBySlug = new Map(countries.map((c) => [c.slug, c]));

  return (
    <>
      <JsonLd
        data={breadcrumbJsonLd([
          { name: tn('home'), path: getPathname({ href: '/', locale: l }) },
          { name: tn('culture'), path: getPathname({ href: '/culture', locale: l }) },
          {
            name: theme.name[l],
            path: getPathname({ href: { pathname: '/culture/[slug]', params: { slug } }, locale: l }),
          },
        ])}
      />

      <PageHeader title={theme.name[l]} lead={theme.description[l]}>
        <div className="mt-7">
          <Breadcrumbs
            items={[
              { label: tn('home'), href: '/' },
              { label: tn('culture'), href: '/culture' },
              { label: theme.name[l] },
            ]}
          />
        </div>
      </PageHeader>

      <Container className="py-12 lg:py-16">
        <p className="mb-10 border border-dashed border-line px-5 py-4 text-[15.5px] leading-[1.6] text-ink-muted">
          {tc('empty')}
        </p>

        <SectionHeader label={tn('stories')} title={ts('related')} />
        <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {articles.map((a, i) => (
            <ArticleCard
              key={a.slug}
              article={a}
              locale={l}
              index={i}
              country={countryBySlug.get(a.country)}
            />
          ))}
        </div>
      </Container>
    </>
  );
}
