import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { Link } from '@/i18n/navigation';
import { ArrowIcon } from '@/components/ui/Icon';
import { Picture } from '@/components/media/Picture';
import { getCultureThemes } from '@/lib/content';
import { buildMetadata } from '@/lib/seo';
import type { Locale } from '@/i18n/routing';

const MOODS = ['dawn', 'noon', 'dusk', 'night', 'fire'] as const;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.culture' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/culture',
    title: t('title'),
    description: t('lead'),
  });
}

export default async function CulturePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const t = await getTranslations('pages.culture');
  const tc = await getTranslations('common');
  const themes = await getCultureThemes();

  return (
    <>
      <PageHeader title={t('title')} lead={t('lead')} />

      <Container className="py-12 lg:py-16">
        <ul className="grid grid-cols-1 gap-px border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
          {themes.map((theme, i) => (
            <li key={theme.slug} className="bg-ground">
              <Link
                href={{ pathname: '/culture/[slug]', params: { slug: theme.slug } }}
                className="group flex h-full flex-col transition-colors hover:bg-surface"
              >
                <div className="relative aspect-16/9 w-full overflow-hidden">
                  <Picture
                    image={theme.image}
                    seed={`culture-${theme.slug}`}
                    mood={MOODS[i % MOODS.length]}
                    alt={theme.name[l]}
                    demoLabel={tc('demoBadge')}
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    className="h-full w-full object-cover opacity-70 transition-all duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.05] group-hover:opacity-100"
                  />
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <h2 className="text-[19px] transition-colors group-hover:text-sun">
                    {theme.name[l]}
                  </h2>
                  <p className="mt-2.5 flex-1 text-[15px] leading-[1.55] text-ink-muted">
                    {theme.description[l]}
                  </p>
                  <span className="label mt-4 inline-flex items-center gap-1.5 text-[9.5px] text-sun">
                    {t('explore')}
                    <ArrowIcon className="h-3 w-3" />
                  </span>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </Container>
    </>
  );
}
