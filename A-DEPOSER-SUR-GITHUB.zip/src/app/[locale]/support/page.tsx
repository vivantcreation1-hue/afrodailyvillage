import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { buildMetadata } from '@/lib/seo';
import type { Locale } from '@/i18n/routing';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.support' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/support',
    title: t('title'),
    description: t('lead'),
  });
}

export default async function SupportPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const t = await getTranslations('pages.support');
  const items = t.raw('freeItems') as string[];

  return (
    <>
      <PageHeader title={t('title')} lead={t('lead')} />

      <Container size="reading" className="py-12 lg:py-16">
        <p className="text-[clamp(1.05rem,2vw,1.2rem)] leading-[1.7] text-ink">{t('body')}</p>

        <h2 className="mt-12 text-[clamp(1.25rem,2.6vw,1.6rem)]">{t('free')}</h2>
        <ol className="mt-5">
          {items.map((item, i) => (
            <li
              key={i}
              className="grid grid-cols-[2.25rem_minmax(0,1fr)] gap-4 border-t border-line py-5 last:border-b"
            >
              <span className="label pt-1 text-[11px] font-semibold tabular-nums text-sun">
                {String(i + 1).padStart(2, '0')}
              </span>
              <p className="text-[16.5px] leading-[1.6] text-ink">{item}</p>
            </li>
          ))}
        </ol>

        <p className="label mt-10 border-l-2 border-line pl-4 text-[10px] leading-[1.8] text-ink-faint">
          {t('soon')}
        </p>
      </Container>
    </>
  );
}
