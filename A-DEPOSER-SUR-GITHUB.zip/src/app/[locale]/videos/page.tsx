import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { VideoCard } from '@/components/cards/VideoCard';
import { Link } from '@/i18n/navigation';
import { getCountries, getVideoCounts, getVideos, VIDEO_CATEGORIES } from '@/lib/content';
import type { VideoCategoryKey } from '@/lib/content';
import { buildMetadata } from '@/lib/seo';
import type { Locale } from '@/i18n/routing';

type Params = { params: Promise<{ locale: string }>; searchParams: Promise<{ c?: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.videos' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/videos',
    title: t('title'),
    description: t('lead'),
  });
}

export default async function VideosPage({ params, searchParams }: Params) {
  const { locale } = await params;
  const { c } = await searchParams;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const active: VideoCategoryKey = (VIDEO_CATEGORIES as readonly string[]).includes(c ?? '')
    ? (c as VideoCategoryKey)
    : 'all';

  const t = await getTranslations('pages.videos');
  const [videos, counts, countries] = await Promise.all([
    getVideos(active),
    getVideoCounts(),
    getCountries(),
  ]);
  const countryBySlug = new Map(countries.map((x) => [x.slug, x]));

  return (
    <>
      <PageHeader title={t('title')} lead={t('lead')} />

      <Container className="py-12 lg:py-16">
        {/* Les filtres sont de vrais liens : ils fonctionnent sans JavaScript,
            se partagent, et Google peut les suivre. */}
        <nav aria-label={t('filterLabel')} className="mb-10 border-b border-line pb-5">
          <ul className="flex flex-wrap gap-2">
            {VIDEO_CATEGORIES.map((key) => {
              const isActive = key === active;
              return (
                <li key={key}>
                  <Link
                    href={key === 'all' ? '/videos' : { pathname: '/videos', query: { c: key } }}
                    aria-current={isActive ? 'page' : undefined}
                    className={`label inline-flex items-center gap-1.5 border px-3 py-2 text-[10px] transition-colors ${
                      isActive
                        ? 'border-sun bg-sun text-[#1A1206]'
                        : 'border-line text-ink-muted hover:border-line-strong hover:text-ink'
                    }`}
                  >
                    {t(`filters.${key}`)}
                    <span className={isActive ? 'text-[#1A1206]/60' : 'text-ink-faint'}>
                      {counts[key]}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {videos.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {videos.map((video) => (
              <VideoCard
                key={video.slug}
                video={video}
                locale={l}
                country={countryBySlug.get(video.country)}
              />
            ))}
          </div>
        )}
      </Container>
    </>
  );
}

async function EmptyState() {
  const t = await getTranslations('common');
  return (
    <p className="border border-dashed border-line px-6 py-16 text-center text-[16px] text-ink-muted">
      {t('empty')}
    </p>
  );
}
