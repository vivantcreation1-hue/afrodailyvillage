import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { ButtonLink } from '@/components/ui/Button';
import { ArrowIcon } from '@/components/ui/Icon';
import { Picture } from '@/components/media/Picture';
import { getStats } from '@/lib/content';
import { buildMetadata, JsonLd } from '@/lib/seo';
import { site } from '@/lib/site';
import type { Locale } from '@/i18n/routing';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.about' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/about',
    title: t('title'),
    description: t('missionBody'),
  });
}

export default async function AboutPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);

  const t = await getTranslations('pages.about');
  const tc = await getTranslations('common');
  const tn = await getTranslations('nav');
  const tv = await getTranslations('villages');
  const stats = await getStats();
  const values = t.raw('valuesList') as string[];

  return (
    <>
      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'Organization',
          name: site.name,
          url: site.url,
          email: site.contactEmail,
          description: t('missionBody'),
        }}
      />

      <PageHeader title={t('title')} lead={t('missionBody')} />

      <Container className="py-12 lg:py-16">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
          <div className="flex flex-col gap-10">
            <section>
              <h2 className="text-[clamp(1.35rem,3vw,1.9rem)]">{t('vision')}</h2>
              <p className="mt-4 max-w-[60ch] text-[16.5px] leading-[1.65] text-ink-muted">
                {t('visionBody')}
              </p>
            </section>

            <section>
              <h2 className="text-[clamp(1.35rem,3vw,1.9rem)]">{t('how')}</h2>
              <p className="mt-4 max-w-[60ch] text-[16.5px] leading-[1.65] text-ink-muted">
                {t('howBody')}
              </p>
            </section>

            <section>
              <h2 className="text-[clamp(1.35rem,3vw,1.9rem)]">{t('values')}</h2>
              <ul className="mt-5 flex flex-wrap gap-2">
                {values.map((value) => (
                  <li
                    key={value}
                    className="label border border-line px-3 py-2 text-[10px] text-ink-muted"
                  >
                    {value}
                  </li>
                ))}
              </ul>
            </section>

            <section>
              <dl className="grid grid-cols-3 divide-x divide-line border-y border-line">
                <Stat value={stats.villages} label={tv('villagesFilmed')} />
                <Stat value={stats.countries} label={tv('countries')} />
                <Stat value={stats.films} label="films" />
              </dl>
            </section>

            <div className="flex flex-wrap gap-3">
              <ButtonLink href="/contact">
                {tn('contact')}
                <ArrowIcon className="h-4 w-4" />
              </ButtonLink>
              <ButtonLink href="/partners" variant="outline">
                {tn('partners')}
              </ButtonLink>
            </div>
          </div>

          <div className="relative aspect-3/4 overflow-hidden">
            <Picture
              seed="about-portrait"
              mood="dusk"
              alt={t('title')}
              demoLabel={tc('demoBadge')}
              sizes="(max-width: 1024px) 100vw, 40vw"
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </Container>
    </>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex flex-col-reverse gap-1 py-5 pl-5 first:pl-0">
      <dt className="label text-[9.5px] text-ink-faint">{label}</dt>
      <dd className="m-0 font-display text-[clamp(1.5rem,4vw,2.25rem)] font-bold leading-none tabular-nums text-sun">
        {value}
      </dd>
    </div>
  );
}
