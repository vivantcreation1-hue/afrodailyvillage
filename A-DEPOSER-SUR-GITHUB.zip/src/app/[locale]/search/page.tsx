import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { Link } from '@/i18n/navigation';
import { ArrowIcon, SearchIcon } from '@/components/ui/Icon';
import { search, type SearchHit } from '@/lib/content';
import { buildMetadata } from '@/lib/seo';
import type { Locale } from '@/i18n/routing';

type Params = { params: Promise<{ locale: string }>; searchParams: Promise<{ q?: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.search' });
  return {
    ...buildMetadata({
      locale: locale as Locale,
      href: '/search',
      title: t('title'),
      description: t('lead'),
    }),
    // Une page de résultats n'a rien à faire dans Google.
    robots: { index: false, follow: true },
  };
}

/** Où mène chaque type de résultat. */
function hrefFor(hit: SearchHit) {
  switch (hit.kind) {
    case 'article':
      return { pathname: '/stories/[slug]', params: { slug: hit.slug } } as const;
    case 'village':
      return { pathname: '/villages/[slug]', params: { slug: hit.slug } } as const;
    case 'recipe':
      return { pathname: '/food/[slug]', params: { slug: hit.slug } } as const;
    case 'word':
      return '/languages' as const;
    default:
      return '/videos' as const;
  }
}

export default async function SearchPage({ params, searchParams }: Params) {
  const { locale } = await params;
  const { q } = await searchParams;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const t = await getTranslations('pages.search');
  const query = (q ?? '').trim();
  const results = query ? await search(query, l) : [];

  return (
    <>
      <PageHeader title={t('title')} lead={t('lead')}>
        {/* Un formulaire GET tout simple : il marche sans JavaScript,
            et l'adresse obtenue se partage. */}
        <form action="" method="get" className="mt-8 flex max-w-[34rem] flex-col gap-2.5 sm:flex-row">
          <label htmlFor="q" className="sr-only">
            {t('placeholder')}
          </label>
          <input
            id="q"
            name="q"
            type="search"
            defaultValue={query}
            placeholder={t('placeholder')}
            className="h-13 min-w-0 flex-1 border border-line bg-ground px-4 font-body text-[16px] text-ink placeholder:text-ink-faint focus:border-sun focus:outline-none"
          />
          <button
            type="submit"
            className="inline-flex h-13 items-center justify-center gap-2 rounded-xs bg-sun px-6 font-display text-[15px] font-semibold text-[#1A1206] transition-colors hover:bg-sun-deep"
          >
            <SearchIcon className="h-4 w-4" />
            {t('submit')}
          </button>
        </form>
      </PageHeader>

      <Container className="py-12 lg:py-16">
        {!query ? (
          <p className="text-[16px] text-ink-muted">{t('prompt')}</p>
        ) : results.length === 0 ? (
          <p className="border border-dashed border-line px-6 py-14 text-center text-[16px] text-ink-muted">
            {t('noResults', { query })}
          </p>
        ) : (
          <>
            <p className="label mb-6 text-[10px] text-ink-faint">
              {t('resultsFor', { count: results.length, query })}
            </p>
            <ul className="divide-y divide-line border-y border-line">
              {results.map((hit) => (
                <li key={`${hit.kind}-${hit.slug}`}>
                  <Link
                    href={hrefFor(hit)}
                    className="group flex items-start justify-between gap-5 py-5 transition-colors"
                  >
                    <div className="min-w-0">
                      <span className="label mb-1.5 block text-[9.5px] text-sun">
                        {t(`kinds.${hit.kind}`)}
                      </span>
                      <h2 className="text-[18px] leading-[1.25] transition-colors group-hover:text-sun">
                        {hit.title}
                      </h2>
                      <p className="mt-1.5 text-[15px] leading-[1.55] text-ink-muted">
                        {hit.excerpt}
                      </p>
                    </div>
                    <ArrowIcon className="mt-1 h-4 w-4 shrink-0 text-line-strong transition-colors group-hover:text-sun" />
                  </Link>
                </li>
              ))}
            </ul>
          </>
        )}
      </Container>
    </>
  );
}
