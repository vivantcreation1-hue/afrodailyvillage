import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { Picture } from '@/components/media/Picture';
import { CountryTag } from '@/components/ui/CountryTag';
import { VideoCard } from '@/components/cards/VideoCard';
import { ArticleCard } from '@/components/cards/ArticleCard';
import { Breadcrumbs } from '@/components/layout/Breadcrumbs';
import {
  getArticlesByVillage,
  getCountry,
  getLanguages,
  getVideosByVillage,
  getVillage,
  getVillageSlugs,
} from '@/lib/content';
import { buildMetadata, breadcrumbJsonLd, JsonLd } from '@/lib/seo';
import { getPathname } from '@/i18n/navigation';
import { routing, type Locale } from '@/i18n/routing';
import { site } from '@/lib/site';

type Params = { params: Promise<{ locale: string; slug: string }> };

export async function generateStaticParams() {
  const slugs = await getVillageSlugs();
  return routing.locales.flatMap((locale) => slugs.map((slug) => ({ locale, slug })));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { locale, slug } = await params;
  const village = await getVillage(slug);
  if (!village) return {};
  const l = locale as Locale;
  return buildMetadata({
    locale: l,
    href: { pathname: '/villages/[slug]', params: { slug } },
    title: `${village.name}, ${village.region[l]}`,
    description: village.summary[l],
  });
}

export default async function VillagePage({ params }: Params) {
  const { locale, slug } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const village = await getVillage(slug);
  if (!village) notFound();

  const t = await getTranslations('pages.villages');
  const tc = await getTranslations('common');
  const tn = await getTranslations('nav');

  const [country, videos, articles, languages] = await Promise.all([
    getCountry(village.country),
    getVideosByVillage(slug),
    getArticlesByVillage(slug),
    getLanguages(),
  ]);

  const spoken = languages.filter((lang) => village.languages.includes(lang.slug));

  return (
    <>
      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'Place',
          name: village.name,
          description: village.summary[l],
          address: {
            '@type': 'PostalAddress',
            addressRegion: village.region[l],
            addressCountry: country?.iso,
          },
          geo: { '@type': 'GeoCoordinates', latitude: village.lat, longitude: village.lng },
          url: `${site.url}${getPathname({ href: { pathname: '/villages/[slug]', params: { slug } }, locale: l })}`,
        }}
      />
      <JsonLd
        data={breadcrumbJsonLd([
          { name: tn('home'), path: getPathname({ href: '/', locale: l }) },
          { name: tn('villages'), path: getPathname({ href: '/villages', locale: l }) },
          {
            name: village.name,
            path: getPathname({ href: { pathname: '/villages/[slug]', params: { slug } }, locale: l }),
          },
        ])}
      />

      {/* Bandeau visuel */}
      <section className="relative isolate flex min-h-[46svh] flex-col justify-end overflow-hidden">
        <Picture
          image={village.image}
          seed={`village-${village.slug}`}
          alt={village.name}
          demoLabel={tc('demoBadge')}
          priority
          className="absolute inset-0 -z-20 h-full w-full object-cover"
        />
        <div className="scrim absolute inset-0 -z-10" />

        <Container className="pb-10 pt-24">
          <Breadcrumbs
            items={[
              { label: tn('home'), href: '/' },
              { label: tn('villages'), href: '/villages' },
              { label: village.name },
            ]}
          />
          <h1 className="mt-4 text-[clamp(2.2rem,7vw,4rem)]">{village.name}</h1>
          <p className="label mt-4 flex flex-wrap items-center gap-2.5 text-[10px] text-ink-muted">
            {country ? <CountryTag country={country} locale={l} /> : null}
            <span aria-hidden="true" className="text-line-strong">·</span>
            <span>{village.region[l]}</span>
            <span aria-hidden="true" className="text-line-strong">·</span>
            <span className={village.filmed ? 'text-sun' : ''}>
              {village.filmed ? t('filmed') : t('planned')}
            </span>
          </p>
        </Container>
      </section>

      <Container className="py-12 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-[1.6fr_1fr] lg:gap-16">
          <div>
            <p className="text-[clamp(1.05rem,2vw,1.25rem)] leading-[1.6] text-ink">
              {village.summary[l]}
            </p>
            <p className="mt-5 text-[16.5px] leading-[1.65] text-ink-muted">
              {village.description[l]}
            </p>
          </div>

          <dl className="divide-y divide-line border-y border-line text-[15px]">
            <div className="flex flex-col gap-1 py-4">
              <dt className="label text-[9.5px] text-ink-faint">{t('coordinates')}</dt>
              <dd className="m-0 font-mono text-[14px] tabular-nums text-ink">
                {village.lat.toFixed(3)}°N · {Math.abs(village.lng).toFixed(3)}°W
              </dd>
            </div>
            <div className="flex flex-col gap-1 py-4">
              <dt className="label text-[9.5px] text-ink-faint">{t('languagesSpoken')}</dt>
              <dd className="m-0 text-ink">
                {spoken.length ? spoken.map((s) => s.name).join(' · ') : '—'}
              </dd>
            </div>
          </dl>
        </div>
      </Container>

      {videos.length > 0 ? (
        <Container className="pb-12 lg:pb-16">
          <SectionHeader
            label={t('filmed')}
            title={t('videosFrom', { place: village.name })}
          />
          <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {videos.map((v) => (
              <VideoCard key={v.slug} video={v} locale={l} country={country} />
            ))}
          </div>
        </Container>
      ) : null}

      {articles.length > 0 ? (
        <Container className="pb-16 lg:pb-24">
          <SectionHeader label={tn('stories')} title={t('storiesFrom', { place: village.name })} />
          <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {articles.map((a, i) => (
              <ArticleCard key={a.slug} article={a} locale={l} index={i} country={country} />
            ))}
          </div>
        </Container>
      ) : null}
    </>
  );
}
