import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { VillageCard } from '@/components/cards/VillageCard';
import { Link } from '@/i18n/navigation';
import { ArrowIcon } from '@/components/ui/Icon';
import { getCountries, getVillages } from '@/lib/content';
import { buildMetadata } from '@/lib/seo';
import type { Locale } from '@/i18n/routing';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.villages' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/villages',
    title: t('title'),
    description: t('lead'),
  });
}

export default async function VillagesPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const t = await getTranslations('pages.villages');
  const [villages, countries] = await Promise.all([getVillages(), getCountries()]);
  const countryBySlug = new Map(countries.map((c) => [c.slug, c]));
  const countriesWithVillages = countries.filter((c) =>
    villages.some((v) => v.country === c.slug),
  );

  return (
    <>
      <PageHeader
        title={t('title')}
        lead={t('lead')}
        meta={
          <ul className="flex flex-wrap gap-2">
            {countriesWithVillages.map((c) => (
              <li key={c.slug}>
                <Link
                  href={{ pathname: '/countries/[slug]', params: { slug: c.slug } }}
                  className="label inline-flex items-center gap-2 border border-line px-3 py-2 text-[10px] text-ink-muted transition-colors hover:border-sun hover:text-sun"
                >
                  <span className="border border-line-strong px-[3px] py-[1px] text-[8.5px] leading-[1.3]">
                    {c.iso}
                  </span>
                  {c.name[l]}
                  <ArrowIcon className="h-3 w-3" />
                </Link>
              </li>
            ))}
          </ul>
        }
      />

      <Container className="py-12 lg:py-16">
        <div className="grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {villages.map((village, i) => (
            <VillageCard
              key={village.slug}
              village={village}
              locale={l}
              index={i}
              country={countryBySlug.get(village.country)}
            />
          ))}
        </div>
      </Container>
    </>
  );
}
