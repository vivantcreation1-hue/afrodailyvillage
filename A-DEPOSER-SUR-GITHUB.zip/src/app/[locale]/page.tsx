import { setRequestLocale } from 'next-intl/server';
import type { Locale } from '@/i18n/routing';

import { Hero } from '@/components/home/Hero';
import { LatestVideos } from '@/components/home/LatestVideos';
import { FeaturedStory } from '@/components/home/FeaturedStory';
import { VillageMap } from '@/components/home/VillageMap';
import { WordOfDay } from '@/components/home/WordOfDay';
import { FoodStrip } from '@/components/home/FoodStrip';
import { YouTubeBlock } from '@/components/home/YouTubeBlock';
import { NewsletterBlock } from '@/components/home/NewsletterBlock';

/**
 * LA PAGE D'ACCUEIL
 *
 * L'ordre des sections raconte une histoire :
 * on émeut (hero) → on montre que ça vit (vidéos) → on prouve qu'on écrit
 * (récit) → on donne envie d'explorer (carte) → on donne une raison de revenir
 * demain (mot du jour) → on capte la recherche « cuisine » → on convertit
 * en abonné YouTube → on garde le contact (newsletter).
 */
export default async function HomePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  return (
    <>
      <Hero />
      <LatestVideos locale={l} />
      <FeaturedStory locale={l} />
      <VillageMap locale={l} />
      <WordOfDay locale={l} />
      <FoodStrip locale={l} />
      <YouTubeBlock locale={l} />
      <NewsletterBlock />
    </>
  );
}
