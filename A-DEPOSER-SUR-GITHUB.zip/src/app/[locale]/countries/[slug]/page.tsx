import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { PageHeader } from '@/components/layout/PageHeader';
import { Breadcrumbs } from '@/components/layout/Breadcrumbs';
import { VillageCard } from '@/components/cards/VillageCard';
import { VideoCard } from '@/components/cards/VideoCard';
import { ArticleCard } from '@/components/cards/ArticleCard';
import { RecipeCard } from '@/components/cards/RecipeCard';
import {
  getArticlesByCountry,
  getCountry,
  getCountrySlugs,
  getRecipesByCountry,
  getVideosByCountry,
  getVillagesByCountry,
} from '@/lib/content';
import { buildMetadata, breadcrumbJsonLd, JsonLd } from '@/lib/seo';
import { getPathname } from '@/i18n/navigation';
import { routing, type Locale } from '@/i18n/routing';

type Params = { params: Promise<{ locale: string; slug: string }> };

export async function generateStaticParams() {
  const slugs = await getCountrySlugs();
  return routing.locales.flatMap((locale) => slugs.map((slug) => ({ locale, slug })));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { locale, slug } = await params;
  const country = await getCountry(slug);
  if (!country) return {};
  const l = locale as Locale;
  return buildMetadata({
    locale: l,
    href: { pathname: '/countries/[slug]', params: { slug } },
    title: country.name[l],
    description: country.intro[l],
  });
}

export default async function CountryPage({ params }: Params) {
  const { locale, slug } = await params;
  setRequestLocale(locale as Locale);
  const l = locale as Locale;

  const country = await getCountry(slug);
  if (!country) notFound();

  const t = await getTranslations('pages.villages');
  const tn = await getTranslations('nav');
  const [villages, videos, articles, recipes] = await Promise.all([
    getVillagesByCountry(slug),
    getVideosByCountry(slug),
    getArticlesByCountry(slug),
    getRecipesByCountry(slug),
  ]);

  return (
    <>
      <JsonLd
        data={breadcrumbJsonLd([
          { name: tn('home'), path: getPathname({ href: '/', locale: l }) },
          { name: tn('villages'), path: getPathname({ href: '/villages', locale: l }) },
          {
            name: country.name[l],
            path: getPathname({ href: { pathname: '/countries/[slug]', params: { slug } }, locale: l }),
          },
        ])}
      />

      <PageHeader title={country.name[l]} lead={country.intro[l]}>
        <div className="mt-7">
          <Breadcrumbs
            items={[
              { label: tn('home'), href: '/' },
              { label: tn('villages'), href: '/villages' },
              { label: country.name[l] },
            ]}
          />
        </div>
      </PageHeader>

      {villages.length > 0 ? (
        <Container className="py-12 lg:py-16">
          <SectionHeader
            label={t('byCountry')}
            title={t('villagesIn', { country: country.name[l] })}
          />
          <div className="grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
            {villages.map((v, i) => (
              <VillageCard key={v.slug} village={v} locale={l} index={i} country={country} />
            ))}
          </div>
        </Container>
      ) : null}

      {videos.length > 0 ? (
        <Container className="pb-12 lg:pb-16">
          <SectionHeader label={tn('videos')} title={tn('videos')} />
          <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {videos.map((v) => (
              <VideoCard key={v.slug} video={v} locale={l} country={country} />
            ))}
          </div>
        </Container>
      ) : null}

      {articles.length > 0 ? (
        <Container className="pb-12 lg:pb-16">
          <SectionHeader label={tn('stories')} title={tn('stories')} />
          <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {articles.map((a, i) => (
              <ArticleCard key={a.slug} article={a} locale={l} index={i} country={country} />
            ))}
          </div>
        </Container>
      ) : null}

      {recipes.length > 0 ? (
        <Container className="pb-16 lg:pb-24">
          <SectionHeader label={tn('food')} title={tn('food')} />
          <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {recipes.map((r, i) => (
              <RecipeCard key={r.slug} recipe={r} locale={l} index={i} country={country} />
            ))}
          </div>
        </Container>
      ) : null}
    </>
  );
}
