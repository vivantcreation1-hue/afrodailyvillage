import type { Metadata } from 'next';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { PageHeader } from '@/components/layout/PageHeader';
import { ButtonLink } from '@/components/ui/Button';
import { ArrowIcon } from '@/components/ui/Icon';
import { buildMetadata } from '@/lib/seo';
import type { Locale } from '@/i18n/routing';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'pages.partners' });
  return buildMetadata({
    locale: locale as Locale,
    href: '/partners',
    title: t('title'),
    description: t('body'),
  });
}

export default async function PartnersPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const t = await getTranslations('pages.partners');

  const offers = [
    { key: 'sponsoring', bodyKey: 'sponsoringBody' },
    { key: 'advertising', bodyKey: 'advertisingBody' },
    { key: 'production', bodyKey: 'productionBody' },
    { key: 'media', bodyKey: 'mediaBody' },
  ] as const;

  return (
    <>
      <PageHeader title={t('title')} lead={t('lead')} />

      <Container className="py-12 lg:py-16">
        <p className="max-w-[62ch] text-[clamp(1.05rem,2vw,1.2rem)] leading-[1.65] text-ink-muted">
          {t('body')}
        </p>

        <ul className="mt-12 grid grid-cols-1 gap-px border border-line bg-line sm:grid-cols-2">
          {offers.map(({ key, bodyKey }) => (
            <li key={key} className="bg-ground p-7">
              <h2 className="text-[19px]">{t(key)}</h2>
              <p className="mt-3 text-[15.5px] leading-[1.6] text-ink-muted">{t(bodyKey)}</p>
            </li>
          ))}
        </ul>

        <div className="mt-12">
          <ButtonLink href="/contact" size="lg">
            {t('cta')}
            <ArrowIcon className="h-4 w-4" />
          </ButtonLink>
        </div>
      </Container>
    </>
  );
}
