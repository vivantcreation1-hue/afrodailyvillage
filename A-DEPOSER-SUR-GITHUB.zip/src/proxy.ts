import createMiddleware from 'next-intl/middleware';
import { routing } from './i18n/routing';

/**
 * Redirige automatiquement le visiteur vers /en ou /fr selon la langue
 * de son navigateur, et gère les adresses traduites.
 */
export default createMiddleware(routing);

export const config = {
  matcher: [
    // tout, sauf les fichiers internes, l'API, le studio et les fichiers statiques
    '/((?!api|studio|_next|_vercel|.*\\..*).*)',
  ],
};
