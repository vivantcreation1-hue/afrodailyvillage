/**
 * Les réglages de connexion au tableau de bord.
 *
 * Tant que NEXT_PUBLIC_SANITY_PROJECT_ID est vide, le site continue de
 * fonctionner avec le contenu de démonstration. Il n'y a donc jamais
 * d'écran d'erreur : le site marche avant et après le branchement.
 */

export const projectId = process.env.NEXT_PUBLIC_SANITY_PROJECT_ID ?? '';
export const dataset = process.env.NEXT_PUBLIC_SANITY_DATASET ?? 'production';
export const apiVersion = process.env.NEXT_PUBLIC_SANITY_API_VERSION ?? '2026-01-01';

/** Vrai seulement quand le tableau de bord est réellement branché. */
export const sanityEnabled = projectId.length > 0;
