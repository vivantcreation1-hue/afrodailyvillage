import type { SchemaTypeDefinition } from 'sanity';
import { localeBlock, localeList, localeString, localeText } from './locale';
import {
  article,
  author,
  country,
  cultureTheme,
  language,
  recipe,
  siteSettings,
  video,
  village,
  word,
} from './documents';

export const schemaTypes: SchemaTypeDefinition[] = [
  // briques bilingues
  localeString,
  localeText,
  localeBlock,
  localeList,
  // fiches
  article,
  video,
  village,
  country,
  recipe,
  language,
  word,
  cultureTheme,
  author,
  siteSettings,
];
