import { defineArrayMember, defineField, defineType } from 'sanity';

/**
 * LES NEUF TYPES DE FICHES
 *
 * C'est ce que vous verrez dans le menu de gauche de votre tableau de bord.
 * Les intitulés sont en français : c'est vous qui les lisez tous les jours.
 * Le contenu, lui, est bilingue.
 */

/* ---------- petites briques réutilisées ---------- */

const slugField = defineField({
  name: 'slug',
  title: 'Adresse web',
  type: 'slug',
  description: 'Cliquez sur « Generate ». C’est ce qui apparaîtra dans le lien de la page.',
  options: { source: (doc: Record<string, unknown>) => {
    const title = doc.title as { en?: string } | undefined;
    const name = doc.name as { en?: string } | string | undefined;
    const word = doc.word as string | undefined;
    if (title?.en) return title.en;
    if (typeof name === 'string') return name;
    if (name?.en) return name.en;
    return word ?? '';
  }, maxLength: 90 },
  validation: (rule) => rule.required().error('Une adresse web est obligatoire.'),
});

const mainImage = defineField({
  name: 'mainImage',
  title: 'Photo principale',
  type: 'image',
  description: 'Celle qui s’affiche en grand, et sur les réseaux quand on partage le lien.',
  options: { hotspot: true },
  fields: [
    { name: 'alt', title: 'Description de l’image', type: 'string',
      description: 'Ce que montre la photo, en une phrase. Pour les malvoyants et pour Google.' },
  ],
});

const gallery = defineField({
  name: 'gallery',
  title: 'Galerie photo',
  type: 'array',
  of: [
    defineArrayMember({
      type: 'image',
      options: { hotspot: true },
      fields: [
        { name: 'alt', title: 'Description de l’image', type: 'string' },
        { name: 'caption', title: 'Légende', type: 'string' },
      ],
    }),
  ],
  options: { layout: 'grid' },
});

/* ---------- 1. PAYS ---------- */

export const country = defineType({
  name: 'country',
  title: 'Pays',
  type: 'document',
  icon: () => '🗺️',
  fields: [
    defineField({ name: 'name', title: 'Nom', type: 'localeString', validation: (r) => r.required() }),
    slugField,
    defineField({
      name: 'iso',
      title: 'Sigle (2 lettres)',
      type: 'string',
      description: 'SN pour le Sénégal, GM pour la Gambie, GW pour la Guinée-Bissau…',
      validation: (r) => r.required().length(2).uppercase(),
    }),
    defineField({ name: 'intro', title: 'Présentation', type: 'localeText' }),
    mainImage,
  ],
  preview: { select: { title: 'name.en', subtitle: 'iso', media: 'mainImage' } },
});

/* ---------- 2. VILLAGE ---------- */

export const village = defineType({
  name: 'village',
  title: 'Village',
  type: 'document',
  icon: () => '🛖',
  fields: [
    defineField({ name: 'name', title: 'Nom du village', type: 'string', validation: (r) => r.required() }),
    slugField,
    defineField({ name: 'country', title: 'Pays', type: 'reference', to: [{ type: 'country' }], validation: (r) => r.required() }),
    defineField({ name: 'region', title: 'Région', type: 'localeString' }),
    defineField({
      name: 'location',
      title: 'Position sur la carte',
      type: 'geopoint',
      description: 'Cherchez le village sur la carte et cliquez dessus.',
    }),
    defineField({ name: 'summary', title: 'Résumé (une ou deux phrases)', type: 'localeText' }),
    defineField({ name: 'description', title: 'Description complète', type: 'localeText' }),
    defineField({
      name: 'languages',
      title: 'Langues parlées',
      type: 'array',
      of: [defineArrayMember({ type: 'reference', to: [{ type: 'language' }] })],
    }),
    defineField({
      name: 'filmed',
      title: 'Déjà filmé ?',
      type: 'boolean',
      description: 'Décochez pour les villages simplement prévus.',
      initialValue: false,
    }),
    mainImage,
    gallery,
  ],
  preview: { select: { title: 'name', subtitle: 'region.fr', media: 'mainImage' } },
});

/* ---------- 3. VIDÉO ---------- */

export const video = defineType({
  name: 'video',
  title: 'Vidéo',
  type: 'document',
  icon: () => '▶️',
  fields: [
    defineField({ name: 'title', title: 'Titre', type: 'localeString', validation: (r) => r.required() }),
    slugField,
    defineField({
      name: 'youtubeId',
      title: 'Identifiant YouTube',
      type: 'string',
      description: 'Dans youtube.com/watch?v=ABC123, l’identifiant est ABC123.',
    }),
    defineField({ name: 'category', title: 'Catégorie affichée', type: 'localeString' }),
    defineField({
      name: 'categoryKey',
      title: 'Filtre',
      type: 'string',
      description: 'Sous quel bouton cette vidéo apparaît sur la page Vidéos.',
      options: {
        list: [
          { title: 'Documentaire', value: 'documentary' },
          { title: 'Vie quotidienne', value: 'dailyLife' },
          { title: 'Cuisine', value: 'food' },
          { title: 'Culture', value: 'culture' },
          { title: 'Traditions', value: 'traditions' },
          { title: 'Interview', value: 'interviews' },
          { title: 'Short', value: 'shorts' },
        ],
      },
      validation: (r) => r.required(),
    }),
    defineField({ name: 'country', title: 'Pays', type: 'reference', to: [{ type: 'country' }] }),
    defineField({ name: 'village', title: 'Village', type: 'reference', to: [{ type: 'village' }] }),
    defineField({
      name: 'durationSeconds',
      title: 'Durée, en secondes',
      type: 'number',
      description: 'Une vidéo de 12 min 34 s = 754 secondes.',
      validation: (r) => r.min(1),
    }),
    defineField({ name: 'publishedAt', title: 'Date de publication', type: 'date', validation: (r) => r.required() }),
    defineField({
      name: 'format',
      title: 'Format',
      type: 'string',
      options: { list: [{ title: 'Film long', value: 'film' }, { title: 'Short', value: 'short' }] },
      initialValue: 'film',
    }),
    mainImage,
  ],
  orderings: [{ title: 'Plus récentes d’abord', name: 'recent', by: [{ field: 'publishedAt', direction: 'desc' }] }],
  preview: { select: { title: 'title.en', subtitle: 'publishedAt', media: 'mainImage' } },
});

/* ---------- 4. ARTICLE ---------- */

export const article = defineType({
  name: 'article',
  title: 'Article',
  type: 'document',
  icon: () => '📰',
  fields: [
    defineField({ name: 'title', title: 'Titre', type: 'localeString', validation: (r) => r.required() }),
    slugField,
    defineField({
      name: 'standfirst',
      title: 'Chapô',
      type: 'localeText',
      description: 'Les deux phrases sous le titre. C’est aussi ce que Google affichera.',
    }),
    defineField({ name: 'category', title: 'Catégorie', type: 'localeString' }),
    defineField({ name: 'country', title: 'Pays', type: 'reference', to: [{ type: 'country' }] }),
    defineField({ name: 'village', title: 'Village', type: 'reference', to: [{ type: 'village' }] }),
    defineField({ name: 'author', title: 'Auteur', type: 'reference', to: [{ type: 'author' }] }),
    defineField({ name: 'publishedAt', title: 'Date de publication', type: 'date', validation: (r) => r.required() }),
    defineField({
      name: 'readingMinutes',
      title: 'Temps de lecture, en minutes',
      type: 'number',
      description: 'Comptez environ 1 minute pour 200 mots.',
    }),
    defineField({
      name: 'featured',
      title: 'À la une sur l’accueil ?',
      type: 'boolean',
      description: 'Un seul article à la fois.',
      initialValue: false,
    }),
    mainImage,
    defineField({ name: 'body', title: 'Le texte de l’article', type: 'localeBlock' }),
    defineField({ name: 'relatedVideo', title: 'Vidéo liée', type: 'reference', to: [{ type: 'video' }] }),
  ],
  orderings: [{ title: 'Plus récents d’abord', name: 'recent', by: [{ field: 'publishedAt', direction: 'desc' }] }],
  preview: { select: { title: 'title.en', subtitle: 'publishedAt', media: 'mainImage' } },
});

/* ---------- 5. RECETTE ---------- */

export const recipe = defineType({
  name: 'recipe',
  title: 'Recette',
  type: 'document',
  icon: () => '🍲',
  fields: [
    defineField({ name: 'name', title: 'Nom du plat', type: 'localeString', validation: (r) => r.required() }),
    slugField,
    defineField({ name: 'country', title: 'Pays', type: 'reference', to: [{ type: 'country' }] }),
    defineField({ name: 'region', title: 'Région', type: 'localeString' }),
    defineField({ name: 'summary', title: 'Résumé', type: 'localeText' }),
    defineField({ name: 'minutes', title: 'Temps total, en minutes', type: 'number' }),
    defineField({ name: 'serves', title: 'Nombre de personnes', type: 'number' }),
    defineField({
      name: 'ingredients',
      title: 'Ingrédients',
      type: 'localeList',
      description: 'Un ingrédient par entrée. Appuyez sur Entrée pour passer au suivant.',
    }),
    defineField({ name: 'steps', title: 'Étapes de préparation', type: 'localeList' }),
    defineField({ name: 'story', title: 'L’histoire du plat', type: 'localeText' }),
    mainImage,
    defineField({ name: 'relatedVideo', title: 'Vidéo liée', type: 'reference', to: [{ type: 'video' }] }),
  ],
  preview: { select: { title: 'name.en', subtitle: 'region.fr', media: 'mainImage' } },
});

/* ---------- 6. LANGUE ---------- */

export const language = defineType({
  name: 'language',
  title: 'Langue',
  type: 'document',
  icon: () => '🗣️',
  fields: [
    defineField({ name: 'name', title: 'Nom de la langue', type: 'string', validation: (r) => r.required() }),
    slugField,
    defineField({ name: 'speakers', title: 'Nombre de locuteurs (texte libre)', type: 'localeString' }),
    defineField({ name: 'description', title: 'Présentation', type: 'localeText' }),
    defineField({ name: 'region', title: 'Où on la parle', type: 'localeString' }),
  ],
  preview: { select: { title: 'name', subtitle: 'region.fr' } },
});

/* ---------- 7. MOT ---------- */

export const word = defineType({
  name: 'word',
  title: 'Mot',
  type: 'document',
  icon: () => '💬',
  fields: [
    defineField({ name: 'word', title: 'Le mot ou l’expression', type: 'string', validation: (r) => r.required() }),
    slugField,
    defineField({ name: 'language', title: 'Langue', type: 'reference', to: [{ type: 'language' }], validation: (r) => r.required() }),
    defineField({
      name: 'pronunciation',
      title: 'Prononciation écrite',
      type: 'string',
      description: 'Comment ça se dit, écrit simplement : « djam tann ».',
    }),
    defineField({
      name: 'audio',
      title: 'Prononciation enregistrée',
      type: 'file',
      description: 'Un enregistrement au téléphone suffit. Format .mp3 ou .m4a.',
      options: { accept: 'audio/*' },
    }),
    defineField({ name: 'meaning', title: 'Signification', type: 'localeText' }),
    defineField({ name: 'example', title: 'Exemple dans la langue', type: 'localeString' }),
    defineField({ name: 'exampleTranslation', title: 'Traduction de l’exemple', type: 'localeText' }),
    defineField({ name: 'region', title: 'Où on l’emploie', type: 'localeString' }),
  ],
  preview: { select: { title: 'word', subtitle: 'pronunciation' } },
});

/* ---------- 8. THÈME CULTUREL ---------- */

export const cultureTheme = defineType({
  name: 'cultureTheme',
  title: 'Thème culturel',
  type: 'document',
  icon: () => '🥁',
  fields: [
    defineField({ name: 'name', title: 'Nom du thème', type: 'localeString', validation: (r) => r.required() }),
    slugField,
    defineField({ name: 'description', title: 'Description', type: 'localeText' }),
    mainImage,
  ],
  preview: { select: { title: 'name.en', media: 'mainImage' } },
});

/* ---------- 9. AUTEUR ---------- */

export const author = defineType({
  name: 'author',
  title: 'Auteur',
  type: 'document',
  icon: () => '✍️',
  fields: [
    defineField({ name: 'name', title: 'Nom', type: 'string', validation: (r) => r.required() }),
    slugField,
    defineField({ name: 'role', title: 'Fonction', type: 'localeString' }),
    defineField({ name: 'bio', title: 'Biographie', type: 'localeText' }),
    defineField({ name: 'photo', title: 'Photo', type: 'image', options: { hotspot: true } }),
  ],
  preview: { select: { title: 'name', subtitle: 'role.fr', media: 'photo' } },
});

/* ---------- RÉGLAGES DU SITE ---------- */

export const siteSettings = defineType({
  name: 'siteSettings',
  title: 'Réglages du site',
  type: 'document',
  icon: () => '⚙️',
  fields: [
    defineField({ name: 'youtubeUrl', title: 'Lien de la chaîne YouTube', type: 'url' }),
    defineField({ name: 'tiktokUrl', title: 'Lien TikTok', type: 'url' }),
    defineField({ name: 'instagramUrl', title: 'Lien Instagram', type: 'url' }),
    defineField({ name: 'contactEmail', title: 'Adresse e-mail de contact', type: 'string' }),
    defineField({ name: 'footerBlurb', title: 'Phrase du pied de page', type: 'localeString' }),
    defineField({
      name: 'defaultOgImage',
      title: 'Image de partage par défaut',
      type: 'image',
      description: 'Celle qui s’affiche quand on colle le lien du site sur WhatsApp ou Facebook.',
    }),
  ],
  preview: { prepare: () => ({ title: 'Réglages du site' }) },
});
