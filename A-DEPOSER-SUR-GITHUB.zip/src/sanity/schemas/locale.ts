import { defineField, defineType } from 'sanity';

/**
 * LES CHAMPS BILINGUES
 *
 * Chaque texte du site existe en deux versions : anglais et français.
 * Plutôt que de créer deux fois chaque fiche, on met les deux langues
 * côte à côte dans le même champ. Dans le tableau de bord, vous verrez
 * simplement deux cases : « English » et « Français ».
 *
 * L'anglais est obligatoire (c'est la langue par défaut du site).
 * Le français est facultatif : vous pouvez publier en anglais d'abord
 * et traduire plus tard, sans rien casser.
 */

export const localeString = defineType({
  name: 'localeString',
  title: 'Texte court bilingue',
  type: 'object',
  fields: [
    defineField({
      name: 'en',
      title: 'English',
      type: 'string',
      validation: (rule) => rule.required().error('Le texte anglais est obligatoire.'),
    }),
    defineField({ name: 'fr', title: 'Français', type: 'string' }),
  ],
});

export const localeText = defineType({
  name: 'localeText',
  title: 'Texte long bilingue',
  type: 'object',
  fields: [
    defineField({
      name: 'en',
      title: 'English',
      type: 'text',
      rows: 3,
      validation: (rule) => rule.required().error('Le texte anglais est obligatoire.'),
    }),
    defineField({ name: 'fr', title: 'Français', type: 'text', rows: 3 }),
  ],
});

export const localeBlock = defineType({
  name: 'localeBlock',
  title: 'Article bilingue',
  type: 'object',
  fields: [
    defineField({
      name: 'en',
      title: 'English',
      type: 'array',
      of: [
        { type: 'block' },
        {
          type: 'image',
          options: { hotspot: true },
          fields: [{ name: 'caption', title: 'Légende', type: 'string' }],
        },
      ],
    }),
    defineField({
      name: 'fr',
      title: 'Français',
      type: 'array',
      of: [
        { type: 'block' },
        {
          type: 'image',
          options: { hotspot: true },
          fields: [{ name: 'caption', title: 'Légende', type: 'string' }],
        },
      ],
    }),
  ],
});

export const localeList = defineType({
  name: 'localeList',
  title: 'Liste bilingue',
  type: 'object',
  fields: [
    defineField({
      name: 'en',
      title: 'English',
      type: 'array',
      of: [{ type: 'string' }],
      options: { layout: 'tags' },
    }),
    defineField({
      name: 'fr',
      title: 'Français',
      type: 'array',
      of: [{ type: 'string' }],
      options: { layout: 'tags' },
    }),
  ],
});
