import type { Country } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

/**
 * L'étiquette pays.
 *
 * On n'utilise PAS les drapeaux emoji : Windows ne sait pas les afficher
 * (il montre « SN » au lieu du drapeau du Sénégal), et une bonne partie
 * de nos lecteurs sera sous Windows. Un petit sigle encadré s'affiche
 * partout de la même façon, et fait plus sobre.
 */
export function CountryTag({
  country,
  locale,
  className = '',
}: {
  country: Country;
  locale: Locale;
  className?: string;
}) {
  return (
    <span className={`inline-flex items-center gap-1.5 ${className}`}>
      <span className="border border-line-strong px-[3px] py-[1px] text-[8.5px] leading-[1.3] text-ink-faint">
        {country.iso}
      </span>
      <span>{country.name[locale]}</span>
    </span>
  );
}
