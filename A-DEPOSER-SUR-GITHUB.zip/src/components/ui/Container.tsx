import type { ReactNode } from 'react';

/**
 * La largeur de page. Une seule source de vérité pour les marges latérales :
 * si on veut respirer davantage un jour, on change ici et nulle part ailleurs.
 */
export function Container({
  children,
  className = '',
  size = 'default',
}: {
  children: ReactNode;
  className?: string;
  size?: 'default' | 'wide' | 'reading';
}) {
  const width =
    size === 'wide' ? 'max-w-[1440px]' : size === 'reading' ? 'max-w-[68ch]' : 'max-w-[1200px]';
  return <div className={`mx-auto w-full px-5 sm:px-7 lg:px-10 ${width} ${className}`}>{children}</div>;
}
