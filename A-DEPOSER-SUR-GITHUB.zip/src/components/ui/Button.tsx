import type { ComponentProps, ReactNode } from 'react';
import { Link } from '@/i18n/navigation';

type Variant = 'solid' | 'outline' | 'ghost' | 'youtube';
type Size = 'sm' | 'md' | 'lg';

const base =
  'inline-flex items-center justify-center gap-2 font-display font-semibold tracking-tight ' +
  'transition-colors duration-200 rounded-xs select-none';

const variants: Record<Variant, string> = {
  solid: 'bg-sun text-[#1A1206] hover:bg-sun-deep',
  outline: 'border border-line-strong text-ink hover:border-sun hover:text-sun',
  ghost: 'text-ink-muted hover:text-sun',
  youtube: 'bg-[#FF0033] text-white hover:bg-[#D9002B]',
};

const sizes: Record<Size, string> = {
  sm: 'h-9 px-3.5 text-[13px]',
  md: 'h-11 px-5 text-[15px]',
  lg: 'h-13 px-7 text-[16px]',
};

interface Shared {
  variant?: Variant;
  size?: Size;
  className?: string;
  children: ReactNode;
}

/** Bouton qui mène à une page interne (l'adresse est traduite automatiquement). */
export function ButtonLink({
  href,
  variant = 'solid',
  size = 'md',
  className = '',
  children,
}: Shared & { href: ComponentProps<typeof Link>['href'] }) {
  return (
    <Link href={href} className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}>
      {children}
    </Link>
  );
}

/** Bouton qui mène à un site extérieur (YouTube, TikTok, Instagram). */
export function ButtonExternal({
  href,
  variant = 'solid',
  size = 'md',
  className = '',
  children,
}: Shared & { href: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
    >
      {children}
    </a>
  );
}

export function Button({
  variant = 'solid',
  size = 'md',
  className = '',
  children,
  ...rest
}: Shared & ComponentProps<'button'>) {
  return (
    <button className={`${base} ${variants[variant]} ${sizes[size]} ${className}`} {...rest}>
      {children}
    </button>
  );
}
