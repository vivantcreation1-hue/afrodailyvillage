import type { ReactNode } from 'react';

/**
 * L'en-tête de section, identique partout : une étiquette discrète,
 * un titre, et un lien à droite. C'est ce qui donne au site sa régularité.
 */
export function SectionHeader({
  label,
  title,
  action,
  intro,
}: {
  label: string;
  title: string;
  action?: ReactNode;
  intro?: string;
}) {
  return (
    <div className="mb-8 flex flex-col gap-4 border-b border-line pb-5 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        <span className="label mb-2.5 block text-sun">{label}</span>
        <h2 className="text-[clamp(1.5rem,3.4vw,2.1rem)]">{title}</h2>
        {intro ? <p className="mt-3 max-w-[58ch] text-[15.5px] text-ink-muted">{intro}</p> : null}
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </div>
  );
}
