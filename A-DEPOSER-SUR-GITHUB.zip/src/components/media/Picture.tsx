import Image from 'next/image';
import { DemoBadge, DemoPhoto } from './DemoPhoto';
import type { DemoMood } from '@/lib/demo-photo';
import type { ImageRef } from '@/lib/content';

/**
 * LE COMPOSANT IMAGE DU SITE
 *
 * Un seul endroit décide de ce qui s'affiche :
 * — s'il y a une vraie photo dans le tableau de bord, on l'affiche,
 *   redimensionnée automatiquement au format et au poids qu'il faut ;
 * — sinon, on affiche un visuel de démonstration, clairement étiqueté.
 *
 * Aucune page n'a besoin de savoir laquelle des deux : c'est pour cela
 * que remplacer une image de démonstration par une vraie photo ne demande
 * aucune modification du code.
 */
export function Picture({
  image,
  seed,
  mood,
  alt,
  demoLabel,
  className = '',
  sizes = '100vw',
  priority = false,
}: {
  image?: ImageRef;
  /** Clé du visuel de remplacement, si aucune vraie photo n'existe. */
  seed: string;
  mood?: DemoMood;
  alt: string;
  demoLabel: string;
  className?: string;
  sizes?: string;
  priority?: boolean;
}) {
  if (image?.url) {
    return (
      <Image
        src={image.url}
        alt={image.alt ?? alt}
        fill
        sizes={sizes}
        priority={priority}
        placeholder={image.lqip ? 'blur' : 'empty'}
        blurDataURL={image.lqip}
        className={className || 'object-cover'}
      />
    );
  }

  return (
    <>
      <DemoPhoto seed={seed} mood={mood} alt={alt} className={className} />
      <DemoBadge label={demoLabel} />
    </>
  );
}
