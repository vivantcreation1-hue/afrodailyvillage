import { buildScene, type DemoMood } from '@/lib/demo-photo';

interface DemoPhotoProps {
  /** Clé stable — le même texte donne toujours le même visuel. */
  seed: string;
  /** Forcer une ambiance précise (aube, midi, crépuscule, nuit, feu). */
  mood?: DemoMood;
  className?: string;
  /** Texte alternatif pour les lecteurs d'écran. */
  alt: string;
}

/**
 * Visuel de démonstration : un paysage de village en silhouette, dessiné
 * en SVG dans les couleurs de la marque. Zéro requête réseau, zéro octet
 * téléchargé, et remplaçable par une vraie photo en changeant un seul
 * composant le jour où les tournages arrivent.
 */
export function DemoPhoto({ seed, mood, className = '', alt }: DemoPhotoProps) {
  const s = buildScene(seed, mood);
  const id = seed.replace(/[^a-zA-Z0-9]/g, '').slice(0, 14) || 'adv';

  return (
    <svg
      viewBox="0 0 100 100"
      preserveAspectRatio="xMidYMid slice"
      className={className}
      role="img"
      aria-label={alt}
    >
      <defs>
        <linearGradient id={`sky-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={s.sky[0]} />
          <stop offset="100%" stopColor={s.sky[1]} />
        </linearGradient>
        <radialGradient id={`glow-${id}`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={s.haze} stopOpacity="0.85" />
          <stop offset="100%" stopColor={s.haze} stopOpacity="0" />
        </radialGradient>
        <filter id={`grain-${id}`} x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" seed="7" />
          <feColorMatrix type="saturate" values="0" />
          <feComponentTransfer>
            <feFuncA type="linear" slope="0.16" />
          </feComponentTransfer>
        </filter>
      </defs>

      {/* Ciel */}
      <rect width="100" height="100" fill={`url(#sky-${id})`} />

      {/* Halo autour du soleil */}
      <circle cx={s.sunX} cy={s.sunY} r="42" fill={`url(#glow-${id})`} />
      <circle cx={s.sunX} cy={s.sunY} r="7.5" fill={s.sun} opacity="0.95" />

      {/* Reliefs successifs */}
      {s.ridges.map((r, i) => (
        <polygon key={i} points={r.points} fill={r.color} />
      ))}

      {/* Acacias — la silhouette du logo */}
      {s.trees.map((t, i) => (
        <g key={i} transform={`translate(${t.x} 72) scale(${t.scale})`} fill={t.color}>
          <rect x="-0.7" y="-9" width="1.4" height="9" />
          <ellipse cx="0" cy="-10.5" rx="8.5" ry="2.6" />
          <ellipse cx="-3.5" cy="-12.2" rx="4.2" ry="1.9" />
          <ellipse cx="3.4" cy="-12" rx="3.8" ry="1.7" />
        </g>
      ))}

      {/* Cases */}
      {s.huts.map((h, i) => (
        <g key={i} transform={`translate(${h.x} 78) scale(${h.scale})`} fill={h.color}>
          <rect x="-4.5" y="-5" width="9" height="5" />
          <polygon points="-6.4,-5 0,-11.5 6.4,-5" />
        </g>
      ))}

      {/* Sol */}
      <rect y="76" width="100" height="24" fill={s.ground} />

      {/* Grain argentique */}
      <rect width="100" height="100" filter={`url(#grain-${id})`} opacity="0.5" />
    </svg>
  );
}

/** Petite étiquette honnête posée sur chaque visuel de démonstration. */
export function DemoBadge({ label }: { label: string }) {
  return (
    <span className="label pointer-events-none absolute left-3 top-3 z-10 rounded-xs bg-ground/75 px-2 py-1 text-[9px] text-ink-faint backdrop-blur-sm">
      {label}
    </span>
  );
}
