interface LogoProps {
  className?: string;
  /** `mark` = le symbole seul ; `full` = symbole + nom. */
  variant?: 'mark' | 'full';
  title?: string;
}

/**
 * La marque Afro Daily Village.
 * Le symbole reprend le logo existant : le soleil, l'acacia et les deux cases.
 * Il est dessiné en SVG pour rester net sur tous les écrans et peser presque rien.
 */
export function Logo({ className = '', variant = 'full', title = 'Afro Daily Village' }: LogoProps) {
  if (variant === 'mark') {
    return (
      <svg viewBox="0 0 64 64" className={className} role="img" aria-label={title}>
        <LogoMark />
      </svg>
    );
  }

  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <svg viewBox="0 0 64 64" className="h-8 w-8 shrink-0" aria-hidden="true">
        <LogoMark />
      </svg>
      <span className="flex flex-col leading-none">
        <span className="wordmark text-[15px] text-ink">Afro</span>
        <span className="wordmark text-[15px] text-sun">Daily Village</span>
      </span>
      <span className="sr-only">{title}</span>
    </span>
  );
}

function LogoMark() {
  return (
    <>
      <defs>
        <linearGradient id="adv-sun" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F5B942" />
          <stop offset="100%" stopColor="#D9761A" />
        </linearGradient>
      </defs>
      {/* Le soleil */}
      <circle cx="32" cy="30" r="22" fill="url(#adv-sun)" />
      {/* L'acacia */}
      <g fill="#17120D">
        <rect x="30.6" y="26" width="2.8" height="21" />
        <path d="M20 26 Q32 18 44 26 Q32 23 20 26 Z" />
        <ellipse cx="32" cy="24.5" rx="15" ry="4.2" />
        <ellipse cx="24" cy="21" rx="7.5" ry="3.2" />
        <ellipse cx="40" cy="21.4" rx="6.8" ry="2.9" />
        {/* Les cases */}
        <g>
          <rect x="13" y="39" width="10" height="8" />
          <polygon points="11,39 18,31.5 25,39" />
        </g>
        <g>
          <rect x="41" y="39" width="10" height="8" />
          <polygon points="39,39 46,31.5 53,39" />
        </g>
      </g>
      {/* La ligne d'horizon */}
      <path d="M6 49 Q32 56 58 49 L58 52 Q32 59 6 52 Z" fill="#17120D" />
    </>
  );
}
