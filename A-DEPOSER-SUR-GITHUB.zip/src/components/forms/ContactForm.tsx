'use client';

import { useState, type FormEvent } from 'react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/Button';

const TOPICS = ['general', 'partnership', 'sponsoring', 'press', 'collaboration'] as const;

const field =
  'h-12 w-full border border-line bg-surface px-3.5 font-body text-[16px] text-ink ' +
  'placeholder:text-ink-faint focus:border-sun focus:outline-none';

/**
 * Le formulaire de contact.
 * Il sera branché sur un envoi réel en phase 8. Pour l'instant il valide
 * la saisie et affiche une confirmation, sans rien envoyer — plutôt qu'un
 * formulaire qui ferait semblant de marcher.
 */
export function ContactForm() {
  const t = useTranslations('pages.contact');
  const tn = useTranslations('newsletter');
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSent(true);
  }

  if (sent) {
    return (
      <p className="border border-leaf/40 bg-leaf/10 px-5 py-4 text-[16px] leading-[1.6] text-ink">
        {tn('success')}
      </p>
    );
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="flex flex-col gap-2">
          <label htmlFor="contact-name" className="label text-[9.5px] text-ink-faint">
            {t('name')}
          </label>
          <input id="contact-name" name="name" required autoComplete="name" className={field} />
        </div>
        <div className="flex flex-col gap-2">
          <label htmlFor="contact-email" className="label text-[9.5px] text-ink-faint">
            {t('email')}
          </label>
          <input
            id="contact-email"
            name="email"
            type="email"
            required
            autoComplete="email"
            className={field}
          />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <label htmlFor="contact-subject" className="label text-[9.5px] text-ink-faint">
          {t('subject')}
        </label>
        <select id="contact-subject" name="subject" required className={field}>
          {TOPICS.map((topic) => (
            <option key={topic} value={topic}>
              {t(`topics.${topic}`)}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-2">
        <label htmlFor="contact-message" className="label text-[9.5px] text-ink-faint">
          {t('message')}
        </label>
        <textarea
          id="contact-message"
          name="message"
          required
          rows={7}
          className="w-full resize-y border border-line bg-surface px-3.5 py-3 font-body text-[16px] leading-[1.6] text-ink placeholder:text-ink-faint focus:border-sun focus:outline-none"
        />
      </div>

      <div>
        <Button type="submit" size="lg">
          {t('send')}
        </Button>
      </div>
    </form>
  );
}
