import { getTranslations } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { ButtonLink } from '@/components/ui/Button';
import { ArrowIcon } from '@/components/ui/Icon';

/**
 * Page d'attente propre.
 * Chaque rubrique du menu mène déjà quelque part : jamais une erreur 404,
 * jamais une page blanche. Ces pages seront remplies en phase 6.
 */
export async function ComingSoon({
  titleKey,
  phase,
}: {
  /** Chemin complet dans les fichiers de traduction, ex. « nav.videos ». */
  titleKey: string;
  phase: string;
}) {
  const t = await getTranslations();
  const tc = await getTranslations('common');

  return (
    <Container className="flex min-h-[60svh] flex-col justify-center py-24">
      <span className="label mb-4 text-sun">{phase}</span>
      <h1 className="text-[clamp(2rem,6vw,3.5rem)]">{t(titleKey)}</h1>
      <p className="mt-5 max-w-[52ch] text-[17px] leading-[1.6] text-ink-muted">
        {tc('empty')}
      </p>
      <div className="mt-9">
        <ButtonLink href="/" variant="outline">
          {tc('backHome')}
          <ArrowIcon className="h-4 w-4" />
        </ButtonLink>
      </div>
    </Container>
  );
}
