import type { ReactNode } from 'react';
import { Container } from '@/components/ui/Container';

/**
 * L'en-tête de rubrique.
 * Identique sur toutes les pages intérieures : c'est ce qui donne au site
 * l'impression d'avoir été dessiné d'un seul trait.
 */
export function PageHeader({
  eyebrow,
  title,
  lead,
  meta,
  children,
}: {
  eyebrow?: string;
  title: string;
  lead?: string;
  meta?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <header className="border-b border-line bg-surface">
      <Container className="py-14 lg:py-20">
        {eyebrow ? <p className="label mb-4 text-sun">{eyebrow}</p> : null}
        <h1 className="max-w-[20ch] text-[clamp(2.2rem,6.5vw,4rem)]">{title}</h1>
        {lead ? (
          <p className="mt-5 max-w-[58ch] text-[clamp(1rem,2vw,1.2rem)] leading-[1.55] text-ink-muted">
            {lead}
          </p>
        ) : null}
        {meta ? <div className="mt-7">{meta}</div> : null}
        {children}
      </Container>
    </header>
  );
}
