import { getTranslations } from 'next-intl/server';
import { Link } from '@/i18n/navigation';
import { Logo } from '@/components/brand/Logo';
import { InstagramIcon, TikTokIcon, YouTubeIcon } from '@/components/ui/Icon';
import { site } from '@/lib/site';

const EXPLORE = [
  { href: '/videos', key: 'videos' },
  { href: '/villages', key: 'villages' },
  { href: '/culture', key: 'culture' },
  { href: '/food', key: 'food' },
  { href: '/stories', key: 'stories' },
  { href: '/languages', key: 'languages' },
] as const;

const BRAND = [
  { href: '/about', key: 'about' },
  { href: '/contact', key: 'contact' },
  { href: '/partners', key: 'partners' },
  { href: '/support', key: 'support' },
] as const;

const LEGAL = [
  { href: '/legal-notice', key: 'legalNotice' },
  { href: '/privacy', key: 'privacy' },
  { href: '/cookies', key: 'cookies' },
  { href: '/terms', key: 'terms' },
] as const;

export async function Footer() {
  const t = await getTranslations();
  const soon = t('common.comingSoon');
  const year = new Date().getFullYear();

  return (
    <footer className="mt-24 border-t border-line bg-surface">
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-7 lg:px-10">
        <div className="grid gap-10 py-14 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo />
            <p className="mt-4 max-w-[34ch] text-[15px] leading-[1.55] text-ink-muted">
              {t('footer.blurb')}
            </p>
            <SocialRow soon={soon} />
          </div>

          <FooterColumn title={t('footer.explore')}>
            {EXPLORE.map((i) => (
              <li key={i.href}>
                <Link href={i.href} className="transition-colors hover:text-sun">
                  {t(`nav.${i.key}`)}
                </Link>
              </li>
            ))}
          </FooterColumn>

          <FooterColumn title={t('footer.brand')}>
            {BRAND.map((i) => (
              <li key={i.href}>
                <Link href={i.href} className="transition-colors hover:text-sun">
                  {t(`nav.${i.key}`)}
                </Link>
              </li>
            ))}
          </FooterColumn>

          <FooterColumn title={t('footer.legal')}>
            {LEGAL.map((i) => (
              <li key={i.href}>
                <Link href={i.href} className="transition-colors hover:text-sun">
                  {t(`footer.${i.key}`)}
                </Link>
              </li>
            ))}
          </FooterColumn>
        </div>

        <div className="label flex flex-col gap-2 border-t border-line py-6 text-[10.5px] text-ink-faint sm:flex-row sm:items-center sm:justify-between">
          <span>
            © {year} {site.name}. {t('footer.rights')}
          </span>
          <span>{t('footer.madeIn')}</span>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="label mb-4 text-[10.5px] text-ink-faint">{title}</h3>
      <ul className="flex flex-col gap-2.5 text-[15px] text-ink-muted">{children}</ul>
    </div>
  );
}

function SocialRow({ soon }: { soon: string }) {
  const items = [
    { url: site.social.youtube, Icon: YouTubeIcon, name: 'YouTube' },
    { url: site.social.tiktok, Icon: TikTokIcon, name: 'TikTok' },
    { url: site.social.instagram, Icon: InstagramIcon, name: 'Instagram' },
  ];

  return (
    <ul className="mt-6 flex items-center gap-2">
      {items.map(({ url, Icon, name }) =>
        url ? (
          <li key={name}>
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={name}
              className="flex h-10 w-10 items-center justify-center border border-line text-ink-muted transition-colors hover:border-sun hover:text-sun"
            >
              <Icon className="h-[18px] w-[18px]" />
            </a>
          </li>
        ) : (
          <li key={name}>
            <span
              title={`${name} — ${soon}`}
              className="flex h-10 w-10 items-center justify-center border border-line text-line-strong"
            >
              <Icon className="h-[18px] w-[18px]" />
            </span>
          </li>
        ),
      )}
    </ul>
  );
}
