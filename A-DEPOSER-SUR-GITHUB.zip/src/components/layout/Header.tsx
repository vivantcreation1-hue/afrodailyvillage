'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import { Link, usePathname } from '@/i18n/navigation';
import { Logo } from '@/components/brand/Logo';
import { LocaleSwitcher } from './LocaleSwitcher';
import { CloseIcon, MenuIcon, SearchIcon, YouTubeIcon } from '@/components/ui/Icon';
import { site } from '@/lib/site';

const NAV = [
  { href: '/videos', key: 'videos' },
  { href: '/villages', key: 'villages' },
  { href: '/culture', key: 'culture' },
  { href: '/food', key: 'food' },
  { href: '/stories', key: 'stories' },
  { href: '/languages', key: 'languages' },
  { href: '/about', key: 'about' },
] as const;

export function Header() {
  const t = useTranslations('nav');
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Le fond de l'en-tête n'apparaît qu'une fois le hero dépassé.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <header
      className={`sticky top-0 z-50 transition-colors duration-300 ${
        scrolled || open
          ? 'border-b border-line bg-ground/94 backdrop-blur-md'
          : 'border-b border-transparent'
      }`}
    >
      <div className="mx-auto flex h-16 w-full max-w-[1440px] items-center gap-4 px-5 sm:px-7 lg:h-[72px] lg:px-10">
        <Link href="/" className="shrink-0" aria-label={site.name}>
          <Logo />
        </Link>

        <nav className="ml-auto hidden items-center gap-6 lg:flex" aria-label={t('home')}>
          {NAV.map((item) => {
            const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`label text-[11px] transition-colors ${
                  active ? 'text-sun' : 'text-ink-muted hover:text-ink'
                }`}
              >
                {t(item.key)}
              </Link>
            );
          })}
        </nav>

        <div className="ml-auto flex items-center gap-3 lg:ml-4">
          <Link
            href="/search"
            aria-label={t('search')}
            className="p-1.5 text-ink-muted transition-colors hover:text-sun"
          >
            <SearchIcon className="h-[18px] w-[18px]" />
          </Link>

          <LocaleSwitcher className="hidden sm:flex" />

          <YouTubeButton label={t('watchOnYouTube')} />

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? t('closeMenu') : t('openMenu')}
            className="p-1.5 text-ink transition-colors hover:text-sun lg:hidden"
          >
            {open ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>

      {/* Menu mobile */}
      <div
        id="mobile-nav"
        hidden={!open}
        className="border-t border-line bg-ground lg:hidden"
      >
        <nav className="flex flex-col px-5 py-2 sm:px-7">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="border-b border-line py-3.5 font-display text-[19px] font-semibold tracking-tight text-ink last:border-0"
            >
              {t(item.key)}
            </Link>
          ))}
          <div className="flex items-center justify-between py-4">
            <LocaleSwitcher />
          </div>
        </nav>
      </div>
    </header>
  );
}

function YouTubeButton({ label }: { label: string }) {
  const classes =
    'hidden items-center gap-1.5 rounded-xs bg-[#FF0033] px-3 py-2 font-display text-[12px] font-semibold text-white transition-colors hover:bg-[#D9002B] sm:inline-flex';

  if (!site.social.youtube) {
    return (
      <span
        className={`${classes} cursor-default bg-line-strong text-ink-faint hover:bg-line-strong`}
        title={label}
      >
        <YouTubeIcon className="h-3.5 w-3.5" />
        <span className="hidden md:inline">{label}</span>
      </span>
    );
  }

  return (
    <a href={site.social.youtube} target="_blank" rel="noopener noreferrer" className={classes}>
      <YouTubeIcon className="h-3.5 w-3.5" />
      <span className="hidden md:inline">{label}</span>
    </a>
  );
}
