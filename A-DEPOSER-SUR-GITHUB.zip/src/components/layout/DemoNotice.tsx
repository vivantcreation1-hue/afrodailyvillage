import { getTranslations } from 'next-intl/server';
import { isDemoContent } from '@/lib/content';

/**
 * Bandeau d'honnêteté.
 *
 * Tant que le site tourne avec du contenu provisoire, il le dit — en haut,
 * lisiblement. Il disparaîtra tout seul dès que le premier vrai article
 * sera publié depuis le tableau de bord. Rien à désactiver à la main.
 */
export async function DemoNotice() {
  if (!(await isDemoContent())) return null;
  const t = await getTranslations('common');

  return (
    <div className="border-b border-line bg-raised">
      <p className="label mx-auto max-w-[1440px] px-5 py-2.5 text-center text-[10px] leading-[1.6] text-ink-faint sm:px-7 lg:px-10">
        {t('demoNotice')}
      </p>
    </div>
  );
}
