import { Link } from '@/i18n/navigation';
import type { ComponentProps } from 'react';

type Item = { label: string; href?: ComponentProps<typeof Link>['href'] };

/** Le fil d'Ariane visible. Sa version pour Google est posée à part, en JSON-LD. */
export function Breadcrumbs({ items }: { items: Item[] }) {
  return (
    <nav aria-label="Breadcrumb">
      <ol className="label flex flex-wrap items-center gap-2 text-[9.5px] text-ink-faint">
        {items.map((item, i) => (
          <li key={i} className="flex items-center gap-2">
            {i > 0 ? (
              <span aria-hidden="true" className="text-line-strong">
                /
              </span>
            ) : null}
            {item.href ? (
              <Link href={item.href} className="transition-colors hover:text-sun">
                {item.label}
              </Link>
            ) : (
              <span className="text-ink-muted">{item.label}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
