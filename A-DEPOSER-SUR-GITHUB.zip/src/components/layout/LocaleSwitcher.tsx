'use client';

import { useLocale } from 'next-intl';
import { useParams } from 'next/navigation';
import { usePathname, useRouter } from '@/i18n/navigation';
import { routing } from '@/i18n/routing';

/**
 * Le bouton EN / FR.
 * Il garde le visiteur exactement sur la même page, dans l'autre langue —
 * il ne le renvoie jamais à l'accueil, ce qui est la faute classique.
 */
export function LocaleSwitcher({ className = '' }: { className?: string }) {
  const locale = useLocale();
  const router = useRouter();
  const pathname = usePathname();
  const params = useParams();

  return (
    <div className={`label flex items-center gap-1 text-[11px] ${className}`}>
      {routing.locales.map((loc, i) => {
        const active = loc === locale;
        return (
          <span key={loc} className="flex items-center gap-1">
            {i > 0 ? (
              <span aria-hidden="true" className="text-line-strong">
                ·
              </span>
            ) : null}
            <button
              type="button"
              disabled={active}
              aria-current={active ? 'true' : undefined}
              onClick={() =>
                router.replace(
                  // @ts-expect-error — les paramètres dynamiques sont conservés tels quels
                  { pathname, params },
                  { locale: loc },
                )
              }
              className={
                active
                  ? 'cursor-default text-sun'
                  : 'text-ink-faint transition-colors hover:text-ink'
              }
            >
              {loc.toUpperCase()}
            </button>
          </span>
        );
      })}
    </div>
  );
}
