import { getTranslations } from 'next-intl/server';
import { ButtonLink } from '@/components/ui/Button';
import { Picture } from '@/components/media/Picture';
import { ArrowIcon, PlayIcon } from '@/components/ui/Icon';
import { getStats } from '@/lib/content';

export async function Hero() {
  const t = await getTranslations('hero');
  const tv = await getTranslations('villages');
  const tc = await getTranslations('common');
  const stats = await getStats();

  return (
    <section className="relative isolate flex min-h-[clamp(34rem,82svh,52rem)] flex-col justify-end overflow-hidden">
      {/* L'image de fond */}
      <Picture
        seed="hero-kolda-dawn"
        mood="dawn"
        alt={t('title')}
        demoLabel={tc('demoBadge')}
        priority
        className="absolute inset-0 -z-20 h-full w-full object-cover"
      />
      {/* Deux voiles superposés : un du bas (pour les boutons), un de la gauche
          (pour que le titre et la ligne d'accroche restent lisibles même quand
          le soleil de la photo se retrouve juste derrière le texte). */}
      <div className="scrim absolute inset-0 -z-10" />
      <div
        className="absolute inset-0 -z-10"
        style={{
          backgroundImage:
            'linear-gradient(100deg, rgb(13 10 6 / 0.86) 0%, rgb(13 10 6 / 0.62) 34%, rgb(13 10 6 / 0.12) 64%, rgb(13 10 6 / 0) 88%)',
        }}
      />

      <div className="mx-auto w-full max-w-[1200px] px-5 pb-10 pt-28 sm:px-7 lg:px-10 lg:pb-14">
        <p className="label adv-fade mb-5 text-sun">{t('eyebrow')}</p>

        <h1 className="wordmark adv-rise max-w-[16ch] text-[clamp(2.5rem,8.2vw,5.75rem)]">
          {t('title')}
        </h1>

        <p
          className="adv-rise mt-6 max-w-[52ch] text-[clamp(1rem,2.1vw,1.25rem)] leading-[1.5] text-ink-muted"
          style={{ animationDelay: '120ms' }}
        >
          {t('subtitle')}
        </p>

        <div
          className="adv-rise mt-9 flex flex-wrap items-center gap-3"
          style={{ animationDelay: '220ms' }}
        >
          <ButtonLink href="/videos" size="lg">
            <PlayIcon className="h-3.5 w-3.5" />
            {t('ctaPrimary')}
          </ButtonLink>
          <ButtonLink href="/villages" variant="outline" size="lg">
            {t('ctaSecondary')}
            <ArrowIcon className="h-4 w-4" />
          </ButtonLink>
        </div>
      </div>

      {/* La bande de chiffres, collée en bas du hero */}
      <div className="border-t border-line/70 bg-ground/55 backdrop-blur-md">
        <dl className="mx-auto grid w-full max-w-[1200px] grid-cols-3 divide-x divide-line/70 px-5 sm:px-7 lg:px-10">
          <Stat value={stats.villages} label={tv('villagesFilmed')} />
          <Stat value={stats.countries} label={tv('countries')} />
          <Stat value={stats.films} label="films" />
        </dl>
      </div>
    </section>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex flex-col-reverse gap-1 py-4 pl-4 first:pl-0">
      <dt className="label text-[9.5px] text-ink-faint">{label}</dt>
      <dd className="m-0 font-display text-[clamp(1.4rem,3.4vw,2rem)] font-bold leading-none tabular-nums text-sun">
        {value}
      </dd>
    </div>
  );
}
