import { getTranslations } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { ButtonLink } from '@/components/ui/Button';
import { ArrowIcon, SoundIcon } from '@/components/ui/Icon';
import { getWordOfTheDay } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

const LANGUAGE_NAMES: Record<string, { en: string; fr: string }> = {
  pulaar: { en: 'Pulaar', fr: 'Pulaar' },
  mandinka: { en: 'Mandinka', fr: 'Mandinka' },
  wolof: { en: 'Wolof', fr: 'Wolof' },
};

export async function WordOfDay({ locale }: { locale: Locale }) {
  const t = await getTranslations('word');
  const word = await getWordOfTheDay();
  const language = LANGUAGE_NAMES[word.language]?.[locale] ?? word.language;

  return (
    <section className="border-y border-line bg-surface py-16 lg:py-20">
      <Container>
        <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr] lg:items-center lg:gap-16">
          <div>
            <span className="label mb-4 block text-sun">{t('sectionLabel')}</span>
            <h2 className="text-[clamp(1.5rem,3.4vw,2.1rem)]">{t('sectionTitle')}</h2>
            <p className="mt-4 max-w-[42ch] text-[15.5px] leading-[1.6] text-ink-muted">
              {t('spokenIn', { region: word.region[locale] })}
            </p>
            <ButtonLink href="/languages" variant="outline" size="sm" className="mt-7">
              {t('seeAll')}
              <ArrowIcon className="h-3.5 w-3.5" />
            </ButtonLink>
          </div>

          {/* La carte-mot : c'est exactement ce visuel qui sera exporté en image
              partageable pour Instagram et TikTok (phase ultérieure). */}
          <figure className="border border-line-strong bg-ground p-7 sm:p-9">
            <div className="label flex items-center justify-between text-[10px] text-ink-faint">
              <span className="text-sun">{language}</span>
              <span>{word.region[locale]}</span>
            </div>

            <p className="wordmark mt-5 text-[clamp(2.25rem,7vw,3.75rem)] text-ink">{word.word}</p>

            <p className="mt-2 font-mono text-[13px] tracking-[0.08em] text-ink-faint">
              [ {word.pronunciation} ]
            </p>

            <button
              type="button"
              disabled
              title={t('listen')}
              className="label mt-5 inline-flex items-center gap-2 border border-line px-3 py-2 text-[10px] text-ink-faint"
            >
              <SoundIcon className="h-3.5 w-3.5" />
              {t('listen')}
            </button>

            <hr className="my-7 border-line" />

            <dl className="flex flex-col gap-5">
              <div>
                <dt className="label mb-1.5 text-[9.5px] text-ink-faint">{t('meaning')}</dt>
                <dd className="m-0 text-[17px] leading-[1.5] text-ink">{word.meaning[locale]}</dd>
              </div>
              <div>
                <dt className="label mb-1.5 text-[9.5px] text-ink-faint">{t('usage')}</dt>
                <dd className="m-0">
                  <p className="font-display text-[17px] font-semibold text-sun">{word.example[locale]}</p>
                  <p className="mt-1.5 text-[15px] leading-[1.5] text-ink-muted">
                    {word.exampleTranslation[locale]}
                  </p>
                </dd>
              </div>
            </dl>
          </figure>
        </div>
      </Container>
    </section>
  );
}
