import { getTranslations } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { ButtonExternal } from '@/components/ui/Button';
import { Picture } from '@/components/media/Picture';
import { PlayIcon, TikTokIcon, YouTubeIcon } from '@/components/ui/Icon';
import { getLatestVideos } from '@/lib/content';
import { site } from '@/lib/site';
import type { Locale } from '@/i18n/routing';

export async function YouTubeBlock({ locale }: { locale: Locale }) {
  const t = await getTranslations('youtube');
  const tc = await getTranslations('common');
  const [top] = await getLatestVideos(1);

  return (
    <section className="border-y border-line bg-[#0a0805] py-16 lg:py-20">
      <Container>
        <div className="grid gap-10 lg:grid-cols-[1.15fr_1fr] lg:items-center lg:gap-14">
          {/* Une miniature, pas un lecteur : la page reste légère et rapide */}
          <div className="relative aspect-video overflow-hidden border border-line">
            <Picture
              image={top?.image}
              seed={`yt-${top?.slug ?? 'channel'}`}
              mood="dusk"
              alt={top ? top.title[locale] : t('title')}
              demoLabel={tc('demoBadge')}
              sizes="(max-width: 1024px) 100vw, 55vw"
              className="h-full w-full object-cover"
            />
            <div className="scrim absolute inset-x-0 bottom-0 h-2/3" />
            <div className="absolute inset-x-0 bottom-0 flex items-end gap-3 p-5">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#FF0033] text-white">
                <PlayIcon className="ml-0.5 h-4 w-4" />
              </span>
              {top ? (
                <h3 className="text-[clamp(1rem,2.4vw,1.35rem)] leading-[1.2]">
                  {top.title[locale]}
                </h3>
              ) : null}
            </div>
          </div>

          <div>
            <span className="label mb-4 flex items-center gap-2 text-[#FF3355]">
              <YouTubeIcon className="h-4 w-4" />
              {t('sectionLabel')}
            </span>

            <h2 className="text-[clamp(1.75rem,4.2vw,2.6rem)] leading-[1.05]">{t('title')}</h2>

            <p className="mt-5 max-w-[44ch] text-[16px] leading-[1.6] text-ink-muted">{t('body')}</p>

            <div className="mt-8 flex flex-wrap gap-3">
              {site.social.youtube ? (
                <ButtonExternal href={site.social.youtube} variant="youtube" size="lg">
                  <YouTubeIcon className="h-4 w-4" />
                  {t('cta')}
                </ButtonExternal>
              ) : (
                <span className="label inline-flex h-13 items-center gap-2 border border-line px-5 text-[11px] text-ink-faint">
                  <YouTubeIcon className="h-4 w-4" />
                  {t('soon')}
                </span>
              )}

              {site.social.tiktok ? (
                <ButtonExternal href={site.social.tiktok} variant="outline" size="lg">
                  <TikTokIcon className="h-4 w-4" />
                  {t('secondary')}
                </ButtonExternal>
              ) : null}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
