import { getTranslations } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { ButtonLink } from '@/components/ui/Button';
import { Picture } from '@/components/media/Picture';
import { ArrowIcon } from '@/components/ui/Icon';
import { CountryTag } from '@/components/ui/CountryTag';
import { formatDate, getAuthor, getCountry, getFeaturedArticle } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

export async function FeaturedStory({ locale }: { locale: Locale }) {
  const article = await getFeaturedArticle();
  if (!article) return null;

  const t = await getTranslations('featured');
  const tc = await getTranslations('common');
  const [author, country] = await Promise.all([
    getAuthor(article.author),
    getCountry(article.country),
  ]);

  return (
    <section className="border-y border-line bg-surface py-16 lg:py-20">
      <Container>
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-14">
          <div className="relative order-1 aspect-4/3 overflow-hidden lg:order-2 lg:aspect-3/4">
            <Picture
              image={article.image}
              seed={`story-${article.slug}`}
              mood="noon"
              alt={article.title[locale]}
              demoLabel={tc('demoBadge')}
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="h-full w-full object-cover"
            />
          </div>

          <div className="order-2 lg:order-1">
            <span className="label mb-4 block text-sun">{t('sectionLabel')}</span>

            <h2 className="text-[clamp(1.75rem,4.6vw,3rem)] leading-[1.04]">
              {article.title[locale]}
            </h2>

            <p className="mt-5 max-w-[46ch] text-[clamp(1rem,1.9vw,1.15rem)] leading-[1.55] text-ink-muted">
              {article.standfirst[locale]}
            </p>

            <div className="label mt-7 flex flex-wrap items-center gap-x-3 gap-y-2 text-[10px] text-ink-faint">
              {author ? <span className="text-ink">{t('byline', { author: author.name })}</span> : null}
              <span aria-hidden="true" className="text-line-strong">/</span>
              <span>{formatDate(article.publishedAt, locale)}</span>
              <span aria-hidden="true" className="text-line-strong">/</span>
              <span>{t('readingTime', { minutes: article.readingMinutes })}</span>
              {country ? (
                <>
                  <span aria-hidden="true" className="text-line-strong">/</span>
                  <CountryTag country={country} locale={locale} />
                </>
              ) : null}
            </div>

            <ButtonLink href="/stories" size="md" className="mt-8">
              {t('readStory')}
              <ArrowIcon className="h-4 w-4" />
            </ButtonLink>
          </div>
        </div>
      </Container>
    </section>
  );
}
