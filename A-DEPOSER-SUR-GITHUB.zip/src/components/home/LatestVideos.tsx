import { getTranslations } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { ButtonLink } from '@/components/ui/Button';
import { VideoCard } from '@/components/cards/VideoCard';
import { ArrowIcon } from '@/components/ui/Icon';
import { getCountries, getLatestVideos } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

export async function LatestVideos({ locale }: { locale: Locale }) {
  const t = await getTranslations('videos');
  const [videos, countries] = await Promise.all([getLatestVideos(6), getCountries()]);
  const countryBySlug = new Map(countries.map((c) => [c.slug, c]));

  return (
    <section className="py-16 lg:py-20">
      <Container>
        <SectionHeader
          label={t('sectionLabel')}
          title={t('sectionTitle')}
          action={
            <ButtonLink href="/videos" variant="outline" size="sm">
              {t('seeAll')}
              <ArrowIcon className="h-3.5 w-3.5" />
            </ButtonLink>
          }
        />

        <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {videos.map((video) => (
            <VideoCard
              key={video.slug}
              video={video}
              locale={locale}
              country={countryBySlug.get(video.country)}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}
