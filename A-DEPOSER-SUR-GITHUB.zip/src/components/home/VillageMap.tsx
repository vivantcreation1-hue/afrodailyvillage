import { getTranslations } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { ButtonLink } from '@/components/ui/Button';
import { ArrowIcon } from '@/components/ui/Icon';
import { CountryTag } from '@/components/ui/CountryTag';
import { getCountries, getVillages } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

/** Cadre géographique de la zone couverte (Haute-Casamance et ses voisins). */
const BOUNDS = { north: 13.65, south: 11.95, west: -15.45, east: -13.75 };
const W = 100;
const H = 62;

const toX = (lng: number) => ((lng - BOUNDS.west) / (BOUNDS.east - BOUNDS.west)) * W;
const toY = (lat: number) => ((BOUNDS.north - lat) / (BOUNDS.north - BOUNDS.south)) * H;

export async function VillageMap({ locale }: { locale: Locale }) {
  const t = await getTranslations('villages');
  const [villages, countries] = await Promise.all([getVillages(), getCountries()]);
  const countryBySlug = new Map(countries.map((c) => [c.slug, c]));

  const meridians = [-15, -14.5, -14];
  const parallels = [13.5, 13, 12.5, 12];

  return (
    <section className="py-16 lg:py-20">
      <Container>
        <SectionHeader
          label={t('sectionLabel')}
          title={t('sectionTitle')}
          intro={t('intro')}
          action={
            <ButtonLink href="/villages" variant="outline" size="sm">
              {t('seeAll')}
              <ArrowIcon className="h-3.5 w-3.5" />
            </ButtonLink>
          }
        />

        <div className="grid gap-8 lg:grid-cols-[1.5fr_1fr] lg:items-start lg:gap-12">
          {/* La carte — coordonnées réelles, tracé volontairement sobre */}
          <div className="relative overflow-hidden border border-line bg-surface">
            <svg
              viewBox={`0 0 ${W} ${H}`}
              className="h-auto w-full"
              role="img"
              aria-label={t('sectionTitle')}
            >
              {/* Graticule */}
              <g stroke="var(--color-line)" strokeWidth="0.15">
                {meridians.map((m) => (
                  <line key={m} x1={toX(m)} y1="0" x2={toX(m)} y2={H} />
                ))}
                {parallels.map((p) => (
                  <line key={p} x1="0" y1={toY(p)} x2={W} y2={toY(p)} />
                ))}
              </g>
              <g fill="var(--color-ink-faint)" fontSize="1.7" fontFamily="var(--font-mono)">
                {meridians.map((m) => (
                  <text key={m} x={toX(m) + 0.6} y={H - 1}>
                    {Math.abs(m).toFixed(1)}°W
                  </text>
                ))}
                {parallels.map((p) => (
                  <text key={p} x="0.6" y={toY(p) - 0.8}>
                    {p.toFixed(1)}°N
                  </text>
                ))}
              </g>

              {/* Les villages */}
              {villages.map((v) => {
                const x = toX(v.lng);
                const y = toY(v.lat);
                const anchor = x > W * 0.66 ? 'end' : 'start';
                const dx = anchor === 'end' ? -2.6 : 2.6;
                return (
                  <g key={v.slug}>
                    {v.filmed ? (
                      <circle cx={x} cy={y} r="3.4" fill="var(--color-sun)" opacity="0.16" />
                    ) : null}
                    <circle
                      cx={x}
                      cy={y}
                      r="1.15"
                      fill={v.filmed ? 'var(--color-sun)' : 'none'}
                      stroke={v.filmed ? 'none' : 'var(--color-ink-faint)'}
                      strokeWidth="0.35"
                    />
                    <text
                      x={x + dx}
                      y={y + 0.7}
                      textAnchor={anchor}
                      fontSize="2.4"
                      fontFamily="var(--font-display)"
                      fontWeight="600"
                      fill={v.filmed ? 'var(--color-ink)' : 'var(--color-ink-faint)'}
                    >
                      {v.name}
                    </text>
                  </g>
                );
              })}
            </svg>

            <p className="label border-t border-line px-4 py-3 text-[9.5px] leading-[1.7] text-ink-faint">
              {t('mapCaption')}
            </p>
          </div>

          {/* La liste, qui double la carte pour les lecteurs d'écran et les petits écrans */}
          <ul className="divide-y divide-line border-y border-line">
            {villages.map((v) => {
              const country = countryBySlug.get(v.country);
              return (
                <li key={v.slug} className="flex items-start gap-3 py-4">
                  <span
                    aria-hidden="true"
                    className={`mt-2 h-1.5 w-1.5 shrink-0 rounded-full ${
                      v.filmed ? 'bg-sun' : 'bg-line-strong'
                    }`}
                  />
                  <div className="min-w-0">
                    <h3 className="text-[16px]">{v.name}</h3>
                    <p className="label mt-1 flex flex-wrap items-center gap-1.5 text-[9.5px] text-ink-faint">
                      {country ? <CountryTag country={country} locale={locale} /> : null}
                      <span aria-hidden="true" className="text-line-strong">
                        ·
                      </span>
                      <span>{v.region[locale]}</span>
                    </p>
                    <p className="mt-1.5 text-[14.5px] leading-[1.5] text-ink-muted">
                      {v.summary[locale]}
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </Container>
    </section>
  );
}
