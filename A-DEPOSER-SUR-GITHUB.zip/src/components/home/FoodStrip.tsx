import { getTranslations } from 'next-intl/server';
import { Container } from '@/components/ui/Container';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { ButtonLink } from '@/components/ui/Button';
import { RecipeCard } from '@/components/cards/RecipeCard';
import { ArrowIcon } from '@/components/ui/Icon';
import { getCountries, getRecipes } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

export async function FoodStrip({ locale }: { locale: Locale }) {
  const t = await getTranslations('food');
  const [recipes, countries] = await Promise.all([getRecipes(3), getCountries()]);
  const countryBySlug = new Map(countries.map((c) => [c.slug, c]));

  return (
    <section className="py-16 lg:py-20">
      <Container>
        <SectionHeader
          label={t('sectionLabel')}
          title={t('sectionTitle')}
          action={
            <ButtonLink href="/food" variant="outline" size="sm">
              {t('seeAll')}
              <ArrowIcon className="h-3.5 w-3.5" />
            </ButtonLink>
          }
        />

        <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {recipes.map((recipe, i) => (
            <RecipeCard
              key={recipe.slug}
              recipe={recipe}
              locale={locale}
              index={i}
              country={countryBySlug.get(recipe.country)}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}
