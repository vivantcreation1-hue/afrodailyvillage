'use client';

import { useState, type FormEvent } from 'react';
import { useTranslations } from 'next-intl';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';

type State = 'idle' | 'sending' | 'done' | 'error';

/**
 * Le formulaire d'inscription.
 * Il enverra les adresses à Brevo via /api/newsletter (phase 8).
 * Pour l'instant il valide la saisie et confirme, sans rien envoyer.
 */
export function NewsletterBlock() {
  const t = useTranslations('newsletter');
  const [state, setState] = useState<State>('idle');
  const [email, setEmail] = useState('');

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!email.includes('@')) return setState('error');
    setState('sending');
    // TODO phase 8 — POST /api/newsletter vers Brevo
    setTimeout(() => setState('done'), 400);
  }

  return (
    <section className="py-16 lg:py-20">
      <Container>
        <div className="border border-line-strong bg-surface px-6 py-12 sm:px-10 lg:px-14 lg:py-16">
          <div className="mx-auto max-w-[46ch] text-center">
            <h2 className="text-[clamp(1.6rem,4vw,2.4rem)] leading-[1.08]">{t('title')}</h2>
            <p className="mt-4 text-[16px] leading-[1.6] text-ink-muted">{t('body')}</p>

            {state === 'done' ? (
              <p className="mt-8 border border-leaf/40 bg-leaf/10 px-4 py-3.5 text-[15px] text-ink">
                {t('success')}
              </p>
            ) : (
              <form onSubmit={onSubmit} className="mt-8 flex flex-col gap-2.5 sm:flex-row">
                <label htmlFor="newsletter-email" className="sr-only">
                  {t('placeholder')}
                </label>
                <input
                  id="newsletter-email"
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (state === 'error') setState('idle');
                  }}
                  placeholder={t('placeholder')}
                  aria-invalid={state === 'error'}
                  className="h-13 min-w-0 flex-1 border border-line bg-ground px-4 font-body text-[16px] text-ink placeholder:text-ink-faint focus:border-sun focus:outline-none"
                />
                <Button type="submit" size="lg" disabled={state === 'sending'}>
                  {t('cta')}
                </Button>
              </form>
            )}

            {state === 'error' ? (
              <p className="mt-3 text-[14px] text-ember">{t('error')}</p>
            ) : (
              <p className="label mt-4 text-[9.5px] text-ink-faint">{t('consent')}</p>
            )}
          </div>
        </div>
      </Container>
    </section>
  );
}
