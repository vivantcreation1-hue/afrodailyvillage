'use client';

import { useState } from 'react';

/**
 * Les boutons de partage.
 * Aucun script tiers n'est chargé : ce sont de simples liens, donc rien
 * ne piste le visiteur et rien ne ralentit la page.
 */
export function ShareRow({ label, url, title }: { label: string; url: string; title: string }) {
  const [copied, setCopied] = useState(false);

  const encoded = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);

  const targets = [
    { name: 'WhatsApp', href: `https://wa.me/?text=${encodedTitle}%20${encoded}` },
    { name: 'Facebook', href: `https://www.facebook.com/sharer/sharer.php?u=${encoded}` },
    { name: 'X', href: `https://x.com/intent/post?text=${encodedTitle}&url=${encoded}` },
    { name: 'LinkedIn', href: `https://www.linkedin.com/sharing/share-offsite/?url=${encoded}` },
  ];

  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="mt-10 border-t border-line pt-6">
      <p className="label mb-3 text-[9.5px] text-ink-faint">{label}</p>
      <ul className="flex flex-wrap gap-2">
        {targets.map((target) => (
          <li key={target.name}>
            <a
              href={target.href}
              target="_blank"
              rel="noopener noreferrer"
              className="label inline-flex items-center border border-line px-3 py-2 text-[10px] text-ink-muted transition-colors hover:border-sun hover:text-sun"
            >
              {target.name}
            </a>
          </li>
        ))}
        <li>
          <button
            type="button"
            onClick={copy}
            className="label inline-flex items-center border border-line px-3 py-2 text-[10px] text-ink-muted transition-colors hover:border-sun hover:text-sun"
          >
            {copied ? '✓' : 'Lien / Link'}
          </button>
        </li>
      </ul>
    </div>
  );
}
