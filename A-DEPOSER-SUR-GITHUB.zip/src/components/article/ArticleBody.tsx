import { Picture } from '@/components/media/Picture';
import type { Block } from '@/lib/content';

/**
 * Le corps d'un article.
 *
 * Le texte est composé de « blocs » — paragraphe, intertitre, citation, image.
 * C'est exactement la structure que Sanity produira en phase 5 : le jour où le
 * vrai CMS arrive, ce composant n'aura pas besoin d'être réécrit.
 */
export function ArticleBody({ blocks, demoLabel }: { blocks: Block[]; demoLabel: string }) {
  return (
    <div className="flex flex-col gap-6">
      {blocks.map((block, i) => {
        switch (block.type) {
          case 'h2':
            return (
              <h2 key={i} className="mt-6 text-[clamp(1.35rem,3vw,1.75rem)]">
                {block.text}
              </h2>
            );

          case 'quote':
            return (
              <figure key={i} className="my-4 border-l-2 border-sun pl-5">
                <blockquote className="font-display text-[clamp(1.2rem,2.8vw,1.6rem)] font-semibold leading-[1.28] tracking-tight text-ink">
                  “{block.text}”
                </blockquote>
                {block.by ? (
                  <figcaption className="label mt-3 text-[9.5px] text-ink-faint">
                    {block.by}
                  </figcaption>
                ) : null}
              </figure>
            );

          case 'image':
            return (
              <figure key={i} className="my-4">
                <div className="relative aspect-3/2 w-full overflow-hidden bg-surface">
                  <Picture
                    image={block.image}
                    seed={block.seed ?? `body-${i}`}
                    alt={block.caption}
                    demoLabel={demoLabel}
                    sizes="(max-width: 768px) 100vw, 68ch"
                    className="h-full w-full object-cover"
                  />
                </div>
                <figcaption className="mt-2.5 text-[14px] leading-[1.5] text-ink-faint">
                  {block.caption}
                </figcaption>
              </figure>
            );

          default:
            return (
              <p key={i} className="text-[clamp(1.05rem,1.9vw,1.15rem)] leading-[1.72] text-ink">
                {block.text}
              </p>
            );
        }
      })}
    </div>
  );
}
