import { getTranslations } from 'next-intl/server';
import { Link } from '@/i18n/navigation';
import { Picture } from '@/components/media/Picture';
import { PlayIcon } from '@/components/ui/Icon';
import { CountryTag } from '@/components/ui/CountryTag';
import { formatDuration, type Country, type Video } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

export async function VideoCard({
  video,
  locale,
  country,
}: {
  video: Video;
  locale: Locale;
  country?: Country;
}) {
  const t = await getTranslations('common');

  return (
    <article className="group">
      <Link href="/videos" className="block focus-visible:outline-offset-4">
        <div className="relative aspect-video w-full overflow-hidden bg-surface">
          <Picture
            image={video.image}
            seed={video.slug}
            mood={video.format === 'short' ? 'noon' : undefined}
            alt={video.title[locale]}
            demoLabel={t('demoBadge')}
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="h-full w-full object-cover transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.045]"
          />

          {/* Le voile n'apparaît qu'en bas : la photo reste visible */}
          <div className="scrim-soft absolute inset-x-0 bottom-0 h-2/3" />

          <span className="label absolute bottom-2.5 right-2.5 bg-ground/85 px-1.5 py-1 text-[10px] text-ink tabular-nums">
            {formatDuration(video.durationSeconds)}
          </span>

          <span className="absolute bottom-2.5 left-2.5 flex h-9 w-9 items-center justify-center rounded-full bg-sun text-[#1A1206] transition-transform duration-300 group-hover:scale-110">
            <PlayIcon className="ml-0.5 h-3.5 w-3.5" />
          </span>

          {video.format === 'short' ? (
            <span className="label absolute right-2.5 top-2.5 bg-ember px-1.5 py-1 text-[9px] text-white">
              Short
            </span>
          ) : null}
        </div>

        <div className="pt-3.5">
          <div className="label mb-2 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10px] text-ink-faint">
            <span className="text-sun">{video.category[locale]}</span>
            {country ? (
              <span aria-hidden="true" className="text-line-strong">
                /
              </span>
            ) : null}
            {country ? <CountryTag country={country} locale={locale} /> : null}
          </div>
          <h3 className="text-[17px] leading-[1.22] transition-colors duration-200 group-hover:text-sun">
            {video.title[locale]}
          </h3>
        </div>
      </Link>
    </article>
  );
}
