import { getTranslations } from 'next-intl/server';
import { SoundIcon } from '@/components/ui/Icon';
import type { Word } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

/**
 * La carte-mot.
 * C'est ce visuel qui sera exporté en image carrée partageable
 * pour Instagram et TikTok — d'où sa composition volontairement carrée.
 */
export async function WordCard({
  word,
  locale,
  languageName,
}: {
  word: Word;
  locale: Locale;
  languageName?: string;
}) {
  const t = await getTranslations('word');

  return (
    <figure className="flex h-full flex-col border border-line bg-surface p-6 transition-colors duration-200 hover:border-line-strong">
      <div className="label flex items-center justify-between gap-3 text-[10px] text-ink-faint">
        <span className="text-sun">{languageName ?? word.language}</span>
        <SoundIcon className="h-3.5 w-3.5 shrink-0" />
      </div>

      <p className="wordmark mt-4 text-[clamp(1.6rem,4.5vw,2.25rem)] text-ink">{word.word}</p>
      <p className="mt-1.5 font-mono text-[12px] tracking-[0.08em] text-ink-faint">
        [ {word.pronunciation} ]
      </p>

      <hr className="my-5 border-line" />

      <div className="flex flex-1 flex-col gap-4">
        <div>
          <p className="label mb-1.5 text-[9px] text-ink-faint">{t('meaning')}</p>
          <p className="text-[16px] leading-[1.5] text-ink">{word.meaning[locale]}</p>
        </div>
        <div>
          <p className="label mb-1.5 text-[9px] text-ink-faint">{t('usage')}</p>
          <p className="font-display text-[16px] font-semibold text-sun">{word.example[locale]}</p>
          <p className="mt-1 text-[14.5px] leading-[1.5] text-ink-muted">
            {word.exampleTranslation[locale]}
          </p>
        </div>
      </div>

      <figcaption className="label mt-5 border-t border-line pt-3 text-[9px] text-ink-faint">
        {word.region[locale]}
      </figcaption>
    </figure>
  );
}
