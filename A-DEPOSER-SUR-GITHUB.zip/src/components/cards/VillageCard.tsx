import { getTranslations } from 'next-intl/server';
import { Link } from '@/i18n/navigation';
import { Picture } from '@/components/media/Picture';
import { CountryTag } from '@/components/ui/CountryTag';
import type { Country, Village } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

const MOODS = ['dawn', 'noon', 'dusk', 'night', 'fire'] as const;

export async function VillageCard({
  village,
  locale,
  country,
  index = 0,
}: {
  village: Village;
  locale: Locale;
  country?: Country;
  index?: number;
}) {
  const t = await getTranslations('common');
  const tv = await getTranslations('pages.villages');

  return (
    <article className="group">
      <Link
        href={{ pathname: '/villages/[slug]', params: { slug: village.slug } }}
        className="block focus-visible:outline-offset-4"
      >
        <div className="relative aspect-3/2 w-full overflow-hidden bg-surface">
          <Picture
            image={village.image}
            seed={`village-${village.slug}`}
            mood={MOODS[index % MOODS.length]}
            alt={village.name}
            demoLabel={t('demoBadge')}
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="h-full w-full object-cover transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.045]"
          />
          <span
            className={`label absolute right-3 top-3 px-1.5 py-1 text-[9px] ${
              village.filmed ? 'bg-sun text-[#1A1206]' : 'bg-ground/85 text-ink-faint'
            }`}
          >
            {village.filmed ? tv('filmed') : tv('planned')}
          </span>
        </div>

        <div className="pt-3.5">
          <h3 className="text-[19px] leading-[1.18] transition-colors duration-200 group-hover:text-sun">
            {village.name}
          </h3>
          <p className="label mt-2 flex flex-wrap items-center gap-1.5 text-[9.5px] text-ink-faint">
            {country ? <CountryTag country={country} locale={locale} /> : null}
            <span aria-hidden="true" className="text-line-strong">·</span>
            <span>{village.region[locale]}</span>
          </p>
          <p className="mt-2.5 text-[15px] leading-[1.55] text-ink-muted">
            {village.summary[locale]}
          </p>
        </div>
      </Link>
    </article>
  );
}
