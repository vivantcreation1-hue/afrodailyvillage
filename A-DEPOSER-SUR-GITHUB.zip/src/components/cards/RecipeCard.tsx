import { getTranslations } from 'next-intl/server';
import { Link } from '@/i18n/navigation';
import { Picture } from '@/components/media/Picture';
import { CountryTag } from '@/components/ui/CountryTag';
import type { Country, Recipe } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

const RECIPE_MOODS = ['fire', 'dusk', 'noon'] as const;

export async function RecipeCard({
  recipe,
  locale,
  country,
  index = 0,
}: {
  recipe: Recipe;
  locale: Locale;
  country?: Country;
  index?: number;
}) {
  const t = await getTranslations('common');

  return (
    <article className="group">
      <Link href="/food" className="block focus-visible:outline-offset-4">
        <div className="relative aspect-4/5 w-full overflow-hidden bg-surface">
          <Picture
            image={recipe.image}
            seed={`recipe-${recipe.slug}`}
            mood={RECIPE_MOODS[index % RECIPE_MOODS.length]}
            alt={recipe.name[locale]}
            demoLabel={t('demoBadge')}
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="h-full w-full object-cover transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.045]"
          />
          <div className="scrim absolute inset-x-0 bottom-0 h-3/5" />

          <div className="absolute inset-x-0 bottom-0 p-4">
            <span className="label mb-1.5 block text-[10px] text-sun">
              {country ? (
                <CountryTag country={country} locale={locale} />
              ) : (
                recipe.region[locale]
              )}
            </span>
            <h3 className="text-[19px] leading-[1.15]">{recipe.name[locale]}</h3>
          </div>
        </div>
        <p className="mt-3 text-[15px] leading-[1.55] text-ink-muted">{recipe.summary[locale]}</p>
      </Link>
    </article>
  );
}
