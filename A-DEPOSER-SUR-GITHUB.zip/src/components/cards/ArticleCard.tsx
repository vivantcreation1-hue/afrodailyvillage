import { getTranslations } from 'next-intl/server';
import { Link } from '@/i18n/navigation';
import { Picture } from '@/components/media/Picture';
import { CountryTag } from '@/components/ui/CountryTag';
import { formatDate, type Article, type Country } from '@/lib/content';
import type { Locale } from '@/i18n/routing';

const MOODS = ['noon', 'dawn', 'dusk', 'night'] as const;

export async function ArticleCard({
  article,
  locale,
  country,
  index = 0,
}: {
  article: Article;
  locale: Locale;
  country?: Country;
  index?: number;
}) {
  const t = await getTranslations('common');
  const tf = await getTranslations('featured');

  return (
    <article className="group">
      <Link
        href={{ pathname: '/stories/[slug]', params: { slug: article.slug } }}
        className="block focus-visible:outline-offset-4"
      >
        <div className="relative aspect-3/2 w-full overflow-hidden bg-surface">
          <Picture
            image={article.image}
            seed={`article-${article.slug}`}
            mood={MOODS[index % MOODS.length]}
            alt={article.title[locale]}
            demoLabel={t('demoBadge')}
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="h-full w-full object-cover transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.045]"
          />
        </div>

        <div className="pt-3.5">
          <div className="label mb-2 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10px] text-ink-faint">
            <span className="text-sun">{article.category[locale]}</span>
            {country ? (
              <>
                <span aria-hidden="true" className="text-line-strong">/</span>
                <CountryTag country={country} locale={locale} />
              </>
            ) : null}
          </div>

          <h3 className="text-[19px] leading-[1.18] transition-colors duration-200 group-hover:text-sun">
            {article.title[locale]}
          </h3>

          <p className="mt-2.5 text-[15px] leading-[1.55] text-ink-muted">
            {article.standfirst[locale]}
          </p>

          <p className="label mt-3 text-[9.5px] text-ink-faint">
            {formatDate(article.publishedAt, locale)} ·{' '}
            {tf('readingTime', { minutes: article.readingMinutes })}
          </p>
        </div>
      </Link>
    </article>
  );
}
