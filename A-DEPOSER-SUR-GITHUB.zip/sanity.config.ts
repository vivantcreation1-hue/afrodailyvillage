'use client';

import { defineConfig } from 'sanity';
import { structureTool } from 'sanity/structure';
import { visionTool } from '@sanity/vision';
import { schemaTypes } from './src/sanity/schemas';
import { apiVersion, dataset, projectId } from './src/sanity/env';

/**
 * LE TABLEAU DE BORD
 *
 * Accessible sur /studio une fois le site en ligne, et sur
 * http://localhost:3000/studio en local.
 *
 * Le menu de gauche est rangé dans l'ordre où on s'en sert vraiment :
 * les articles et les vidéos en haut, les réglages tout en bas.
 */
export default defineConfig({
  name: 'afrodailyvillage',
  title: 'Afro Daily Village',
  basePath: '/studio',
  projectId,
  dataset,
  schema: { types: schemaTypes },
  plugins: [
    structureTool({
      structure: (S) =>
        S.list()
          .title('Afro Daily Village')
          .items([
            S.documentTypeListItem('article').title('Articles'),
            S.documentTypeListItem('video').title('Vidéos'),
            S.documentTypeListItem('village').title('Villages'),
            S.documentTypeListItem('country').title('Pays'),
            S.documentTypeListItem('recipe').title('Recettes'),
            S.divider(),
            S.documentTypeListItem('language').title('Langues'),
            S.documentTypeListItem('word').title('Mots'),
            S.documentTypeListItem('cultureTheme').title('Thèmes culturels'),
            S.divider(),
            S.documentTypeListItem('author').title('Auteurs'),
            S.listItem()
              .title('Réglages du site')
              .id('siteSettings')
              .child(S.document().schemaType('siteSettings').documentId('siteSettings')),
          ]),
    }),
    visionTool({ defaultApiVersion: apiVersion }),
  ],
});
