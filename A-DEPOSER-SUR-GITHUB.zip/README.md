# Afro Daily Village

> Le quotidien des villages africains, raconté au monde.
> The daily life of African villages, told to the world.

Site officiel d'Afro Daily Village — plateforme média bilingue (anglais / français)
consacrée à la vie quotidienne dans les villages d'Afrique de l'Ouest.

---

## 1. Où en est le projet

| Phase | Contenu | État |
| --- | --- | --- |
| 1 | Audit et architecture | ✅ Terminé |
| 2 | Initialisation du projet | ✅ Terminé |
| 3 | Design system | ✅ Terminé |
| 4 | Page d'accueil | ✅ Terminé |
| 5 | Tableau de bord (Sanity) | ✅ Terminé (projet `pjxrvb9e`) |
| 6 | Pages éditoriales | ✅ Terminé |
| 7 | Référencement | 🟡 Socle complet (sitemap 94 URL, robots, metadata, hreflang, JSON-LD) |
| 8 | Newsletter (Brevo) | ⬜ À venir |
| 9 | Statistiques et RGPD | ⬜ À venir |
| 10 | Monétisation | ⬜ À venir |
| 11 | Optimisation et mise en ligne | ⬜ À venir |

---

## 2. La stack, et pourquoi

| Outil | Rôle | Raison du choix |
| --- | --- | --- |
| **Next.js 16** (App Router) | Moteur du site | Rapide, excellent pour Google, standard de l'industrie média |
| **TypeScript** | Sécurité du code | Attrape les erreurs avant la mise en ligne |
| **Tailwind CSS 4** | Mise en forme | Design system tenu par des jetons de couleur et de police |
| **next-intl** | Bilingue | Deux vraies versions du site, adresses traduites, `hreflang` automatique |
| **Sanity** *(phase 5)* | Tableau de bord | Aucun serveur à entretenir, CDN d'images inclus, bilingue natif |
| **Brevo** *(phase 8)* | Newsletter | Société française, serveurs en Europe, conforme RGPD, gratuit au départ |
| **Vercel** | Hébergement | Créé par les auteurs de Next.js ; le domaine OVH pointera dessus |
| **Fontsource** | Polices | Servies par notre domaine, jamais par Google — exigence RGPD |

---

## 3. Installation

```bash
npm install          # installe les dépendances
cp .env.example .env.local
npm run dev          # démarre le site sur http://localhost:3000
```

Autres commandes :

```bash
npm run build        # construit la version de production
npm run start        # lance la version de production
npm run lint         # vérifie la qualité du code
npx tsc --noEmit     # vérifie les types
```

---

## 4. Variables d'environnement

Toutes décrites dans `.env.example`. **Aucun secret ne doit être placé dans Git.**
Le fichier `.env.local` est ignoré par Git.

| Variable | Phase | À quoi ça sert |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | 2 | Adresse du site (sitemap, partages sociaux) |
| `NEXT_PUBLIC_YOUTUBE_URL` / `TIKTOK` / `INSTAGRAM` | 2 | Liens sociaux. Vides = le site affiche « bientôt » au lieu d'un lien mort |
| `NEXT_PUBLIC_SANITY_PROJECT_ID`, `SANITY_API_READ_TOKEN` | 5 | Tableau de bord |
| `YOUTUBE_API_KEY`, `YOUTUBE_CHANNEL_ID` | 6 | Récupération automatique des vidéos |
| `BREVO_API_KEY`, `BREVO_LIST_ID` | 8 | Newsletter |
| `NEXT_PUBLIC_GA_MEASUREMENT_ID` | 9 | Google Analytics |
| `NEXT_PUBLIC_ADSENSE_CLIENT` | 10 | Publicité |

---

## 5. Organisation du code

```
src/
├─ app/
│  ├─ [locale]/          Toutes les pages, dans les deux langues
│  │  ├─ layout.tsx      En-tête, pied de page, métadonnées
│  │  ├─ page.tsx        LA PAGE D'ACCUEIL
│  │  └─ …/page.tsx      Une par rubrique
│  ├─ layout.tsx         Enveloppe technique exigée par Next.js
│  ├─ not-found.tsx      404 sans langue
│  ├─ sitemap.ts         Plan du site pour Google
│  └─ robots.ts          Consignes pour Google
├─ components/
│  ├─ brand/             Le logo
│  ├─ ui/                Boutons, conteneurs, icônes, étiquettes pays
│  ├─ layout/            En-tête, pied de page, bandeau démo, page d'attente
│  ├─ media/             Visuels de démonstration
│  ├─ cards/             Cartes vidéo, recette (article, village, mot : phase 6)
│  └─ home/              Les huit sections de la page d'accueil
├─ i18n/                 Réglages des deux langues et des adresses traduites
├─ lib/
│  ├─ content/           ⚠️ Couche d'accès au contenu — voir §7
│  ├─ demo-photo.ts      Générateur de visuels provisoires
│  └─ site.ts            Réglages de la marque
└─ proxy.ts              Redirige vers /en ou /fr selon le navigateur

messages/
├─ en.json               Tous les textes anglais
└─ fr.json               Tous les textes français
```

**Règle :** tout texte visible passe par `messages/en.json` et `messages/fr.json`.
Aucun texte n'est écrit en dur dans un composant.

---

## 6. Le design system

Défini une seule fois, dans `src/app/globals.css`.

**Couleurs** — terre, sable, végétation, bois, soleil, pierre. Le site est
volontairement sombre : les photos de village y ressortent comme au cinéma,
et l'ocre du logo devient la seule couleur vive.

| Jeton | Valeur | Usage |
| --- | --- | --- |
| `ground` | `#0D0A06` | Fond général |
| `surface` | `#16110A` | Sections posées sur le fond |
| `ink` | `#F5EEE2` | Texte principal |
| `ink-muted` | `#B3A48D` | Texte secondaire |
| `sun` | `#E39B2E` | Accent, boutons, liens |
| `ember` | `#C9552A` | Alertes, badge « Short » |
| `leaf` | `#6E8C58` | Confirmations |

**Polices** — `Archivo` (titres, très gras, comme le logo), `Source Serif 4`
(textes, pour la sensation magazine), `IBM Plex Mono` (étiquettes et chiffres).

---

## 6 bis. Le tableau de bord (Sanity)

Adresse : **`/studio`** — donc `afrodailyvillage.com/studio` une fois en ligne,
et `http://localhost:3000/studio` en local.

**Identifiant du projet : `pjxrvb9e`** (public, ce n'est pas un mot de passe).

Neuf types de fiches, définis dans `src/sanity/schemas/documents.ts` :
Article · Vidéo · Village · Pays · Recette · Langue · Mot · Thème culturel ·
Auteur, plus les Réglages du site.

**Le bilingue dans le tableau de bord.** Chaque champ de texte a deux cases,
« English » et « Français ». L'anglais est obligatoire, le français facultatif :
un article publié en anglais seul s'affiche en anglais sur les deux versions
du site, plutôt que de laisser un trou.

**La bascule est automatique.** `src/lib/content/index.ts` interroge Sanity ;
si Sanity ne répond pas, ou si aucune fiche n'existe encore, le site affiche
le contenu de démonstration. Le bandeau « contenu de démonstration » disparaît
tout seul dès le premier article publié. Il n'y a donc aucun interrupteur à
actionner, et une panne de Sanity ne peut pas mettre le site hors service.

**À faire dans sanity.io/manage → API → CORS origins**, sinon le tableau de
bord refusera de s'ouvrir :

| Origine | Credentials |
| --- | --- |
| `http://localhost:3000` | oui |
| `https://afrodailyvillage.com` | oui |
| l'adresse `.vercel.app` du site | oui |

---

## 7. Contenu de démonstration

Le site tourne actuellement avec du contenu provisoire, dans
`src/lib/content/demo-data.ts`.

- Un bandeau le signale en haut de chaque page.
- Chaque visuel porte l'étiquette « Photo de démonstration ».
- Les lieux et les langues sont réels ; les récits, durées et dates sont fictifs.

**Rien de fictif n'est jamais présenté comme un fait avéré.**

Pour passer au vrai contenu (phase 5), il suffira de remplacer l'intérieur des
fonctions de `src/lib/content/index.ts` par des requêtes Sanity. Aucune page
n'aura besoin d'être modifiée : c'est tout l'intérêt de cette couche.

---

## 8. Le bilingue

- Anglais par défaut (`/en`), français en second (`/fr`).
- Les adresses sont traduites : `/en/stories` ↔ `/fr/histoires`.
- Chaque page indique à Google où se trouve sa jumelle (`hreflang`).
- Le bouton EN/FR garde le visiteur sur la même page.
- La liste complète des adresses est dans `src/i18n/routing.ts`.

---

## 8 bis. Limite connue — les adresses des articles

Les rubriques sont traduites (`/en/stories` ↔ `/fr/histoires`), mais le
« slug » d'un article reste identique dans les deux langues :

```
/en/stories/the-woman-who-decides-breakfast
/fr/histoires/the-woman-who-decides-breakfast   ← devrait être en français
```

Ce n'est pas bloquant, mais c'est une perte de référencement côté français.
La correction se fera en phase 5 : dans Sanity, chaque article aura un slug
par langue, et la résolution se fera langue par langue. Ne pas bricoler cela
avant, sous peine de casser le bouton EN/FR.

## 9. Ce qu'il reste à faire pour la mise en ligne

1. Créer un compte Sanity et brancher le tableau de bord (phase 5).
2. Créer les comptes YouTube / TikTok / Instagram et renseigner les liens.
3. Créer un compte Brevo pour la newsletter (phase 8).
4. Rédiger les pages légales et poser le bandeau cookies (phase 9).
5. Publier 15 à 20 vrais articles **avant** de demander Google AdSense (phase 10).
6. Déployer sur Vercel et faire pointer le domaine OVH dessus (phase 11).

---

## 10. Règles de qualité tenues sur ce projet

- TypeScript strict, aucune erreur ESLint.
- Aucun secret dans le code ; en-têtes de sécurité posés dans `next.config.ts`.
- Mobile d'abord, puis tablette, puis ordinateur.
- Animations désactivées si le visiteur a demandé « moins d'animations ».
- Aucune dépendance ajoutée sans raison : le site ne charge aucune librairie
  d'icônes, aucune librairie d'animation, aucune police externe.
